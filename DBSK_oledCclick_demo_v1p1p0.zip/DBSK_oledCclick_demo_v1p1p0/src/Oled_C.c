/*
 * Project name:
      OLED C Click
 * Copyright:
      (c) mikroElektronika, 2014.
 * Revision History:
      20140919:
      - Initial release (BD);
 * Description:
      OLED C click lets you add a small but bright and crisp display to your design. 
      It carries a passive matrix OLED display capable of displaying over 65k colors, and a SEPS114A display driver and controller IC.
      OLED C click communicates with the target board through mikroBUS SPI lines: CS, SCK, and MOSI (SDI); and PWM (A/C) and RST lines.

      They are bright, have a wide viewing angle and low power consumption (with a 20mA maximum). 
      The display on OLED C click is 19.8 x 19.8mm with a 96 x 96px resolution.
      The SEPS114A controller has built-in functionalities like screen saver (vertical scroll, horizontal panning, fade in/out), 
      programmable panel size, power save mode and so forth.

      OLED C click uses a 3.3V power supply.

 * Test configuration:
      MCU:             STM32F107VC
                       http://www.st.com/st-web-ui/static/active/en/resource/technical/document/reference_manual/CD00171190.pdf
      Dev. Board:      EasyMx PRO v7 for STM32
                       http://www.mikroe.com/eng/products/view/852/easymx-pro-v7-for-stm32/
      Oscillator:      HS-PLL 72.0000 MHz
      ext. modules:    OLED C click
                       http://www.mikroe.com/click/oled-c/
      SW:              mikroC PRO for ARM
                       http://www.mikroe.com/mikroc/arm/
 NOTES:
     - Place OLED C Click board in the mikroBUS socket 1.
*/
/*****************************************************************************
 * Copyright (C) 2015 by Embedded Product Design, LLC                        *
 *                                                                           *
 * FILENAME: Oled_C.c      PART OF PROJECT: DBSK_oledCclick_demo             *
 *                                                                           *
 * FILE DESCRIPTION:                                                         *
 * Commented-out original code as provided my MikroElektronica               *
 * SSP-equivalents are included in support.c/.h                              *
 *                                                                           *
 * HISTORY:                                                                  *
 * Date          By           Description                                    *
 * 2015-10-09    Ed Strehle   Initial release for Renesas DevCon 2015        *
 * 2015-10-23    EPD/Ed Strehle   v1.1.0 update for SSP v1.0.0 ...           *
 *                                   replaced Avnet logo w/DiscBoards        *
 *                                                                           *
 * NOTES:                                                                    *
 *                                                                           *
 * KNOWN TODOs:                                                              *
 * <none>                                                                    *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
#include "Oled_C.h"
#include "support.h"
#include "screens.h"

/* to be replaced with SSP equivalents ... see support.c
sbit OLED_RST at GPIOC_ODR.B2;      // RST pin
sbit OLED_CS  at GPIOD_ODR.B13;     // CS pin
sbit OLED_DC  at GPIOA_ODR.B0;      // DC pin
sbit OLED_T   at GPIOA_ODR.B4;      // R/W pin

// Init MCU function
void InitMCU(){

  GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_2);      // Set GPIOC pin 3  as digital output  (OLED_RST pin)
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_13);     // Set GPIOD pin 13 as digital output  (OLED_RST pin)
  GPIO_Digital_Output(&GPIOA_BASE, _GPIO_PINMASK_0);      // Set GPIOA pin 0  as digital output  (OLED_DC pin)
  GPIO_Digital_Output(&GPIOA_BASE, _GPIO_PINMASK_4);      // Set GPIOA pin 0  as digital output  (OLED_T pin)

// Initialize SPI3 module
  SPI3_Init_Advanced(_SPI_FPCLK_DIV8, _SPI_MASTER | _SPI_8_BIT |
                     _SPI_CLK_IDLE_LOW | _SPI_FIRST_CLK_EDGE_TRANSITION |
                     _SPI_MSB_FIRST | _SPI_SS_DISABLE | _SPI_SSM_ENABLE | _SPI_SSI_1,
                     &_GPIO_MODULE_SPI3_PC10_11_12);
  OLED_T=0;
  //Delay_ms(100);
}

//Send command to OLED C display
void OLED_C_command(unsigned char reg_index, unsigned char reg_value){
//Select index addr
    OLED_CS = 0;
    OLED_DC = 0;
    SPI3_Write(reg_index);
    OLED_CS = 1;
//Write data to reg
    OLED_CS = 0;
    OLED_DC = 1;
    SPI3_Write(reg_value);
    OLED_CS = 1;
}

//Send data to OLED C display
void OLED_C_data(unsigned char data_value){
    OLED_CS = 0;
    OLED_DC = 1;
    SPI3_Write(data_value);
    OLED_CS = 1;
}
*/


// Init sequence for 96x96 OLED color module
void OLED_C_Init(){
	reset_LCD();

/*	OLED_RST=0;
	Delay_ms(10);
	OLED_RST=1;
	Delay_ms(10);
*/
	/*  Soft reset */
	OLED_C_command(SEPS114A_SOFT_RESET,0x00);
	/* Standby ON/OFF*/
	OLED_C_command(SEPS114A_STANDBY_ON_OFF,0x01);          // Standby on
	Delay_ms(5);                                           // Wait for 5ms (1ms Delay Minimum)
	OLED_C_command(SEPS114A_STANDBY_ON_OFF,0x00);          // Standby off
	Delay_ms(5);                                           // 1ms Delay Minimum (1ms Delay Minimum)
	/* Display OFF */
	OLED_C_command(SEPS114A_DISPLAY_ON_OFF,0x00);
	/* Set Oscillator operation */
	OLED_C_command(SEPS114A_ANALOG_CONTROL,0x00);          // using external resistor and internal OSC
	/* Set frame rate */
	OLED_C_command(SEPS114A_OSC_ADJUST,0x03);              // frame rate : 95Hz
	/* Set active display area of panel */
	OLED_C_command(SEPS114A_DISPLAY_X1,0x00);
	OLED_C_command(SEPS114A_DISPLAY_X2,0x5F);
	OLED_C_command(SEPS114A_DISPLAY_Y1,0x00);
	OLED_C_command(SEPS114A_DISPLAY_Y2,0x5F);
	/* Select the RGB data format and set the initial state of RGB interface port */
	OLED_C_command(SEPS114A_RGB_IF,0x00);                 // RGB 8bit interface
	/* Set RGB polarity */
	OLED_C_command(SEPS114A_RGB_POL,0x00);
	/* Set display mode control */
	OLED_C_command(SEPS114A_DISPLAY_MODE_CONTROL,0x80);   // SWAP:BGR, Reduce current : Normal, DC[1:0] : Normal
	/* Set MCU Interface */
	OLED_C_command(SEPS114A_CPU_IF,0x00);                 // MPU External interface mode, 8bits
	/* Set Memory Read/Write mode */
	OLED_C_command(SEPS114A_MEMORY_WRITE_READ,0x00);
	/* Set row scan direction */
	OLED_C_command(SEPS114A_ROW_SCAN_DIRECTION,0x00);     // Column : 0 --> Max, Row : 0 �--> Max
	/* Set row scan mode */
	OLED_C_command(SEPS114A_ROW_SCAN_MODE,0x00);          // Alternate scan mode
	/* Set column current */
	OLED_C_command(SEPS114A_COLUMN_CURRENT_R,0x6E);
	OLED_C_command(SEPS114A_COLUMN_CURRENT_G,0x4F);
	OLED_C_command(SEPS114A_COLUMN_CURRENT_B,0x77);
	/* Set row overlap */
	OLED_C_command(SEPS114A_ROW_OVERLAP,0x00);            // Band gap only
	/* Set discharge time */
	OLED_C_command(SEPS114A_DISCHARGE_TIME,0x01);         // Discharge time : normal discharge
	/* Set peak pulse delay */
	OLED_C_command(SEPS114A_PEAK_PULSE_DELAY,0x00);
	/* Set peak pulse width */
	OLED_C_command(SEPS114A_PEAK_PULSE_WIDTH_R,0x02);
	OLED_C_command(SEPS114A_PEAK_PULSE_WIDTH_G,0x02);
	OLED_C_command(SEPS114A_PEAK_PULSE_WIDTH_B,0x02);
	/* Set precharge current */
	OLED_C_command(SEPS114A_PRECHARGE_CURRENT_R,0x14);
	OLED_C_command(SEPS114A_PRECHARGE_CURRENT_G,0x50);
	OLED_C_command(SEPS114A_PRECHARGE_CURRENT_B,0x19);
	/* Set row scan on/off  */
	OLED_C_command(SEPS114A_ROW_SCAN_ON_OFF,0x00);        // Normal row scan
	/* Set scan off level */
	OLED_C_command(SEPS114A_SCAN_OFF_LEVEL,0x04);         // VCC_C*0.75
	/* Set memory access point */
	OLED_C_command(SEPS114A_DISPLAYSTART_X,0x00);
	OLED_C_command(SEPS114A_DISPLAYSTART_Y,0x00);
	/* Display ON */
	OLED_C_command(SEPS114A_DISPLAY_ON_OFF,0x01);
}

/* to be replaced with SSP equivalents ... see support.c
//Sekvence before writing data to memory
void DDRAM_access(){
    OLED_CS=0;
    OLED_DC=0;
    SPI3_Write(0x08);
    OLED_CS=1;
}
*/

//Set memory area(address) to write a display data
void OLED_C_MemorySize(char X1, char X2, char Y1, char Y2){
    OLED_C_command(SEPS114A_MEM_X1,X1);
    OLED_C_command(SEPS114A_MEM_X2,X2);
    OLED_C_command(SEPS114A_MEM_Y1,Y1);
    OLED_C_command(SEPS114A_MEM_Y2,Y2);
}

// replace with SSP equivalents ... see support.c ... this is meant to be a 16-bit SPI write
//Select color
void OLED_C_Color(char colorMSB, char colorLSB ){
    OLED_C_data(colorMSB);
    OLED_C_data(colorLSB);
}


void OLED_C_Background( uint16_t * p_screen){
    unsigned i,j,k;
    u_pixel_16b	pixel;
    
    OLED_C_command(0x1D,0x02);                //Set Memory Read/Write mode

    // let's load a logo
    OLED_C_MemorySize(0x00,0x5F,0x00,0x5F);
    	DDRAM_access();
        for(j=0;j<9216;j++) {
        	pixel.w = p_screen[j];
        	OLED_C_Color(pixel.b[1], pixel.b[0]);
        }
    
 }

void main_oledc_demo(){
      uint8_t i;
      uint8_t loop=0;

      InitMCU();
/* to be replaced with SSP equivalents ... see support.c
      UART1_Init(56000);
*/
      OLED_C_Init();

     while(1){

    	 switch (loop & 0x01) {
    	 	 case 0:
    	         OLED_C_Background( (uint16_t *) &epdScreenData[0] );
    		 	 break;
    	 	 case 1:
    	         OLED_C_Background( (uint16_t *) &discboardsScreenData[0] );
    		 	 break;
    	 	 default:
    		 	 break;
    	 };

         for (i=0;i<6;i++) {
        	 OLED_C_command(SEPS114A_SCREEN_SAVER_MODE,i);
        	 OLED_C_command(SEPS114A_SCREEN_SAVER_CONTEROL,0x88);
        	 delay_ms(1000);
        	 OLED_C_command(SEPS114A_SCREEN_SAVER_CONTEROL,0x00);
         }
         delay_ms(2000);
         loop++;
      }
}
