/*****************************************************************************
 * Copyright (C) 2015 by Embedded Product Design, LLC                        *
 * Ed Strehle <edstrehle@emprodesign.com>                                    *
 *                                                                           *
 * PROJECT NAME:         DBSK_oledCclick_demo                                *
 * PROJECT DESCRIPTION:                                                      *
 * Display multiple logos on a 96x96pixel screen with purchased Click board  *
 * - This project demonstrates the ability to integrate example code to      *
 *     drive a purchased "Click" board.                                      *
 * - Files "Oled.c/.h" were imported from MikroElektronika.                  *
 * - IO functions were commented-out in the supplied code and replaced with  *
 *     SSP equivalents in support.c/.h.                                      *
 * - screens.c/.h include data to load 96x96 24-bit bitmaps into the LCD.    *
 *                                                                           *
 * TARGET CONFIGURATION:                                                     *
 *     DiscBoards Processor module (S7G2) Rev A                              *
 *     DiscBoards Application module Rev A                                   *
 *     MikroElektronika Oled-C Click module (w/SEPS114A LCD controller)      *
 *                                                                           *
 * BUILD ENVIRONMENT:                                                        *
 *     Compiler:        Renesas Synergy SSP v1.0.0                           *
 *     SSP Blocks used: HAL, GPIO, SPI, external IRQ , subclock              *
 *     Customizations:                                                       *
 *         - Application Modules need P008 tied to P000 (P6pin3 to P9pin1)   *
 *             OLED-C click uses the MikroBus AN pin as a GPIO.  Synergy     *
 *             pin P000 (assigned to the AN pin) is input-only.              *
 *         - SWO pin not used in Pin Configurator (ignore error)             *
 *                                                                           *
 * FILENAME: hal_entry.c                                                     *
 * FILE DESCRIPTION:  Calls the main() function from the imported code       *
 *                                                                           *
 * HISTORY:                                                                  *
 * Date          By               Description                                *
 * 2015-10-09    EPD/Ed Strehle   v1.00 release for Renesas DevCon 2015      *
 * 2015-10-23    EPD/Ed Strehle   v1.1.0 update for SSP v1.0.0 ...           *
 *                                    replaced Avnet logo w/DiscBoards       *
 *                                                                           *
 * NOTES:                                                                    *
 * 1) Links:                                                                 *
 *      http://www.discboards.org                                            *
 *      http://www.mikroe.com/click/oled-c/                                  *
 *      http://www.crystalfontz.com/controllers/Sycoam/SEPS114A/356          *
 *                                                                           *
 * KNOWN TODOs:                                                              *
 * <none>                                                                    *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
#include "hal_data.h"
#include "Oled_C.h"
#include "support.h"

void hal_entry(void) {
    main_oledc_demo();
}
