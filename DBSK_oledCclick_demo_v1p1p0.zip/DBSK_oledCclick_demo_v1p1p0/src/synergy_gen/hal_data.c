/* generated HAL source file - do not edit */
#include "hal_data.h"
#if SPI_ON_SCI_SPI_CALLBACK_USED_g_sci_spi0
#if defined(__ICCARM__)
#define callback_sci_spi0_WEAK_ATTRIBUTE
#pragma weak callback_sci_spi0                            = callback_sci_spi0_internal
#elif defined(__GNUC__)
#define callback_sci_spi0_WEAK_ATTRIBUTE       __attribute__ ((weak, alias("callback_sci_spi0_internal")))
#endif
void callback_sci_spi0(spi_callback_args_t * p_args) callback_sci_spi0_WEAK_ATTRIBUTE;
#endif
spi_ctrl_t g_sci_spi0_ctrl;
const spi_cfg_t g_sci_spi0_cfg =
{ .channel = 0, .operating_mode = SPI_MODE_MASTER, .clk_phase = SPI_CLK_PHASE_EDGE_EVEN, .clk_polarity =
          SPI_CLK_POLARITY_LOW,
  .mode_fault = SPI_MODE_FAULT_ERROR_DISABLE, .bit_order = SPI_BIT_ORDER_MSB_FIRST, .bitrate = 100000, .p_callback =
          callback_sci_spi0,
  .p_context = (void *) &g_sci_spi0, };
/* Instance structure to use this module. */
const spi_instance_t g_sci_spi0 =
{ .p_ctrl = &g_sci_spi0_ctrl, .p_cfg = &g_sci_spi0_cfg, .p_api = &g_spi_on_sci };

#if SPI_ON_SCI_SPI_CALLBACK_USED_g_sci_spi0
/*******************************************************************************************************************//**
 * @brief      This is a weak example callback function.  It should be overridden by defining a user callback function 
 *             with the prototype below.
 *               - void callback_sci_spi0(spi_callback_args_t * p_args)
 *
 * @param[in]  p_args  Callback arguments used to identify what caused the callback.
 **********************************************************************************************************************/
void callback_sci_spi0_internal(spi_callback_args_t * p_args)
{
    /** Do nothing. */
}
#endif
#if EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_external_irq
#if defined(__ICCARM__)
#define callback_buttonS1_WEAK_ATTRIBUTE
#pragma weak callback_buttonS1                            = callback_buttonS1_internal
#elif defined(__GNUC__)
#define callback_buttonS1_WEAK_ATTRIBUTE       __attribute__ ((weak, alias("callback_buttonS1_internal")))
#endif
void callback_buttonS1(external_irq_callback_args_t * p_args) callback_buttonS1_WEAK_ATTRIBUTE;
#endif
static external_irq_ctrl_t g_external_irq_ctrl;
static const external_irq_cfg_t g_external_irq_cfg =
{ .channel = 4, .trigger = EXTERNAL_IRQ_TRIG_FALLING, .filter_enable = false, .pclk_div = EXTERNAL_IRQ_PCLK_DIV_BY_64,
  .autostart = true, .p_callback = callback_buttonS1, .p_context = &g_external_irq, .p_extend = NULL };
/* Instance structure to use this module. */
const external_irq_instance_t g_external_irq =
{ .p_ctrl = &g_external_irq_ctrl, .p_cfg = &g_external_irq_cfg, .p_api = &g_external_irq_on_icu };

#if EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_external_irq
/*******************************************************************************************************************//**
 * @brief      This is a weak example callback function.  It should be overridden by defining a user callback function 
 *             with the prototype below.
 *               - void callback_buttonS1(external_irq_callback_args_t * p_args)
 *
 * @param[in]  p_args  Callback arguments used to identify what caused the callback.
 **********************************************************************************************************************/
void callback_buttonS1_internal(external_irq_callback_args_t * p_args)
{
    /** Do nothing. */
}
#endif
const ioport_instance_t g_ioport =
{ .p_api = &g_ioport_on_ioport, .p_cfg = NULL };
const elc_instance_t g_elc =
{ .p_api = &g_elc_on_elc, .p_cfg = NULL };
const cgc_instance_t g_cgc =
{ .p_api = &g_cgc_on_cgc, .p_cfg = NULL };
void g_hal_init(void)
{
}
