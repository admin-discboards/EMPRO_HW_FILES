/*****************************************************************************
 * Copyright (C) 2015 by Embedded Product Design, LLC                        *
 *                                                                           *
 * FILENAME: screens.h     PART OF PROJECT: DBSK_oledCclick_demo             *
 *                                                                           *
 * FILE DESCRIPTION:                                                         *
 * Point to 16-bit representations of EPD and Avnet logos.                   *
 *                                                                           *
 * HISTORY:                                                                  *
 * Date          By               Description                                *
 * 2015-10-09    Ed Strehle       Initial release for Renesas DevCon 2015    *
 * 2015-10-23    EPD/Ed Strehle   v1.1.0 update for SSP v1.0.0 ...           *
 *                                    replaced Avnet logo w/DiscBoards       *
 *                                                                           *
 * NOTES:                                                                    *
 *                                                                           *
 * KNOWN TODOs:                                                              *
 * <none>                                                                    *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
#ifndef SCREENS_H_
#define SCREENS_H_

typedef union {
	uint8_t		b[2];
	uint16_t 	w;
} u_pixel_16b;

extern const uint16_t epdScreenData[9216];
extern const uint16_t discboardsScreenData[9216];

#endif /* SCREENS_H_ */
