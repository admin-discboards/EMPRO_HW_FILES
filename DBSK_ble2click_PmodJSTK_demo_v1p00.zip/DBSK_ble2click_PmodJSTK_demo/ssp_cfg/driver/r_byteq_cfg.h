/* generated config header file - do not edit */
#ifndef R_BYTEQ_CFG_H_
#define R_BYTEQ_CFG_H_
#define BYTEQ_CFG_PARAM_CHECKING_ENABLE ((BSP_CFG_PARAM_CHECKING_ENABLE))
#endif /* R_BYTEQ_CFG_H_ */
