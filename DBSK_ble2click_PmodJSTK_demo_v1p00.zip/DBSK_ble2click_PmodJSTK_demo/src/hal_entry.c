/*****************************************************************************
 *  Copyright (C) 2015 by Embedded Product Design, LLC                       *
 *  Ed Strehle <edstrehle@emprodesign.com>                                   *
 *                                                                           *
 *  PROJECT NAME:         DBSK_ble2click_PmodJSTK_demo                       *
 *  PROJECT DESCRIPTION:                                                     *
 *  Makes a BlueTooth Low Energy (BLE) connection with an Android tablet or  *
 *  phone running the app "MLDP Terminal".  MLDP is a Private-Service
 *  created by Microchip to be similar to a serial terminal.                 *
 *  Joystick readings are sent over BLE from the DiscBoard to the Android.   *
 *  - This project demonstrates the ability to integrate example code to     *
 *      drive purchased "Click" and PMod boards.                             *
 *  - Files "ble_RN4020" were loosely-based on functions from RN4020_driver  *
 *      examples from MikroElektronika.                                      *
 *                                                                           *
 *  TARGET CONFIGURATION:                                                    *
 *      DiscBoards Processor module (S7G2) Rev A                             *
 *      DiscBoards Application module Rev A                                  *
 *      MikroElektronika BLE2 Click module (based on MicroChip RN4020)       *
 *      DigilientInc PmodJSTK (plugs into top 6 pins of PMOD connector).     *
 *                                                                           *
 *  BUILD ENVIRONMENT:                                                       *
 *      Compiler:        Renesas Synergy SSP v0.91.01                        *
 *      SSP Blocks used: HAL, GPIO, SPI, UART, AGT, external IRQ, subclock   *
 *      Customizations:                                                      *
 *          - SWO pin not used in Pin Configurator (ignore error)            *
 *                                                                           *
 *  FILENAME: hal_entry.c                                                    *
 *  FILE DESCRIPTION:  Calls the main() function from the imported code      *
 *                                                                           *
 *  HISTORY:                                                                 *
 *  Date          By           Description                                   *
 *  2015-10-09    Ed Strehle   v1.00 Initial release for Renesas DevCon 2015 *
 *                                                                           *
 *  NOTES:                                                                   *
 *  1) Links:                                                                *
 *       http://www.discboards.org                                           *
 *       http://www.mikroe.com/click/ble2/                                   *
 *       http://www.microchip.com/wwwproducts/Devices.aspx?product=RN4020    *
 *       http://ww1.microchip.com/downloads/en/DeviceDoc/MLDPTerminal8.apk   *
 *       http://www.digilentinc.com/Products/Detail.cfm?Prod=PMOD-JSTK       *
 *                                                                           *
 *  KNOWN TODOs:                                                             *
 *  <none>                                                                   *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
#include "ble_RN4020.h"
#include "hal_data.h"
#include "r_sci_spi.h"

#include <string.h>
#include "support.h"
#include "pmod_jstk.h"

// global variables
volatile char g_rx_buff[MAX_BUFFER_LEN];
volatile char g_tx_buff[MAX_BUFFER_LEN];

volatile bool 		g_ble_data_ready = false;
volatile uint8_t 	g_data_len = 0;
volatile bool 		g_tmr_flg = false;
volatile bool 		g_spi6_xfer_complete = false;

volatile bool 		g_keypressed = false;
volatile bool 		g_uart2_tx_complete = false;		// no uart tx to complete yet

volatile bool		g_ble_connected = false;

ssp_err_t init_ble2click_demo(void) {
	ssp_err_t		err;

	cgc_clock_t				my_clock;
	cgc_clock_cfg_t 		my_clock_cfg;
	cgc_system_clock_cfg_t	my_system_clock_cfg;

	// initialize key IO pin states and interrupts
		// leaves RN4020 asleep
	err = g_ioport_on_ioport.pinWrite(CLICK_L2_RST_BLE2SWAKE,    IOPORT_LEVEL_LOW);
	if (SSP_SUCCESS != err) return err;

		// puts RN4020 into CMD mode
	err = g_ioport_on_ioport.pinWrite(CLICK_R1_PWM_BLE2CMD_MLDP, IOPORT_LEVEL_LOW);
	if (SSP_SUCCESS != err) return err;

	/** open an IRQ instance, then enable it for button DBSK_BUTTON01 */
	err = g_external_irq_on_icu.open  (g_ext_irq4.p_ctrl, g_ext_irq4.p_cfg);
	if (SSP_SUCCESS != err) return err;
	err = g_external_irq_on_icu.enable(g_ext_irq4.p_ctrl);
	if (SSP_SUCCESS != err) return err;

	/** open an IRQ instance, then enable it for input CLICK_L1_AN_BLE2CONN */
	err = g_external_irq_on_icu.open  (g_ext_irq6.p_ctrl, g_ext_irq6.p_cfg);
	if (SSP_SUCCESS != err) return err;
	err = g_external_irq_on_icu.enable(g_ext_irq6.p_ctrl);
	if (SSP_SUCCESS != err) return err;

	// open the UART ... recall commenting out "expect_rdlen=0" in r_sci_uart_rxi_common() to make this work
	err = g_uart_on_sci.open  (g_uart2.p_ctrl, g_uart2.p_cfg );
	g_uart2.p_ctrl->expect_rdlen = 1;		// prime r_sci_uart_rxi_common() for next byte
	if (SSP_SUCCESS != err) return err;

	// turn on sub-clock for AGT ... SSP doesn't turn on automatically as of 0.91.01
	err = g_cgc_on_cgc.systemClockGet(&my_clock, &my_system_clock_cfg);
	if (SSP_SUCCESS != err) return err;

	err = g_cgc_on_cgc.clockStart(CGC_CLOCK_SUBCLOCK, &my_clock_cfg );
	if (SSP_SUCCESS != err) return err;

	// added delay for subclock to stabilize.  A/O 0.91.01 can't check with R_CGC_ClockCheck()
	R_BSP_SoftwareDelay(250, BSP_DELAY_UNITS_MILLISECONDS);  // spins the processor

	// open and start the AGT
	err = g_timer_on_agt.open (g_timer.p_ctrl, g_timer.p_cfg);
	if (SSP_SUCCESS != err) return err;

	err = g_timer_on_agt.start(g_timer.p_ctrl);
	if (SSP_SUCCESS != err) return err;

	// open and start SPI instance for joystick.
	err = g_spi_on_sci.open( g_sci_spi6.p_ctrl, g_sci_spi6.p_cfg);
	if (SSP_SUCCESS != err) return err;

	g_spi6_xfer_complete = false;

#define INIT_BLE
#ifdef INIT_BLE
	init_RN4020_BLE();
	R_BSP_SoftwareDelay(2000, BSP_DELAY_UNITS_MICROSECONDS);  // spins the processor
#else
	err = g_ioport_on_ioport.pinWrite(CLICK_L2_RST_BLE2SWAKE, IOPORT_LEVEL_HIGH);
	byteq_ctrl_t * p_byteq = (byteq_ctrl_t *) g_uart2.p_cfg->p_rx_que_ctrl;
	wait_response("CMD");
#endif

	return err;
}


void hal_entry(void) {
	ssp_err_t 	err = SSP_SUCCESS;
	uint8_t 	update_count = 0;

	err = init_ble2click_demo();

	err = wait_for_BLE_connection();

	err = set_RN4020_MLDPmode();

	while (1) {
		if (g_ble_data_ready) {
			// received messages come here and are looped back
			strcpy((char *) g_tx_buff, (char *) g_rx_buff);
    		flush_rx_buff();

    		uart2_send_text((char *) g_tx_buff);
    		uart2_send_text("\r\n");
		}
		else {
			// every 5sec increment counter and send on BLE
			if (g_tmr_flg) {
				g_tmr_flg = false;
				update_count++;

				g_jstk_ledcmds.members.ledcmd = (update_count & 0x03) | PMODJSTK_LEDCMD_DEF;

				g_spi6_xfer_complete = false;
				err = g_ioport_on_ioport.pinWrite(PMOD2A_01_SS, IOPORT_LEVEL_LOW);
				R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MICROSECONDS);  // spins the processor
				g_spi_on_sci.writeRead(g_sci_spi6.p_ctrl, (void *)&g_jstk_ledcmds, (void *)&g_jstk_readbytes, sizeof(g_jstk_ledcmds),SPI_BIT_WIDTH_8_BITS);
				while (!g_spi6_xfer_complete);
				R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MICROSECONDS);  // spins the processor
				err = g_ioport_on_ioport.pinWrite(PMOD2A_01_SS, IOPORT_LEVEL_HIGH);

				// if BLE connected send joystick info
				if (g_ble_connected) {
					send_BLE_byte_ascii(update_count);
					uart2_send_text("-> X:");
					send_BLE_uint16_ascii(g_jstk_readbytes.members.x_rdg);
					uart2_send_text("-> Y:");
					send_BLE_uint16_ascii(g_jstk_readbytes.members.y_rdg);
					uart2_send_text(" SW ");
					send_BLE_byte_ascii(g_jstk_readbytes.members.buttons);
					uart2_send_text("\r\n");
				}
			}
		}
	} /* while 1 */

}


// if "button" is pressed this function sets a flag high ... flag is cleared in hal_entry()
// triggered by IRQ4, currently assigned to P111
void callback_dbskButtonS1 (external_irq_callback_args_t * p_args) {
	static ioport_level_t pinlevel;

	if (!g_keypressed) {
		g_ioport_on_ioport.pinRead( DBSK_BUTTON01, &pinlevel );

		if (IOPORT_LEVEL_LOW == pinlevel) {
			g_keypressed = true;
		}
	}

}

// when RN4020 CLICK_L1_AN_BLE2CONN pin state changes this function sets a flag
// don't write the flag anywhere else!
void callback_dbskPinP000 (external_irq_callback_args_t * p_args) {
	static ioport_level_t pinlevel;

	g_ioport_on_ioport.pinRead( CLICK_L1_AN_BLE2CONN, &pinlevel );
	g_ble_connected = (bool) pinlevel;
}


// continuous timer set to callback every 5 seconds
void callback_g_timer(timer_callback_args_t * p_args) {
	g_tmr_flg = true;
}


void callback_sci_spi6(spi_callback_args_t * p_args) {
	if (p_args->event == SPI_EVENT_TRANSFER_COMPLETE) {
		g_spi6_xfer_complete = true;

	}
}


// explicitly shown here to override the WEAK callback ... empty for now
void callback_uart2(uart_callback_args_t * p_args) {
	ssp_err_t err = SSP_SUCCESS;
	byteq_ctrl_t * p_byteq;
	uint8_t i;

	if (UART_EVENT_TX_COMPLETE == p_args->event) {
		g_uart2_tx_complete = true;
	}

	if (UART_EVENT_RX_COMPLETE == p_args->event) {
		err = g_uart_on_sci.read (g_uart2.p_ctrl, (char *) &g_rx_buff[g_data_len], 1 );
		if (SSP_SUCCESS != err ) {
			g_data_len = 0;
			return;
		}

		if (ASCII_LF == g_rx_buff[g_data_len]) {
			g_rx_buff[g_data_len] = 0;		// null-terminate the string
			g_ble_data_ready = true;
		}
		else {
			g_data_len++;
		}

		g_uart2.p_ctrl->expect_rdlen = 1;		// prime r_sci_uart_rxi_common() for next byte
	}	/* UART_EVENT_RX_COMPLETE */
}
