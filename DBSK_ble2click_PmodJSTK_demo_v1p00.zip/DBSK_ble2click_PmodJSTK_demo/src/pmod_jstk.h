/*****************************************************************************
 *  Copyright (C) 2015 by Embedded Product Design, LLC                       *
 *                                                                           *
 *  FILENAME: pmod_jstk.h    PART OF PROJECT: DBSK_ble2click_PmodJSTK_demo   *
 *                                                                           *
 *  FILE DESCRIPTION:                                                        *
 *  Declarations supporting PmodJSTK functionality                           *
 *                                                                           *
 *  HISTORY:                                                                 *
 *  Date          By           Description                                   *
 *  2015-10-09    Ed Strehle   Initial release for Renesas DevCon 2015       *
 *                                                                           *
 *  NOTES:                                                                   *
 *                                                                           *
 *  KNOWN TODOs:                                                             *
 *  <none>                                                                   *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
#ifndef PMOD_JSTK_H_
#define PMOD_JSTK_H_

#include "hal_data.h"

#define PMODJSTK_LEDCMD_LED1 	0x01
#define PMODJSTK_LEDCMD_LED2 	0x02
#define PMODJSTK_LEDCMD_DEF 	0x80

#define PMODJSTK_JSTK_DEF 		0x0200

#define PMODJSTK_BTN1 			0x02
#define PMODJSTK_BTN2 			0x04
#define PMODJSTK_JSTKBTN		0x01
#define PMODJSTK_BTN_DEF 		0x00

// bytes read from the PmodJSTK during the SPI transfer
typedef union {
	uint8_t		miso_a[5];
	struct {
		uint8_t		x_rdg_low;
		uint8_t		x_rdg_high;
		uint8_t		y_rdg_low;
		uint8_t		y_rdg_high;
		uint8_t		buttons;
	} miso_b;
	struct {
		uint16_t	x_rdg;
		uint16_t	y_rdg;
		uint8_t		buttons;
	} members;
} u_pmodjstk_misobytes;

// command bytes (including unused "dummy" bytes) written to the
// PmodJSTK during the SPI transfer
typedef union {
	uint8_t 	mosi_a[5];
	struct {
		uint8_t		ledcmd;
		uint8_t		dummy[4];
	} members;
} u_pmodjstk_mosibytes;

// variables to share globally
extern u_pmodjstk_misobytes g_jstk_readbytes;
extern u_pmodjstk_mosibytes g_jstk_ledcmds;

// function prototypes
void pmodjstk_set_leds(uint8_t	ledcmd);
void pmodjstk_get_info(u_pmodjstk_mosibytes info);

#endif /* PMOD_JSTK_H_ */
