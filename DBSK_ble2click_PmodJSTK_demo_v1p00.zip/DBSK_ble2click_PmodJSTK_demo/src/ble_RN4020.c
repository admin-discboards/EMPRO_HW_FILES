/*****************************************************************************
 *  Copyright (C) 2015 by Embedded Product Design, LLC                       *
 *                                                                           *
 *  FILENAME: ble_RN4020.c    PART OF PROJECT: DBSK_ble2click_PmodJSTK_demo  *
 *                                                                           *
 *  FILE DESCRIPTION:                                                        *
 *  Code supporting the RN4020 module for BLE usage.  Content leverages      *
 *  code from MikroElektronika's "RN4020_driver.c/.h files.                  *
 *      examples from MikroElektronika.                                      *
 *                                                                           *
 *  HISTORY:                                                                 *
 *  Date          By           Description                                   *
 *  2015-10-09    Ed Strehle   Initial release for Renesas DevCon 2015       *
 *                                                                           *
 *  NOTES:                                                                   *
 *                                                                           *
 *  KNOWN TODOs:                                                             *
 *  <none>                                                                   *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
#include <string.h>
#include "hal_data.h"
#include "support.h"
#include "ble_RN4020.h"

ssp_err_t wait_for_BLE_connection() {
	ssp_err_t	err;

	err = g_ioport_on_ioport.pinRead(CLICK_L1_AN_BLE2CONN, (ioport_level_t *)&g_ble_connected);
	if (SSP_SUCCESS != err) return err;

	while (g_ble_connected) {
		flush_rx_buff();
		err = g_ioport_on_ioport.pinRead(CLICK_L1_AN_BLE2CONN, (ioport_level_t *)&g_ble_connected);
		if (SSP_SUCCESS != err) return err;
	}
	while ( !wait_for_response("Connected") );

	return err;
}


void send_BLE_byte_ascii(uint8_t value) {
	char txt[3];
	char *ptr;

	byte_to_ascii_hex(value, txt);

	ptr = (char *) g_tx_buff;
	*ptr++ = txt[1];
	*ptr++ = txt[0];
	*ptr++ = 0;

	uart2_send_text((char *)g_tx_buff);
	memset((char *) g_tx_buff, 0x00, 3);
}


void send_BLE_uint16_ascii(uint16_t value) {
	char txt[5];
	char *ptr;

	word_to_ascii_hex(value, txt);

	ptr = (char *) g_tx_buff;
	*ptr++ = txt[3];
	*ptr++ = txt[2];
	*ptr++ = txt[1];
	*ptr++ = txt[0];
	*ptr++ = 0;

	uart2_send_text((char *)g_tx_buff);
	memset((char *) g_tx_buff, 0x00, 5);
}


bool wait_for_response(char *value) {
	bool result = false;

	while( !g_ble_data_ready );
	if( strstr((char *)g_rx_buff, value) ) {
		result = true;
	}
	flush_rx_buff();

	return result;
}


// set MLDP mode can only after connected ... no response when MLDP entered unless with "I"
ssp_err_t set_RN4020_MLDPmode(void) {
	ssp_err_t err = SSP_SUCCESS;

#define MLDP_W_IOPIN
#ifdef	MLDP_W_IOPIN
	err = g_ioport_on_ioport.pinWrite(CLICK_R1_PWM_BLE2CMD_MLDP, IOPORT_LEVEL_HIGH);
#else
	UART_Write_Line("I"); 			// use commands to set MLDP mode
	while ( !wait_for_response("MLDP") );
#endif

	return err;
}


// set CMD mode
ssp_err_t set_RN4020_CMDmode(void) {
	ssp_err_t err = SSP_SUCCESS;
	ioport_level_t pinlevel;

	err = g_ioport_on_ioport.pinWrite(CLICK_R1_PWM_BLE2CMD_MLDP, IOPORT_LEVEL_LOW);

	err = g_ioport_on_ioport.pinRead( CLICK_L2_RST_BLE2SWAKE, &pinlevel );
	if (IOPORT_LEVEL_HIGH == pinlevel) {
		while ( !wait_for_response("CMD") );
	}

	return err;
}


//Initialize RN4020 module ... rewrite from RN4020_Driver.c with TFT support removed
void init_RN4020_BLE() {
	ssp_err_t err;

	err = g_ioport_on_ioport.pinWrite(CLICK_L2_RST_BLE2SWAKE, IOPORT_LEVEL_HIGH);
	while ( !wait_for_response("CMD") );
	R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MICROSECONDS);  // spins the processor


	// Reset RN4020 to factory settings
	uart2_send_text("SF,1\r\n");
	while ( !wait_for_response("AOK") );
	R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MICROSECONDS);  // spins the processor

	// Set name EmPro_DEMO
	uart2_send_text("S-,EmPro_Demo\r\n");
	while ( !wait_for_response("AOK") );
	R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MICROSECONDS);  // spins the processor

	// set server services ... custom user profile
	uart2_send_text("SS,E0000001\r\n");                                               //Battery
	while ( !wait_for_response("AOK") );
	R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MICROSECONDS);  // spins the processor

	// set peripheral services ... auto-advertise, MLDP, auto-enter MLDP
	uart2_send_text("SR,30000800\r\n");
	while ( !wait_for_response("AOK") );
	R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MICROSECONDS);  // spins the processor

	// reboot the RN4020 so setting changes can take
	uart2_send_text("R,1\r\n");
	while ( !wait_for_response("Reboot") );
	while ( !wait_for_response("CMD") );	// expected after reboot
}
