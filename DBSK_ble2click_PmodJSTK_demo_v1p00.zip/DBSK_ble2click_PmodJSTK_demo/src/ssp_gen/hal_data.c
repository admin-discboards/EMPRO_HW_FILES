/* generated HAL source file - do not edit */
#include "hal_data.h"
#if SPI_ON_SCI_SPI_CALLBACK_USED_g_sci_spi6
#if defined(__ICCARM__)
#define callback_sci_spi6_WEAK_ATTRIBUTE
#pragma weak callback_sci_spi6                            = callback_sci_spi6_internal
#elif defined(__GNUC__)
#define callback_sci_spi6_WEAK_ATTRIBUTE       __attribute__ ((weak, alias("callback_sci_spi6_internal")))
#endif
void callback_sci_spi6(spi_callback_args_t * p_args) callback_sci_spi6_WEAK_ATTRIBUTE;
#endif
spi_ctrl_t g_sci_spi6_ctrl;
const spi_cfg_t g_sci_spi6_cfg = { .channel = 6, .operating_mode =
		SPI_MODE_MASTER, .clk_phase = SPI_CLK_PHASE_EDGE_ODD, .clk_polarity =
		SPI_CLK_POLARITY_LOW, .mode_fault = SPI_MODE_FAULT_ERROR_DISABLE,
		.bit_order = SPI_BIT_ORDER_MSB_FIRST, .bitrate = 50000, .p_callback =
				callback_sci_spi6, .p_context = (void *) &g_sci_spi6, };
/* Instance structure to use this module. */
const spi_instance_t g_sci_spi6 = { .p_ctrl = &g_sci_spi6_ctrl, .p_cfg =
		&g_sci_spi6_cfg, .p_api = &g_spi_on_sci };

#if SPI_ON_SCI_SPI_CALLBACK_USED_g_sci_spi6
/*******************************************************************************************************************//**
 * @brief      This is a weak example callback function.  It should be overridden by defining a user callback function 
 *             with the prototype below.
 *               - void callback_sci_spi6(spi_callback_args_t * p_args)
 *
 * @param[in]  p_args  Callback arguments used to identify what caused the callback.
 **********************************************************************************************************************/
void callback_sci_spi6_internal(spi_callback_args_t * p_args)
{
	/** Do nothing. */
}
#endif
#if EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_ext_irq6
#if defined(__ICCARM__)
#define callback_dbskPinP000_WEAK_ATTRIBUTE
#pragma weak callback_dbskPinP000                            = callback_dbskPinP000_internal
#elif defined(__GNUC__)
#define callback_dbskPinP000_WEAK_ATTRIBUTE       __attribute__ ((weak, alias("callback_dbskPinP000_internal")))
#endif
void callback_dbskPinP000(external_irq_callback_args_t * p_args) callback_dbskPinP000_WEAK_ATTRIBUTE;
#endif
static external_irq_ctrl_t g_ext_irq6_ctrl;
static const external_irq_cfg_t g_ext_irq6_cfg = { .channel = 6, .trigger =
		EXTERNAL_IRQ_TRIG_BOTH_EDGE, .filter_enable = false, .pclk_div =
		EXTERNAL_IRQ_PCLK_DIV_BY_64, .autostart = true, .p_callback =
		callback_dbskPinP000, .p_context = &g_ext_irq6, .p_extend = NULL };
/* Instance structure to use this module. */
const external_irq_instance_t g_ext_irq6 = { .p_ctrl = &g_ext_irq6_ctrl,
		.p_cfg = &g_ext_irq6_cfg, .p_api = &g_external_irq_on_icu };

#if EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_ext_irq6
/*******************************************************************************************************************//**
 * @brief      This is a weak example callback function.  It should be overridden by defining a user callback function 
 *             with the prototype below.
 *               - void callback_dbskPinP000(external_irq_callback_args_t * p_args)
 *
 * @param[in]  p_args  Callback arguments used to identify what caused the callback.
 **********************************************************************************************************************/
void callback_dbskPinP000_internal(external_irq_callback_args_t * p_args)
{
	/** Do nothing. */
}
#endif
#if TIMER_ON_AGT_CALLBACK_USED_g_timer
#if defined(__ICCARM__)
#define callback_g_timer_WEAK_ATTRIBUTE
#pragma weak callback_g_timer                            = callback_g_timer_internal
#elif defined(__GNUC__)
#define callback_g_timer_WEAK_ATTRIBUTE       __attribute__ ((weak, alias("callback_g_timer_internal")))
#endif
void callback_g_timer(timer_callback_args_t * p_args) callback_g_timer_WEAK_ATTRIBUTE;
#endif

static timer_ctrl_t g_timer_ctrl;
static const timer_on_agt_cfg_t g_timer_extend = { .count_source =
		AGT_CLOCK_FSUB, .agto_output_enabled = false, .agtio_output_enabled =
		false, .output_inverted = false, };
static const timer_cfg_t g_timer_cfg = { .mode = TIMER_MODE_PERIODIC, .period =
		1, .unit = TIMER_UNIT_PERIOD_SEC, .channel = 0, .autostart = true,
		.p_callback = callback_g_timer, .p_context = &g_timer, .p_extend =
				&g_timer_extend };
/* Instance structure to use this module. */
const timer_instance_t g_timer = { .p_ctrl = &g_timer_ctrl, .p_cfg =
		&g_timer_cfg, .p_api = &g_timer_on_agt };

#if TIMER_ON_AGT_CALLBACK_USED_g_timer
/*******************************************************************************************************************//**
 * @brief      This is a weak example callback function.  It should be overridden by defining a user callback function 
 *             with the prototype below.
 *               - void callback_g_timer(timer_callback_args_t * p_args)
 *
 * @param[in]  p_args  Callback arguments used to identify what caused the callback.
 **********************************************************************************************************************/
void callback_g_timer_internal(timer_callback_args_t * p_args)
{
	/** Do nothing. */
}
#endif
#if UART_ON_SCI_UART_CALLBACK_USED_g_uart2
#if defined(__ICCARM__)
#define callback_uart2_WEAK_ATTRIBUTE
#pragma weak callback_uart2  = callback_uart2_internal
#elif defined(__GNUC__)
#define callback_uart2_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("callback_uart2_internal")))
#endif
void callback_uart2(uart_callback_args_t * p_args) callback_uart2_WEAK_ATTRIBUTE;
#endif

uart_ctrl_t g_uart2_ctrl;
#if (64)
static uint8_t g_uart2_tx_que[64];
static byteq_ctrl_t g_uart2_tx_que_ctrl;
#else
#endif
#if (64)
static uint8_t g_uart2_rx_que[64];
static byteq_ctrl_t g_uart2_rx_que_ctrl;
#else
#endif

/** UART extended configuration for UARTonSCI HAL driver */
const uart_on_sci_cfg_t uart_sci2_cfg_t = { .clk_src = SCI_CLK_SRC_INT,
		.baudclk_out = false, .rx_edge_start = true, .noisecancel_en = false,
		.p_extpin_ctrl = (void *) NULL };

/** UART interface configuration */
const uart_cfg_t g_uart2_cfg = { .channel = 2, .baud_rate = 115200, .data_bits =
		UART_DATA_BITS_8, .parity = UART_PARITY_OFF, .stop_bits =
		UART_STOP_BITS_1, .ctsrts_en = false, .p_callback =
		(void *) callback_uart2, .p_context = (void *) &g_uart2, .p_extend =
		(void *) &uart_sci2_cfg_t,
#if (64)
		.p_tx_que = g_uart2_tx_que, .tx_que_len = 64, .p_tx_que_ctrl =
				(void *) &g_uart2_tx_que_ctrl,
#else
		.p_tx_que = NULL,
		.tx_que_len = 0,
		.p_tx_que_ctrl = NULL,
#endif
#if (64)
		.p_rx_que = g_uart2_rx_que, .rx_que_len = 64, .p_rx_que_ctrl =
				(void *) &g_uart2_rx_que_ctrl
#else
		.p_rx_que = NULL,
		.rx_que_len = 0,
		.p_rx_que_ctrl = NULL
#endif
	};

/* Instance structure to use this module. */
const uart_instance_t g_uart2 = { .p_ctrl = &g_uart2_ctrl,
		.p_cfg = &g_uart2_cfg, .p_api = &g_uart_on_sci };

#if UART_ON_SCI_UART_CALLBACK_USED_g_uart2
/*******************************************************************************************************************//**
 * @brief      This is a weak example callback function.  It should be overridden by defining a user callback function 
 *             with the prototype below.
 *               - void callback_uart2(uart_callback_args_t * p_args)
 *
 * @param[in]  p_args  Callback arguments used to identify what caused the callback.
 **********************************************************************************************************************/
void callback_uart2_internal(uart_callback_args_t * p_args)
{
	/** Do nothing. */
}
#endif
#if EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_ext_irq4
#if defined(__ICCARM__)
#define callback_dbskButtonS1_WEAK_ATTRIBUTE
#pragma weak callback_dbskButtonS1                            = callback_dbskButtonS1_internal
#elif defined(__GNUC__)
#define callback_dbskButtonS1_WEAK_ATTRIBUTE       __attribute__ ((weak, alias("callback_dbskButtonS1_internal")))
#endif
void callback_dbskButtonS1(external_irq_callback_args_t * p_args) callback_dbskButtonS1_WEAK_ATTRIBUTE;
#endif
static external_irq_ctrl_t g_ext_irq4_ctrl;
static const external_irq_cfg_t g_ext_irq4_cfg = { .channel = 4, .trigger =
		EXTERNAL_IRQ_TRIG_RISING, .filter_enable = false, .pclk_div =
		EXTERNAL_IRQ_PCLK_DIV_BY_64, .autostart = true, .p_callback =
		callback_dbskButtonS1, .p_context = &g_ext_irq4, .p_extend = NULL };
/* Instance structure to use this module. */
const external_irq_instance_t g_ext_irq4 = { .p_ctrl = &g_ext_irq4_ctrl,
		.p_cfg = &g_ext_irq4_cfg, .p_api = &g_external_irq_on_icu };

#if EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_ext_irq4
/*******************************************************************************************************************//**
 * @brief      This is a weak example callback function.  It should be overridden by defining a user callback function 
 *             with the prototype below.
 *               - void callback_dbskButtonS1(external_irq_callback_args_t * p_args)
 *
 * @param[in]  p_args  Callback arguments used to identify what caused the callback.
 **********************************************************************************************************************/
void callback_dbskButtonS1_internal(external_irq_callback_args_t * p_args)
{
	/** Do nothing. */
}
#endif
const ioport_instance_t g_ioport =
		{ .p_api = &g_ioport_on_ioport, .p_cfg = NULL };
const elc_instance_t g_elc = { .p_api = &g_elc_on_elc, .p_cfg = NULL };
void g_hal_init(void) {
}
