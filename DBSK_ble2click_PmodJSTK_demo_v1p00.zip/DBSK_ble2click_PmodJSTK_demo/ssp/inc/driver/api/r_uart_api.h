/***********************************************************************************************************************
 * Copyright [2015] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
 * display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
 * purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
 * SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
 * NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
 * OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
 * be subject to different terms.
 **********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : r_uart_api.h
 * Description  : UART Shared Interface definition
 ***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *           19.12.2014 1.00    Initial Release.
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @ingroup Interface_Library
 * @defgroup UART_API UART Interface
 * @brief Interface for UART peripheral API
 *
 * @section UART_INTERFACE_SUMMARY Summary
 * The UART interface provides common APIs for UART HAL drivers. The UART interface supports the following features:
 * - Full-duplex UART communication
 * - Generic UART parameter setting
 * - Interrupt driven transmit/receive processing
 * - Callback function with returned event code
 * - Runtime baud-rate change
 * - Hardware resource locking during a transaction
 * - CTS/RTS hardware flow control support (with an associated IOPORT pin)
 * - Circular buffer support
 * - Runtime Transmit/Receive circular buffer flushing
 *
 * Implemented as:
 * - @ref UARTonSCI
 * - @ref UARTonUSBX
 * @{
 **********************************************************************************************************************/

#ifndef DRV_UART_API_H
#define DRV_UART_API_H

/***********************************************************************************************************************
 * Includes
 **********************************************************************************************************************/
/* Includes board and MCU related header files. */
#include "bsp_api.h"
#include "r_byteq.h"

/**********************************************************************************************************************
 * Macro definitions
 **********************************************************************************************************************/
#define UART_API_VERSION_MAJOR (01)
#define UART_API_VERSION_MINOR (00)

/**********************************************************************************************************************
 * Typedef definitions
 **********************************************************************************************************************/
/** UART Event codes */
typedef enum e_sf_event
{
    UART_EVENT_RX_COMPLETE        = (1 << 0),         ///< Receive complete event
    UART_EVENT_TX_COMPLETE        = (1 << 1),         ///< Transmit complete event
    UART_EVENT_ERR_PARITY         = (1 << 2),         ///< Parity error event
    UART_EVENT_ERR_FRAMING        = (1 << 3),         ///< Mode fault error event
    UART_EVENT_BREAK_DETECT       = (1 << 4),         ///< Break detect error event
    UART_EVENT_ERR_OVERFLOW       = (1 << 5),         ///< FIFO Overflow error event
    UART_EVENT_ERR_RXBUF_OVERFLOW = (1 << 6),         ///< Receive buffer overflow error event
} uart_event_t;

/* UART Data bit length definition */
typedef enum e_uart_data_bits
{
    UART_DATA_BITS_8,                       ///< Data bits 8-bit
    UART_DATA_BITS_7,                       ///< Data bits 7-bit
    UART_DATA_BITS_9                        ///< Data bits 9-bit
} uart_data_bits_t;

/** UART Parity definition */
typedef enum e_uart_parity
{
    UART_PARITY_OFF,                        ///< No parity
    UART_PARITY_ODD,                        ///< Odd parity
    UART_PARITY_EVEN                        ///< Even parity
} uart_parity_t;

/** UART Stop bits definition */
typedef enum e_uart_stop_bits
{
    UART_STOP_BITS_1,                       ///< Stop bit 1-bit
    UART_STOP_BITS_2                        ///< Stop bits 2-bit
} uart_stop_bits_t;

/** UART Callback parameter definition */
typedef struct st_uart_callback_arg
{
    uint32_t      channel;                  ///< Device channel number
    uart_event_t  event;                    ///< Event code
    uint32_t      data;                     ///< General purpose data storage
    void          * p_context;              ///< Context provided to user during callback
} uart_callback_args_t;

/** UART Configuration */
typedef struct st_uart_cfg
{
    /* UART generic configuration */
    uint32_t          channel;              ///< Select a channel corresponding to the channel number of the hardware.
    uint32_t          baud_rate;            ///< Baud rate, i.e. 9600, 19200, 115200
    uart_data_bits_t  data_bits;            ///< Data bit length (8 or 7 or 9)
    uart_parity_t     parity;               ///< Parity type (none or odd or even)
    uart_stop_bits_t  stop_bits;            ///< Stop bit length (1 or 2)
    bool              ctsrts_en;            ///< CTS/RTS hardware flow control enable

    /* Circular buffer configuration */
    uint8_t   * p_tx_que;                   ///< Transmit buffer address
    uint8_t   * p_rx_que;                   ///< Receive buffer address
    uint32_t  tx_que_len;                   ///< Transmit buffer length
    uint32_t  rx_que_len;                   ///< Receive buffer length
    void      * p_tx_que_ctrl;              ///< Transmit buffer handle
    void      * p_rx_que_ctrl;              ///< Receive buffer handle

    /* Configuration for UART Event processing */
    void (* p_callback)(uart_callback_args_t * p_args); ///< Pointer to callback function
    void  * p_context;                                  ///< User defined context passed into callback function

    /* Pointer to UART peripheral specific configuration */
    void  * p_extend;                       ///< UART hardware dependent configuration
} uart_cfg_t;

/** UART Control block */
typedef struct st_uart_ctrl
{
    /* Parameters to control UART peripheral device */
    uint32_t  channel;                      ///< Channel number
    uint32_t  expect_rdlen;                 ///< Expected read data length

    /* Parameters to control circular buffer */
    /** transmit data */
    union
    {
        byteq_ctrl_t  * p_que;              ///< Handle for a transmit circular buffer (used in non-zero copy mode)
        uint8_t       * p_buf;              ///< Buffer address (used in zero copy mode)
    }  u_tx_data;

    /** receive data */
    union
    {
        byteq_ctrl_t  * p_que;              ///< Handle for a transmit circular buffer (used in non-zero copy mode)
        uint8_t       * p_buf;              ///< Buffer address (used in zero copy mode)
    }  u_rx_data;

    /* Parameters to process UART Event */
    void (* p_callback)(uart_callback_args_t * p_args); ///< Pointer to callback function
    void  * p_context;                                  ///< Pointer to the higher level device context
                                                        //   (e.g. sf_uart_ctrl_t type data )
} uart_ctrl_t;

/** Shared Interface definition for UART */
typedef struct st_uart_api
{
    /** Open  UART device.
     * @par Implemented as
     * - R_SCI_UartOpen()
     * - R_USBX_UartOpen()
     *
     * @param[in,out]  p_ctrl     Pointer to the UART control block Must be declared by user. Value set here.
     * @param[in]      uart_cfg_t Pointer to UART configuration structure. All elements of this structure must be set by
     *                            user.
     */
	ssp_err_t (* open)(uart_ctrl_t * const      p_ctrl,
                       uart_cfg_t const * const p_cfg);

    /** Read from UART device.
     * @par Implemented as
     * - R_SCI_UartRead()
     * - R_USBX_UartRead()
     *
     * @param[in]   p_ctrl     Pointer to the UART control block for the channel.
     * @param[in]   p_dest     Destination address to read data from.
     * @param[in]   bytes      Read data length.
     */
    ssp_err_t (* read)(uart_ctrl_t * const   p_ctrl,
                       uint8_t const * const p_dest,
                       uint32_t const        bytes);

    /** Write to UART device.
     * @par Implemented as
     * - R_SCI_UartWrite()
     * - R_USBX_UartWrite()
     *
     * @param[in]   p_ctrl     Pointer to the UART control block.
     * @param[in]   p_src      Source address  to write data to.
     * @param[in]   bytes      Write data length.
     */
    ssp_err_t (* write)(uart_ctrl_t const * const p_ctrl,
                        uint8_t const * const     p_src,
                        uint32_t const            bytes);

    /** Change baud rate.
     * @par Implemented as
     * - R_SCI_UartBaudSet()
     * - R_USBX_UartBaudSet()
     *
     * @param[in]   p_ctrl     Pointer to the UART control block.
     * @param[in]   baudrate   Baud rate in bps.
     */
    ssp_err_t (* baudSet)(uart_ctrl_t const * const p_ctrl,
                          uint32_t const            baudrate);

    /** Flush transmit queue.
     * @par Implemented as
     * - R_SCI_UartTxFlush()
     * - R_USBX_UartTxFlush()
     *
     * @param[in]   p_ctrl     Pointer to the UART control block.
     */
    ssp_err_t (* txFlush)(uart_ctrl_t const * const p_ctrl);

    /** Flush receive queue.
     * @par Implemented as
     * - R_SCI_UartRxFlush()
     * - R_USBX_UartRxFlush()
     *
     * @param[in]   p_ctrl     Pointer to the UART control block.
     */
    ssp_err_t (* rxFlush)(uart_ctrl_t const * const p_ctrl);

    /** Close UART device.
     * @par Implemented as
     * - R_SCI_UartClose()
     * - R_USBX_UartClose()
     *
     * @param[in]   p_ctrl     Pointer to the UART control block.
     */
    ssp_err_t (* close)(uart_ctrl_t * const p_ctrl);

    /** Get version.
     * @par Implemented as
     * - R_SCI_UartVersionGet()
     * - R_USBX_UartVersionGet()
     *
     * @param[in]   p_version  Pointer to the memory to store the version information.
     */
    ssp_err_t (* versionGet)(ssp_version_t * p_version);
} uart_api_t;

/** This structure encompasses everything that is needed to use an instance of this interface. */
typedef struct st_uart_instance
{
    uart_ctrl_t       * p_ctrl;    ///< Pointer to the control structure for this instance
    uart_cfg_t  const * p_cfg;     ///< Pointer to the configuration structure for this instance
    uart_api_t  const * p_api;     ///< Pointer to the API structure for this instance
} uart_instance_t;


/** @} (end defgroup UART_API) */
#endif /* DRV_UART_API_H */
