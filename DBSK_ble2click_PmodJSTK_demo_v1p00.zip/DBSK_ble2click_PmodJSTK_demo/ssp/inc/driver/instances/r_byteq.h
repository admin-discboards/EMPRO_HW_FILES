/***********************************************************************************************************************
 * Copyright [2015] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
 * display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
 * purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
 * SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
 * NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
 * OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
 * be subject to different terms.
 **********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : r_byteq.h
 * @brief       : ByteQ module library header file.
 ***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *           19.12.2014 1.00    Initial Release.
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @ingroup HAL_Library
 * @defgroup BYTEQ BYTEQ
 * @brief Generic circular buffer software library
 *
 * @section BYTEQ_SUMMARY Summary
 * This module implements the generic circular buffer. This module can queue or de-queue 8-bit/16-bit data.
 * @{
 **********************************************************************************************************************/

#ifndef BYTEQ_H
#define BYTEQ_H

/***********************************************************************************************************************
 * Includes
 **********************************************************************************************************************/
#include "bsp_api.h"
#include "r_byteq_cfg.h"

/***********************************************************************************************************************
 * Macro definitions
 **********************************************************************************************************************/
/* Version Number of API. */
#define BYTEQ_API_VERSION_MAJOR  (1)
#define BYTEQ_API_VERSION_MINOR  (00)
#define BYTEQ_CODE_VERSION_MAJOR (1)
#define BYTEQ_CODE_VERSION_MINOR (00)

/***********************************************************************************************************************
 * Typedef definitions
 **********************************************************************************************************************/
/** Byte Queue Data Length */
typedef enum e_byteq_datalen
{
    BYTEQ_DATALEN_1BYTE  = 1,
    BYTEQ_DATALEN_2BYTES = 2
} byteq_datalen_t;

/** Byte Queue Control Block (for handle) */
typedef struct st_byteq_ctrl
{
    uint8_t   * p_buffer;       ///< Pointer to buffer
    uint8_t   data_len;         ///< Data length/each
    uint16_t  size;             ///< Buffer size
    uint16_t  count;            ///< Number data bytes in queue
    uint16_t  in_index;         ///< Index used by Put function to add data
    uint16_t  out_index;        ///< Index used by Get function to remove data
} byteq_ctrl_t;

/***********************************************************************************************************************
 * Private function prototypes
 **********************************************************************************************************************/
ssp_err_t R_BYTEQ_Open   (byteq_ctrl_t * const  p_ctrl,
                          uint8_t const * const p_buf,
                          uint16_t const        buf_size,
                          uint16_t const        data_len);

ssp_err_t     R_BYTEQ_Close  (byteq_ctrl_t * const p_ctrl);

ssp_err_t     R_BYTEQ_Put    (byteq_ctrl_t * const p_ctrl, uint16_t const byte);

ssp_err_t     R_BYTEQ_Get    (byteq_ctrl_t * const p_ctrl, void * const p_byte);

ssp_err_t     R_BYTEQ_Flush  (byteq_ctrl_t * const p_ctrl);

ssp_err_t     R_BYTEQ_Used   (byteq_ctrl_t const * const p_ctrl, uint16_t * const p_cnt);

ssp_err_t     R_BYTEQ_Unused (byteq_ctrl_t const * const p_ctrl, uint16_t * const p_cnt);

ssp_version_t R_BYTEQ_GetVersion (void);

/*******************************************************************************************************************//**
 * @} (end defgroup BYTEQ)
 **********************************************************************************************************************/

#endif /* BYTEQ_H */
