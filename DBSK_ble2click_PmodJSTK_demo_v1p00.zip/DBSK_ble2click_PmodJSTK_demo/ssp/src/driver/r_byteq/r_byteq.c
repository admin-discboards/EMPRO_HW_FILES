/***********************************************************************************************************************
 * Copyright [2015] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
 * display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
 * purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
 * SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
 * NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
 * OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
 * be subject to different terms.
 **********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : r_byteq.c
 * @brief       : ByteQ module library API definition.
 ***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *           19.12.2014 1.00    Initial Release.
 **********************************************************************************************************************/



/***********************************************************************************************************************
 * Includes
 **********************************************************************************************************************/
/* Defines for BYTEQ support */
#include "bsp_api.h"
#include "r_byteq_private.h"
#include "r_byteq.h"

/***********************************************************************************************************************
 * Macro definitions
 **********************************************************************************************************************/
#ifndef BYTEQ_ERROR_RETURN
#define BYTEQ_ERROR_RETURN(a, err) SSP_ERROR_RETURN((a), (err), module_name, &sci_uart_version)
#endif

/***********************************************************************************************************************
 * Typedef definitions
 **********************************************************************************************************************/
/** Name of module used by error logger macro */
static const char          module_name[] = "byteq";

/** Version of module */
static const ssp_version_t byteq_version =
{
    .api_version_major  = BYTEQ_API_VERSION_MAJOR,
    .api_version_minor  = BYTEQ_API_VERSION_MINOR,
    .code_version_major = BYTEQ_CODE_VERSION_MAJOR,
    .code_version_minor = BYTEQ_CODE_VERSION_MINOR
};

/***********************************************************************************************************************
 * Private function prototypes
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Private global variables
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Private Functions
 **********************************************************************************************************************/
/*******************************************************************************************************************//**
 * @addtogroup BYTEQ
 * @{
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * Initialize the ByteQ instance as specified by the arguments. If the queue is successfully created, the pointer to
 * the control block structure is returned to 'p_ctrl' which is then used as a queue ID for the other ByteQ APIs. Data
 * size can be selected from  1 byte or 2 bytes and if it is 2 bytes, the address of buffer must be aligned to 16-bit
 * boundary on memory and buffer size must be the number of power of 2.
 * @param[in,out] p_ctrl             Pointer to the queue control block (value set here).
 * @param[in]     p_buf              Pointer to the buffer.
 * @param[in]     buf_size           Buffer size in bytes.
 * @param[in]     data_len           Data length per 1 data entry. 1 or 2 bytes(per data) can be selected.
 * @retval SSP_SUCCESS               ByteQ instance is initialized successfully.
 * @retval SSP_ERR_ASSERTION         Pointer to the queue control block or the buffer is NULL.
 * @retval SSP_ERR_INVALID_ARGUMENT  Argument is not valid for parameter.
 **********************************************************************************************************************/
ssp_err_t R_BYTEQ_Open (byteq_ctrl_t * const  p_ctrl,
                        uint8_t const * const p_buf,
                        uint16_t const        buf_size,
                        uint16_t const        data_len)
{
#if (BYTEQ_CFG_PARAM_CHECKING_ENABLE)
    SSP_ASSERT(p_ctrl);
    SSP_ASSERT(p_buf);

    /* Data length check */
    BYTEQ_ERROR_RETURN(((BYTEQ_DATALEN_1BYTE == data_len) || (BYTEQ_DATALEN_2BYTES == data_len)),
                       SSP_ERR_INVALID_ARGUMENT);

    /* Buffer size check, if data length is 1byte, buffer size have to be greater than or equal to 2, if data length is
     * 2bytes,
     *  buffer size have to be greater than or equal to 4
     */
    BYTEQ_ERROR_RETURN((((BYTEQ_DATALEN_1BYTE == data_len) &&
                         (buf_size >= 2)) || ((BYTEQ_DATALEN_2BYTES == data_len) && (buf_size >= 4))),
                       SSP_ERR_INVALID_ARGUMENT);

    /* Buffer size is not matched to data length */
    if (BYTEQ_DATALEN_2BYTES == data_len)
    {
        BYTEQ_ERROR_RETURN((0 == (((uint32_t) p_buf) % 2)), SSP_ERR_INVALID_ARGUMENT);
        BYTEQ_ERROR_RETURN((0 == (buf_size % 2)), SSP_ERR_INVALID_ARGUMENT);
    }

#endif /* if (BYTEQ_CFG_PARAM_CHECKING_ENABLE) */

    p_ctrl->p_buffer  = (uint8_t *) p_buf;
    p_ctrl->data_len  = data_len;
    p_ctrl->size      = buf_size;
    p_ctrl->count     = 0;
    p_ctrl->in_index  = 0;
    p_ctrl->out_index = 0;

    return SSP_SUCCESS;
}  /* End of function R_BYTEQ_Open() */

/*******************************************************************************************************************//**
 * Queue a byte of data to the queue.
 * @param[in] p_ctrl           Pointer to the queue control block.
 * @param[in] data             Data to queue into ByteQ module.
 * @retval SSP_SUCCESS         Data queued into ByteQ module successfully.
 * @retval SSP_ERR_ASSERTION   Pointer to the queue control block is NULL.
 * @retval SSP_ERR_QUEUE_FULL  Queue is full, cannot put data into ByteQ module.
 * @note   This function does not disable/enable interrupts. The interrupts for the peripheral which uses this module
 *          have to be disabled/enabled before/after calling this routine.
 **********************************************************************************************************************/
ssp_err_t R_BYTEQ_Put (byteq_ctrl_t * const p_ctrl, uint16_t const data)
{
    void * paddr;

#if (BYTEQ_CFG_PARAM_CHECKING_ENABLE)
    SSP_ASSERT(p_ctrl);
#endif

    BYTEQ_ERROR_RETURN((p_ctrl->count < p_ctrl->size), SSP_ERR_QUEUE_FULL);    /* return if queue is full */

    /* Queue data */
    if (BYTEQ_DATALEN_1BYTE == p_ctrl->data_len)
    {
        paddr              = p_ctrl->p_buffer + p_ctrl->in_index;
        *(uint8_t *) paddr = (uint8_t) data;               /* add 1byte data */
    }
    else
    {
        paddr               = p_ctrl->p_buffer + (p_ctrl->in_index * 2);
        *(uint16_t *) paddr = (uint16_t) data;             /* add 2bytes data */
    }

    p_ctrl->in_index++;
    if (p_ctrl->in_index >= p_ctrl->size)                /* adjust index */
    {
        p_ctrl->in_index = 0;
    }

    p_ctrl->count++;                                     /* adjust count */

    return SSP_SUCCESS;
}  /* End of function R_BYTEQ_Put() */

/*******************************************************************************************************************//**
 * Dequeue data from the ByteQ module. If .length in the control block is BYTEQ_DATALEN_1BYTE, 1 byte is
 *  dequeued, if BYTEQ_DATALEN_2BYTES, 2 bytes are dequeued.
 * @param[in] p_ctrl             Pointer to the queue control block.
 * @param[in] p_dest             Pointer to the memory where the dequeued data are copied to.
 * @retval SSP_SUCCESS           Data is successfully dequeued from the queue.
 * @retval SSP_ERR_ASSERTION     Pointer to the queue control block is NULL.
 * @retval SSP_ERR_QUEUE_EMPTY   Queue is empty, no data available to queue.
 * @note   This function does not disable/enable interrupts. The interrupts for the peripheral which uses this module
 *            have to be disabled/enabled before/after calling this routine.
 **********************************************************************************************************************/
ssp_err_t R_BYTEQ_Get (byteq_ctrl_t * const p_ctrl, void * const p_dest)
{
#if (BYTEQ_CFG_PARAM_CHECKING_ENABLE)
    SSP_ASSERT(p_ctrl);
    SSP_ASSERT(p_dest);

    if (BYTEQ_DATALEN_2BYTES == p_ctrl->data_len)
    {
        /* buffer size is not matched to data length */
        BYTEQ_ERROR_RETURN((0 == ((uint32_t) p_dest % 2)), SSP_ERR_INVALID_ARGUMENT);
    }

#endif /* if (BYTEQ_CFG_PARAM_CHECKING_ENABLE) */

    BYTEQ_ERROR_RETURN((0 != p_ctrl->count), SSP_ERR_QUEUE_EMPTY);    /* return if queue empty */

    /* Dequeue data */
    if (BYTEQ_DATALEN_1BYTE == p_ctrl->data_len)
    {
        *(uint8_t *) p_dest = *(uint8_t *) (p_ctrl->p_buffer + p_ctrl->out_index);
    }
    else
    {
        *(uint16_t *) p_dest = *(uint16_t *) (p_ctrl->p_buffer + (p_ctrl->out_index * 2));
    }

    p_ctrl->out_index++;
    if (p_ctrl->out_index >= p_ctrl->size)              /* adjust index */
    {
        p_ctrl->out_index = 0;
    }

    p_ctrl->count--;                                    /* adjust count */

    return SSP_SUCCESS;
}  /* End of function R_BYTEQ_Get() */

/*******************************************************************************************************************//**
 * Reset the queue to the empty state.
 * @param[in] p_ctrl             Pointer to the queue control block.
 * @retval SSP_SUCCESS           Queue is successfully reset to the empty state.
 * @retval SSP_ERR_ASSERTION     Pointer to the queue control block is NULL.
 * @note   This function does not disable/enable interrupts. The interrupts for the peripheral which uses this module
 *          have to be disabled/enabled before/after calling this routine.
 **********************************************************************************************************************/
ssp_err_t R_BYTEQ_Flush (byteq_ctrl_t * const p_ctrl)
{
#if (BYTEQ_CFG_PARAM_CHECKING_ENABLE)
    SSP_ASSERT(p_ctrl);
#endif

    /* reset queue */
    p_ctrl->in_index  = 0;
    p_ctrl->out_index = 0;
    p_ctrl->count     = 0;

    return SSP_SUCCESS;
}  /* End of function R_BYTEQ_Flush() */

/*******************************************************************************************************************//**
 * Provide the number of data bytes in the queue.
 * @param[in] p_ctrl             Pointer to the queue control block.
 * @param[in] p_cnt              Pointer to the memory where the number of used queue slot to be stored.
 * @retval SSP_SUCCESS           Successfully get the number of data bytes already used in the queue.
 * @retval SSP_ERR_ASSERTION     Pointer to the queue control block is NULL.
 **********************************************************************************************************************/
ssp_err_t R_BYTEQ_Used (byteq_ctrl_t const * const p_ctrl, uint16_t * const p_cnt)
{
#if (BYTEQ_CFG_PARAM_CHECKING_ENABLE)
    SSP_ASSERT(p_ctrl);
    SSP_ASSERT(p_cnt);
#endif

    *p_cnt = p_ctrl->count;

    return SSP_SUCCESS;
}  /* End of function R_BYTEQ_Used() */

/*******************************************************************************************************************//**
 * Provide the number of data bytes available for storage in the queue.
 * @param[in] p_ctrl             Pointer to the queue control block.
 * @param[in] p_cnt              Pointer to the memory where the number of unused queue slot to be stored.
 * @retval SSP_SUCCESS           Successfully get the number of data bytes available for storage in the queue.
 * @retval SSP_ERR_ASSERTION     Pointer to the queue control block is NULL.
 **********************************************************************************************************************/
ssp_err_t R_BYTEQ_Unused (byteq_ctrl_t const * const p_ctrl, uint16_t * const p_cnt)
{
#if (BYTEQ_CFG_PARAM_CHECKING_ENABLE)
    SSP_ASSERT(p_ctrl);
    SSP_ASSERT(p_cnt);
#endif

    *p_cnt = (uint16_t) (p_ctrl->size - p_ctrl->count);

    return SSP_SUCCESS;
}  /* End of function R_BYTEQ_Unused() */

/*******************************************************************************************************************//**
 * Finalize the queue.
 * @param[in] p_ctrl             Pointer to the queue control block.
 * @retval SSP_SUCCESS           Finalized the queue successfully.
 * @retval SSP_ERR_ASSERTION     Pointer to the queue control block is NULL.
 **********************************************************************************************************************/
ssp_err_t R_BYTEQ_Close (byteq_ctrl_t * const p_ctrl)
{
#if (BYTEQ_CFG_PARAM_CHECKING_ENABLE)
    SSP_ASSERT(p_ctrl);
#endif

    p_ctrl->p_buffer  = NULL;
    p_ctrl->data_len  = 0;
    p_ctrl->size      = 0;
    p_ctrl->count     = 0;
    p_ctrl->in_index  = 0;
    p_ctrl->out_index = 0;

    return SSP_SUCCESS;
}  /* End of function R_BYTEQ_Close() */

/*******************************************************************************************************************//**
 * Return the version of this module.
 * @param  : none
 * @retval : version number
 **********************************************************************************************************************/
ssp_version_t  R_BYTEQ_GetVersion (void)
{
    return byteq_version;
}  /* End of function R_BYTEQ_GetVersion() */

/*******************************************************************************************************************//**
 * @} (end addtogroup BYTEQ)
 **********************************************************************************************************************/
/* End of file */
