/***********************************************************************************************************************
 * Copyright [2015] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
 * display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
 * purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
 * SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
 * NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
 * OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
 * be subject to different terms.
 **********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : r_sci_uart.c
 * Description  : UART on SCI HAL driver
 ***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *           08.12.2014 1.00    Initial Release.
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Includes
 **********************************************************************************************************************/
#include "r_sci_common_cfg.h"
#include "r_sci_uart_cfg.h"
#include "r_sci_uart.h"
#include "r_sci_uart_private_api.h"
#include "r_cgc.h"
#include "../r_sci_common/r_sci_private.h"

#if (SCI_CFG_ASYNC_INCLUDED)

/***********************************************************************************************************************
 * Macro definitions
 **********************************************************************************************************************/
#ifndef SCI_UART_ERROR_RETURN
#define SCI_UART_ERROR_RETURN(a, err) SSP_ERROR_RETURN((a), (err), module_name, &module_version)
#endif

/***********************************************************************************************************************
 * Typedef definitions
 **********************************************************************************************************************/
/** Circular buffer status */
typedef enum buf_status
{
    QUE_STATUS_NOT_EMPTY,
    QUE_STATUS_EMPTY,
} buf_status_t;

/***********************************************************************************************************************
 * Private function prototypes
 **********************************************************************************************************************/
static ssp_err_t r_sci_uart_open_param_check  (uart_ctrl_t const * const p_ctrl, uart_cfg_t const * const p_cfg);

static ssp_err_t r_sci_read_write_param_check (uart_ctrl_t const     * p_ctrl,
                                               uint8_t const * const addr,
                                               uint32_t const        size);

static ssp_err_t    r_sci_uart_config_set        (uart_cfg_t const * const p_cfg);

static ssp_err_t    r_sci_queue_init             (uart_cfg_t const * const p_cfg);

static ssp_err_t    r_sci_queue_finalize         (byteq_ctrl_t * const p_que_ctrl);

static ssp_err_t    r_sci_uart_baud_set          (uint32_t const channel, sci_clk_src_t clk_src, uint32_t baudrate);

static uint16_t     r_sci_uart_reg_read          (uint32_t const channel);

static void         r_sci_uart_reg_write         (uint32_t const channel, uint16_t data);

#if (SCI_UART_CFG_HW_FIFO_ENABLE)
static void         r_sci_uart_fifo_reset  (uart_cfg_t const * const p_cfg);

static void         r_sci_uart_fifo_enable (uart_cfg_t const * const p_cfg);

static buf_status_t r_sci_uart_que2reg_fifo_write (uint32_t const channel);

#else
static buf_status_t r_sci_uart_que2reg_write     (uint32_t const channel);
#endif
#if (SCI_UART_CFG_EXTERNAL_RTS_OPERATION)
static void         r_sci_uart_external_rts_operation_enable (uart_cfg_t const * const p_cfg);
#endif

/***********************************************************************************************************************
 * Private global variables
 **********************************************************************************************************************/
/** SCI control block array for channel */
extern sci_ctrl_t           g_sci_ctrl_blk[SCI_PHY_CH_MAX];

/** Baud rate divisor information(UART mode) */
static const baud_setting_t async_baud[NUM_DIVISORS_ASYNC] =
{
    {   6,  0,  0,  1,  0 }, /* divisor, BGDM, ABCS, ABCSE, n */
    {   8,  1,  1,  0,  0 },
    {  16,  0,  1,  0,  0 },
    {  24,  0,  0,  1,  1 },
    {  32,  0,  0,  0,  0 },
    {  64,  0,  1,  0,  1 },
    {  96,  0,  0,  1,  2 },
    { 128,  0,  0,  0,  1 },
    { 256,  0,  1,  0,  2 },
    { 384,  0,  0,  1,  3 },
    { 512,  0,  0,  0,  2 },
    { 1024, 0,  1,  0,  3 },
    { 2048, 0,  0,  0,  3 }
};

/** SCI UART HAL module version data structure */
static const ssp_version_t module_version =
{
    .api_version_major  = UART_API_VERSION_MAJOR,
    .api_version_minor  = UART_API_VERSION_MINOR,
    .code_version_major = SCI_UART_CODE_VERSION_MAJOR,
    .code_version_minor = SCI_UART_CODE_VERSION_MINOR
};

/** Name of module used by error logger macro */
static const char module_name[] = "sci_uart";

/** UART on SCI HAL API mapping for UART interface */
const uart_api_t  g_uart_on_sci =
{
    .open       = R_SCI_UartOpen,
    .close      = R_SCI_UartClose,
    .write      = R_SCI_UartWrite,
    .read       = R_SCI_UartRead,
    .baudSet    = R_SCI_UartBaudSet,
    .txFlush    = R_SCI_UartTxFlush,
    .rxFlush    = R_SCI_UartRxFlush,
    .versionGet = R_SCI_UartVersionGet
};

/*******************************************************************************************************************//**
 * @addtogroup UARTonSCI
 * @{
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Functions
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @retval  SSP_SUCCESS                  Channel opened successfully.
 * @retval  SSP_ERR_IN_USE               Channel already in use.
 * @retval  SSP_ERR_ASSERTION            Pointer to UART control block or configuration structure is NULL.
 * @retval  SSP_ERR_HW_LOCKED            Channel is locked.
 * @retval  SSP_ERR_INVALID_MODE         Channel is used for non-UART mode or illegal mode is set.
 * @retval  SSP_ERR_INVALID_ARGUMENT     Invalid parameter setting found in the configuration structure.
 * @retval  SSP_ERR_QUEUE_UNAVAILABLE    Cannot open transmit or receive queue or both.
 * @note This function is reentrant.
 **********************************************************************************************************************/
ssp_err_t R_SCI_UartOpen (uart_ctrl_t * const p_ctrl, uart_cfg_t const * const p_cfg)
{
    ssp_err_t         err = SSP_SUCCESS;
    uart_on_sci_cfg_t * pextend;

#if (SCI_UART_CFG_PARAM_CHECKING_ENABLE)
    /** Check parameters. */
    err = r_sci_uart_open_param_check(p_ctrl, p_cfg);        /** check arguments */
    SCI_UART_ERROR_RETURN((SSP_SUCCESS == err), err);
#endif

    pextend = (uart_on_sci_cfg_t *) p_cfg->p_extend;

    /** lock specified SCI channel */
    SCI_UART_ERROR_RETURN((SSP_SUCCESS == r_sci_hardware_lock(p_cfg->channel)), SSP_ERR_HW_LOCKED);

    /** initializes queues */
    err = r_sci_queue_init(p_cfg);
    if (err != SSP_SUCCESS)
    {
        r_sci_hardware_unlock(p_cfg->channel);
        return err;
    }

    p_ctrl->u_rx_data.p_que = p_cfg->p_rx_que_ctrl;
    p_ctrl->u_tx_data.p_que = p_cfg->p_tx_que_ctrl;

    HW_SCI_PowerOn(p_cfg->channel);                             /** applies power to channel */
    HW_SCI_InterruptEnable(p_cfg->channel, SCI_ALL_INT, false); /** disables interrupt */
    HW_SCI_ReceiverDisable(p_cfg->channel);                     /** disables receiver */
    HW_SCI_TransmitterDisable(p_cfg->channel);                  /** enables transmitter */

#if (SCI_UART_CFG_HW_FIFO_ENABLE)
    r_sci_uart_fifo_reset(p_cfg);                          /** configure FIFO related registers */
#endif

    if ((pextend) && (pextend->rx_edge_start))
    {
        HW_SCI_StartBitFallingEdgeSet(p_cfg->channel);     /** starts reception when RXD has falling edge */
    }
    else
    {
        HW_SCI_StartBitLowLevelSet(p_cfg->channel);        /** starts reception when RXD becomes low level */
    }

    if ((pextend) && (pextend->noisecancel_en))
    {
        HW_SCI_NoiseFilterSet(p_cfg->channel, 0);          /** enables the noise cancellation, the effect level should
                                                            *   be fixed to the minimum */
    }
    else
    {
        HW_SCI_NoiseFilterClear(p_cfg->channel);           /** disables the noise cancellation */
    }

    err = r_sci_uart_config_set(p_cfg);                    /** configure UART related registers */
    if (err != SSP_SUCCESS)
    {
        r_sci_queue_finalize(p_cfg->p_tx_que_ctrl);
        r_sci_queue_finalize(p_cfg->p_rx_que_ctrl);
        HW_SCI_StartBitLowLevelSet(p_cfg->channel);        /** set default setting */
        HW_SCI_PowerOff(p_cfg->channel);                   /** removes power to channel */
        r_sci_hardware_unlock(p_cfg->channel);
        return err;
    }

#if (SCI_UART_CFG_HW_FIFO_ENABLE)
    r_sci_uart_fifo_enable(p_cfg);                         /** configure FIFO related registers */
#endif

#if (SCI_UART_CFG_RX_ENABLE)
    HW_SCI_RXIeventSelect(p_cfg->channel);             /** selects RXI when detecting a reception data ready */
#endif

    p_ctrl->channel                          = p_cfg->channel;
    p_ctrl->p_context                        = p_cfg->p_context;  /** saves AMS UART device context inside SCI HAL
                                                                   * driver */
    p_ctrl->p_callback                       = p_cfg->p_callback; /** registers callback function from higher layer */
    p_ctrl->expect_rdlen                     = 0;                 /** initializes expected read length */

    g_sci_ctrl_blk[p_cfg->channel].mode      = SCI_MODE_ASYNC;
    g_sci_ctrl_blk[p_cfg->channel].tx_busy   = false;
    g_sci_ctrl_blk[p_cfg->channel].p_context = p_ctrl;

#if (SCI_UART_CFG_RX_ENABLE)
    HW_SCI_ReceiverEnable(p_cfg->channel);                      /** enables receiver */
    HW_SCI_InterruptEnable(p_cfg->channel, SCI_RX_INT, true);   /** enables receive interrupt */
#endif

    /** Transmitter and its interrupt are enabled in R_SCI_UartWrite() */

#if (SCI_UART_CFG_EXTERNAL_RTS_OPERATION)
    r_sci_uart_external_rts_operation_enable(p_cfg);            /** configure FIFO related registers */
#endif

    return SSP_SUCCESS;
}  /* End of function R_SCI_UartOpen() */

/*******************************************************************************************************************//**
 * @retval  SSP_SUCCESS              Channel successfully closed.
 * @retval  SSP_ERR_ASSERTION        Pointer to UART control block is NULL.
 * @note This function is reentrant.
 **********************************************************************************************************************/
ssp_err_t R_SCI_UartClose (uart_ctrl_t * const p_ctrl)
{
#if (SCI_UART_CFG_PARAM_CHECKING_ENABLE)
    SSP_ASSERT(p_ctrl);
#endif

    /** finalizes Tx and Rx queues */
    if (g_sci_ctrl_blk[p_ctrl->channel].mode == SCI_MODE_ASYNC)
    {
#if (SCI_UART_CFG_RX_ENABLE)
        r_sci_queue_finalize(p_ctrl->u_rx_data.p_que);
#endif
#if (SCI_UART_CFG_TX_ENABLE)
        r_sci_queue_finalize(p_ctrl->u_tx_data.p_que);
#endif
    }

    /** clears control block parameters */
    p_ctrl->expect_rdlen = 0;
    p_ctrl->p_callback   = NULL;

    /** disables the associated interrupts<br>
     *  disables receiver<br>
     *  disables transmitter<br>
     *  removes power to the SCI channel<br>
     *  unlocks specified SCI channel<br>
     *  clears device context<br>
     */
    r_sci_close_common(p_ctrl->channel);

    return SSP_SUCCESS;
}  /* End of function R_SCI_UartClose() */

#if (SCI_UART_CFG_RX_ENABLE)

/*******************************************************************************************************************//**
 * @retval  SSP_SUCCESS                  Data reception successfully ends.
 * @retval  SSP_ERR_HW_LOCKED            Channel is locked.
 * @retval  SSP_ERR_ASSERTION            Pointer to UART control block is NULL.
 * @retval  SSP_ERR_INVALID_MODE         Channel is used for non-UART mode.
 * @retval  SSP_ERR_INVALID_ARGUMENT     Destination address or data size is invalid against data length.
 * @retval  SSP_ERR_INSUFFICIENT_DATA    There is not enough data in receive queue
 * @note This function is reentrant. This API is only valid when SCI_UART_CFG_RX_ENABLE is enabled.
 *       If 9-bit data length is specified at R_SCI_UartOpen call, dest must be aligned 16-bit boundary.
 **********************************************************************************************************************/
ssp_err_t R_SCI_UartRead (uart_ctrl_t * const p_ctrl, uint8_t const * const p_dest, uint32_t const bytes)
{
    ssp_err_t err        = SSP_SUCCESS;
    uint32_t  data_bytes = 1;
    uint16_t  cnt;

#if (SCI_UART_CFG_PARAM_CHECKING_ENABLE)
    /** checks arguments */
    err = r_sci_read_write_param_check(p_ctrl, p_dest, bytes);
    SCI_UART_ERROR_RETURN((SSP_SUCCESS == err), err);
#endif

    /** checks data byte length */
    if (HW_SCI_IsDataLength9bits(p_ctrl->channel))
    {
        data_bytes = 2;               /* data length per data entry is 2byte if 9bits data length */
    }

    /** locks specified SCI channel */
    SCI_UART_ERROR_RETURN((BSP_SUCCESS == R_BSP_SoftwareLock(
                               &g_sci_ctrl_blk[p_ctrl->channel].resource_lock_rx)), SSP_ERR_HW_LOCKED);

    if (g_sci_ctrl_blk[p_ctrl->channel].mode == SCI_MODE_ASYNC)
    {
        /** disables RXI before accessing to circular buffer */
        HW_SCI_InterruptEnable(p_ctrl->channel, SCI_RX_INT, false);

        /** checks for sufficient data in queue and fetch if available */
        R_BYTEQ_Used(p_ctrl->u_rx_data.p_que, &cnt);

        /** enables RXI after accessing to circular buffer */
        HW_SCI_InterruptEnable(p_ctrl->channel, SCI_RX_INT, true);

        if (cnt < (bytes >> (data_bytes - 1)))
        {
            p_ctrl->expect_rdlen = bytes;    /* saves the expected data size */
            err                  = SSP_ERR_INSUFFICIENT_DATA;
        }
        else
        {
            /** gets data from receive queue */
            for (cnt = 0; cnt < bytes; cnt += data_bytes)
            {
                HW_SCI_InterruptEnable(p_ctrl->channel, SCI_RX_INT, false);
                R_BYTEQ_Get(p_ctrl->u_rx_data.p_que, (void *) (p_dest + cnt));
                HW_SCI_InterruptEnable(p_ctrl->channel, SCI_RX_INT, true);
            }

            err = SSP_SUCCESS;
        }
    }

    /* unlocks specified SCI channel */
    R_BSP_SoftwareUnlock(&g_sci_ctrl_blk[p_ctrl->channel].resource_lock_rx);

    return err;
}  /* End of function R_SCI_UartRead() */
#endif /* if (SCI_UART_CFG_RX_ENABLE) */

#if (SCI_UART_CFG_TX_ENABLE)

/*******************************************************************************************************************//**
 * @retval  SSP_SUCCESS                  Data transmission finished successfully.
 * @retval  SSP_ERR_ASSERTION            Pointer to UART control block is NULL.
 * @retval  SSP_ERR_INVALID_MODE         Channel is used for non-UART mode or illegal mode is set in handle.
 * @retval  SSP_ERR_INVALID_ARGUMENT     Source address or data size is invalid against data length.
 * @retval  SSP_ERR_INSUFFICIENT_SPACE   No enough space to store data in transmit queue.
 * @retval  SSP_ERR_HW_LOCKED            Could not lock hardware.
 * @note This function is reentrant.
 *       If 9-bit data length is specified at R_SCI_UartOpen call, the source must be aligned on a 16-bit boundary.
 **********************************************************************************************************************/
ssp_err_t R_SCI_UartWrite (uart_ctrl_t const * const p_ctrl, uint8_t const * const p_src, uint32_t const bytes)
{
    ssp_err_t err        = SSP_SUCCESS;
    uint32_t  data_bytes = 1;
    uint16_t  data;
    uint16_t  cnt;
#if (SCI_UART_CFG_HW_FIFO_ENABLE)
    uint16_t  fifo_rest;
#else
    uint16_t  first_data = 0;
#endif

#if (SCI_UART_CFG_PARAM_CHECKING_ENABLE)
    /** checks arguments */
    err = r_sci_read_write_param_check(p_ctrl, p_src, bytes);
    if (SSP_SUCCESS != err)
    {
        return err;
    }
#endif

    /** locks specified SCI channel */
    SCI_UART_ERROR_RETURN((BSP_SUCCESS == R_BSP_SoftwareLock(
                               &g_sci_ctrl_blk[p_ctrl->channel].resource_lock_tx)), SSP_ERR_HW_LOCKED);

    if (SCI_MODE_ASYNC == g_sci_ctrl_blk[p_ctrl->channel].mode)
    {
        /** disables TIE prior to disabling TE because disabling TE during TIE=1 generates
         *   TXI interrupt which is not expected here. */
        HW_SCI_InterruptEnable(p_ctrl->channel, SCI_TX_INT, false);

        HW_SCI_TransmitterDisable(p_ctrl->channel);                 /** disables first prepare for any case */

        /** determines amount of space left in transmit queue */
        R_BYTEQ_Unused(p_ctrl->u_tx_data.p_que, &cnt);
        if (cnt < bytes)
        {
            err = SSP_ERR_INSUFFICIENT_SPACE;                        /* If can't fit, return */
        }
        else
        {
            if (!g_sci_ctrl_blk[p_ctrl->channel].tx_busy)
            {
                g_sci_ctrl_blk[p_ctrl->channel].tx_busy = true;     /** sets transmit status as ON TRANSACTION */
                HW_SCI_TransmitterEnable(p_ctrl->channel);          /** enables transmitter */
            }

#if (SCI_UART_CFG_HW_FIFO_ENABLE)
            /** checks the rest size in FIFO */
            fifo_rest = SCI_FIFO_STAGE_NUM - HW_SCI_FIFO_WriteCount(p_ctrl->channel);
#endif
            if (HW_SCI_IsDataLength9bits(p_ctrl->channel))
            {
                data_bytes = 2;
            }

            for (cnt = 0; cnt < bytes; cnt += data_bytes)
            {
                /** checks data byte length */
                if (1 == data_bytes)
                {
                    data = (uint16_t) (*(p_src + cnt));
                }
                else
                {
                    data = (uint16_t) (*(uint16_t *) (p_src + cnt));    /* 9-bit data length needs 2 bytes */
                }

#if (SCI_UART_CFG_HW_FIFO_ENABLE)
                /* FIFO case */
                if (cnt < fifo_rest)
                {
                    /** writes bytes to FIFO directly if the rest of FIFO is larger than data bytes to be transferred
                     *(FIFO mode procedure) */
                    HW_SCI_WriteFIFO(p_ctrl->channel, data);
                }
                else
                {
                    /** or writes bytes to circular buffer if the rest of FIFO is zero (FIFO mode procedure) */
                    R_BYTEQ_Put(p_ctrl->u_tx_data.p_que, data);
                }

#else /* if (SCI_UART_CFG_HW_FIFO_ENABLE) */
                /* Non FIFO case */
                if (0 == cnt)
                {
                    /** keep first byte(s) which should be written into data register directly (non-FIFO mode procedure)
                    **/
                    first_data = data;
                }
                else
                {
                    /** writes data to circular buffer except first byte(s) (non-FIFO mode procedure) */
                    R_BYTEQ_Put(p_ctrl->u_tx_data.p_que, data);
                }
#endif /* if (SCI_UART_CFG_HW_FIFO_ENABLE) */
            }

            HW_SCI_InterruptEnable(p_ctrl->channel, SCI_TX_INT, true);

#if !(SCI_UART_CFG_HW_FIFO_ENABLE)
            /* Non FIFO case */
            /** writes first byte(s) to data register directly below step (non-FIFO mode procedure) */
            if (HW_SCI_IsDataLength9bits(p_ctrl->channel))
            {
                HW_SCI_Write9bits(p_ctrl->channel, first_data);
            }
            else
            {
                HW_SCI_Write(p_ctrl->channel, first_data);
            }
#endif /* if !(SCI_UART_CFG_HW_FIFO_ENABLE) */
            err = SSP_SUCCESS;
        }
    }

    /** unlocks specified SCI channel */
    R_BSP_SoftwareUnlock(&g_sci_ctrl_blk[p_ctrl->channel].resource_lock_tx);

    return err;
}  /* End of function R_SCI_UartWrite() */
#endif /* if (SCI_UART_CFG_TX_ENABLE) */

/*******************************************************************************************************************//**
 * @retval  SSP_SUCCESS                  Baud rate was successfully changed.
 * @retval  SSP_ERR_ASSERTION            Pointer to UART control block is NULL.
 * @retval  SSP_ERR_INVALID_ARGUMENT     Illegal baud rate value is specified.
 * @retval  SSP_ERR_HW_LOCKED            Could not lock hardware.
 * @note This function is reentrant. Clock source cannot be changed by this API, need to open again if it is needed.
 **********************************************************************************************************************/
ssp_err_t R_SCI_UartBaudSet (uart_ctrl_t const * p_ctrl, uint32_t const baudrate)
{
    ssp_err_t     err = SSP_SUCCESS;
    sci_clk_src_t clk_src;

#if (SCI_UART_CFG_PARAM_CHECKING_ENABLE)
    SSP_ASSERT(p_ctrl);
#endif

    /** locks specified SCI channel */
    SCI_UART_ERROR_RETURN((BSP_SUCCESS == R_BSP_SoftwareLock(
                               &g_sci_ctrl_blk[p_ctrl->channel].resource_lock_tx)), SSP_ERR_HW_LOCKED);

    /** disables interrupts */
    HW_SCI_InterruptEnable(p_ctrl->channel, SCI_ALL_INT, false);

    /** disables transmitter. This API does not resume transmission but terminate it */
    HW_SCI_TransmitterDisable(p_ctrl->channel);

    /** disables receiver */
    HW_SCI_ReceiverDisable(p_ctrl->channel);

    /** sets baud-rate related registers */
    if (HW_SCI_IsBaudRateInternalClkSelected(p_ctrl->channel))
    {
        clk_src = SCI_CLK_SRC_INT;
    }
    else
    {
        if (HW_SCI_IsBaudRateGenClkDivideBy8Selected(p_ctrl->channel))
        {
            clk_src = SCI_CLK_SRC_EXT8X;
        }
        else
        {
            clk_src = SCI_CLK_SRC_EXT16X;
        }
    }

    err = r_sci_uart_baud_set(p_ctrl->channel, clk_src, baudrate);

    /** enables receiver */
    HW_SCI_ReceiverEnable(p_ctrl->channel);

    /** enables interrupts */
    HW_SCI_InterruptEnable(p_ctrl->channel, SCI_RX_INT, true);

    /** unlocks specified SCI channel */
    R_BSP_SoftwareUnlock(&g_sci_ctrl_blk[p_ctrl->channel].resource_lock_tx);

    return err;
}  /* End of function R_SCI_UartBaudSet() */

#if (SCI_UART_CFG_TX_ENABLE)

/*******************************************************************************************************************//**
 * @retval  SSP_SUCCESS          Transmit buffer is successfully flushed.
 * @retval  SSP_ERR_ASSERTION    Pointer to UART control block or circular buffer is NULL.
 * @retval  SSP_ERR_HW_LOCKED    Specified channel has been locked.
 * @note This function is reentrant.
 **********************************************************************************************************************/
ssp_err_t R_SCI_UartTxFlush (uart_ctrl_t const * const p_ctrl)
{
#if (SCI_UART_CFG_PARAM_CHECKING_ENABLE)
    SSP_ASSERT(p_ctrl);
    SSP_ASSERT(p_ctrl->u_tx_data.p_que);
#endif

    /** locks specified SCI channel */
    SCI_UART_ERROR_RETURN((BSP_SUCCESS == R_BSP_SoftwareLock(
                               &g_sci_ctrl_blk[p_ctrl->channel].resource_lock_tx)), SSP_ERR_HW_LOCKED);

    /** disables interrupts */
    HW_SCI_InterruptEnable(p_ctrl->channel, SCI_TX_INT, false);

    /** flushes circular buffer */
    R_BYTEQ_Flush(p_ctrl->u_tx_data.p_que);

    /** unlocks specified SCI channel */
    R_BSP_SoftwareUnlock(&g_sci_ctrl_blk[p_ctrl->channel].resource_lock_tx);

    return SSP_SUCCESS;
}  /* End of function R_SCI_UartTxFlush() */
#endif /* if (SCI_UART_CFG_TX_ENABLE) */

#if (SCI_UART_CFG_RX_ENABLE)

/*******************************************************************************************************************//**
 * @retval  SSP_SUCCESS          Receive buffer is successfully flushed.
 * @retval  SSP_ERR_ASSERTION    Pointer to UART control block or circular buffer is NULL.
 * @retval  SSP_ERR_HW_LOCKED    Specified channel has been locked.
 * @note This function is reentrant.
 **********************************************************************************************************************/
ssp_err_t R_SCI_UartRxFlush (uart_ctrl_t const * const p_ctrl)
{
#if (SCI_UART_CFG_PARAM_CHECKING_ENABLE)
    SSP_ASSERT(p_ctrl);
    SSP_ASSERT(p_ctrl->u_rx_data.p_que);
#endif

    /** locks specified SCI channel */
    SCI_UART_ERROR_RETURN((BSP_SUCCESS == R_BSP_SoftwareLock(
                               &g_sci_ctrl_blk[p_ctrl->channel].resource_lock_rx)), SSP_ERR_HW_LOCKED);

    /** disables interrupts */
    HW_SCI_InterruptEnable(p_ctrl->channel, SCI_RX_INT, false);

    /** flushes circular buffer */
    R_BYTEQ_Flush(p_ctrl->u_rx_data.p_que);

    /** enables interrupts */
    HW_SCI_InterruptEnable(p_ctrl->channel, SCI_RX_INT, true);

    /** unlocks specified SCI channel */
    R_BSP_SoftwareUnlock(&g_sci_ctrl_blk[p_ctrl->channel].resource_lock_rx);

    return SSP_SUCCESS;
}  /* End of function R_SCI_UartRxFlush() */
#endif /* if (SCI_UART_CFG_RX_ENABLE) */

/*******************************************************************************************************************//**
 * @retval   Version number
 * @note This function is reentrant.
 **********************************************************************************************************************/
ssp_err_t R_SCI_UartVersionGet (ssp_version_t * p_version)
{
    *p_version = module_version;
    return SSP_SUCCESS;
} /* End of function R_SCI_UartVersionGet() */

/*******************************************************************************************************************//**
 * @} (end addtogroup UARTonSCI)
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Private Functions
 **********************************************************************************************************************/
#if (SCI_UART_CFG_PARAM_CHECKING_ENABLE)

/*******************************************************************************************************************//**
 * Parameter error check function for open processing
 * @param[in] p_ctrl   Pointer to the control block for the channel
 * @param[in] p_cfg    Pointer to the configuration structure specific to UART mode
 * @retval  SSP_SUCCESS                  No parameter error found
 * @retval  SSP_ERR_IN_USE               Channel already in use
 * @retval  SSP_ERR_ASSERTION            Pointer to UART control block or configuration structure is NULL
 * @retval  SSP_ERR_INVALID_ARGUMENT     Invalid parameter setting found in the configuration structure
 **********************************************************************************************************************/
static ssp_err_t r_sci_uart_open_param_check (uart_ctrl_t const * const p_ctrl, uart_cfg_t const * const p_cfg)
{
    SSP_ASSERT(p_ctrl);
    SSP_ASSERT(p_cfg);
    SCI_UART_ERROR_RETURN((SCI_CH_MAX > p_cfg->channel), SSP_ERR_INVALID_ARGUMENT);
    SCI_UART_ERROR_RETURN((SCI_MODE_OFF == g_sci_ctrl_blk[p_cfg->channel].mode), SSP_ERR_IN_USE);

    SCI_UART_ERROR_RETURN((((UART_DATA_BITS_7  == p_cfg->data_bits) || (UART_DATA_BITS_8  == p_cfg->data_bits))
                           || (UART_DATA_BITS_9  == p_cfg->data_bits)), SSP_ERR_INVALID_ARGUMENT);

    SCI_UART_ERROR_RETURN(((UART_STOP_BITS_1 == p_cfg->stop_bits) || (UART_STOP_BITS_2 == p_cfg->stop_bits))
                          , SSP_ERR_INVALID_ARGUMENT);

    SCI_UART_ERROR_RETURN((((UART_PARITY_OFF  == p_cfg->parity) || (UART_PARITY_EVEN == p_cfg->parity))
                           || (UART_PARITY_ODD  == p_cfg->parity)), SSP_ERR_INVALID_ARGUMENT);

    if (p_cfg->p_extend)
    {
        if (SCI_CLK_SRC_INT == ((uart_on_sci_cfg_t *) (p_cfg->p_extend))->clk_src)
        {
            SCI_UART_ERROR_RETURN((0 != p_cfg->baud_rate), SSP_ERR_INVALID_ARGUMENT);
        }
        else if ((SCI_CLK_SRC_EXT8X  == ((uart_on_sci_cfg_t *) (p_cfg->p_extend))->clk_src)
                 || (SCI_CLK_SRC_EXT16X == ((uart_on_sci_cfg_t *) (p_cfg->p_extend))->clk_src)
                 )
        {
            /* No error */
        }
        else
        {
            return SSP_ERR_INVALID_ARGUMENT;
        }
    }

    return SSP_SUCCESS;
}  /* End of function r_sci_uart_open_param_check() */

/*******************************************************************************************************************//**
 * Parameter error check function for read/write processing
 * @param[in] p_ctrl Pointer to the control block for the channel
 * @param[in] addr   Pointer to the buffer
 * @param[in] size   Data size
 * @retval  SSP_SUCCESS              No parameter error found
 * @retval  SSP_ERR_ASSERTION        Pointer to UART control block or configuration structure is NULL
 * @retval  SSP_ERR_INVALID_MODE     Channel is used for non-UART mode or illegal mode is set
 * @retval  SSP_ERR_INVALID_ARGUMENT Address is not aligned to 2-byte boundary or size is the odd number when the data
 * length is 9-bit
 * @note This function is reentrant.
 **********************************************************************************************************************/
static ssp_err_t r_sci_read_write_param_check (uart_ctrl_t const * const p_ctrl,
                                               uint8_t const * const     addr,
                                               uint32_t const            size)
{
    SSP_ASSERT(p_ctrl);
    SSP_ASSERT(addr);
    SCI_UART_ERROR_RETURN((g_sci_ctrl_blk[p_ctrl->channel].mode != SCI_MODE_OFF), SSP_ERR_INVALID_MODE);
    SCI_UART_ERROR_RETURN((g_sci_ctrl_blk[p_ctrl->channel].mode < SCI_MODE_MAX), SSP_ERR_INVALID_MODE);

    if (HW_SCI_IsDataLength9bits(p_ctrl->channel))
    {
        /* Do not allow odd buffer address if data length is 9bits. */
        SCI_UART_ERROR_RETURN((0 == ((uint32_t) addr % 2)), SSP_ERR_INVALID_ARGUMENT);

        /* Do not allow odd number of data size if data length is 9bits. */
        SCI_UART_ERROR_RETURN((0 == (size % 2)), SSP_ERR_INVALID_ARGUMENT);
    }

    return SSP_SUCCESS;
}  /* End of function r_sci_read_write_param_check() */
#endif /* if (SCI_UART_CFG_PARAM_CHECKING_ENABLE) */

/*******************************************************************************************************************//**
 * Configures UART related registers
 * @param[in]     p_cfg   Pointer to UART specific configuration structure
 * @retval        none
 **********************************************************************************************************************/
static ssp_err_t r_sci_uart_config_set (uart_cfg_t const * const p_cfg)
{
    ssp_err_t         err;
    uart_on_sci_cfg_t * pextend = (uart_on_sci_cfg_t *) p_cfg->p_extend;
    sci_clk_src_t     clk_src;

    HW_SCI_AsyncModeSet(p_cfg->channel);               /* applies ASYNC mode */

    HW_SCI_ClockPhaseDelayDisable(p_cfg->channel);     /* disables SCKn clock delay */

    HW_SCI_ClockPorarityNormalSet(p_cfg->channel);     /* sets SCKn clock polarity normal */

    if (UART_PARITY_OFF != p_cfg->parity)
    {
        HW_SCI_ParityBitEnable(p_cfg->channel);        /* enables parity */
    }
    else
    {
        HW_SCI_ParityBitDisable(p_cfg->channel);       /* disables parity */
    }

    if (UART_PARITY_ODD == p_cfg->parity)
    {
        HW_SCI_ParityOddSelect(p_cfg->channel);        /* selects odd parity */
    }
    else
    {
        HW_SCI_ParityEvenSelect(p_cfg->channel);       /* selects even parity */
    }

    if (UART_DATA_BITS_7 == p_cfg->data_bits)
    {
        HW_SCI_DataBits7bitsSelect(p_cfg->channel);    /* selects 7-bit data length */
    }
    else if (UART_DATA_BITS_9 == p_cfg->data_bits)
    {
        HW_SCI_DataBits9bitsSelect(p_cfg->channel);    /* selects 9-bit data length */
    }
    else
    {
        HW_SCI_DataBits8bitsSelect(p_cfg->channel);    /* selects 8-bit data length */
    }

    if (UART_STOP_BITS_2 == p_cfg->stop_bits)
    {
        HW_SCI_StopBits2bitsSelect(p_cfg->channel);    /* selects 2-bit stop bit length */
    }
    else
    {
        HW_SCI_StopBits1bitSelect(p_cfg->channel);     /* selects 1-bit stop bit length */
    }

    if (p_cfg->ctsrts_en)
    {
        HW_SCI_CtsInEnable(p_cfg->channel);            /* enables CTS hardware flow control on RTSn#/CTSn# pin */
    }
    else
    {
        HW_SCI_RtsOutEnable(p_cfg->channel);           /* enables RTS hardware flow control on RTSn#/CTSn# pin */
    }

    /** sets baud rate */
    if ((pextend)
        && (((SCI_CLK_SRC_INT    == pextend->clk_src)
             ||   (SCI_CLK_SRC_EXT8X  == pextend->clk_src))
            ||   (SCI_CLK_SRC_EXT16X == pextend->clk_src))
        )
    {
        clk_src = pextend->clk_src;
    }
    else
    {
        clk_src = SCI_CLK_SRC_INT;
    }

    err = r_sci_uart_baud_set(p_cfg->channel, clk_src, p_cfg->baud_rate);
    if (err == SSP_ERR_INVALID_ARGUMENT)
    {
        HW_SCI_BaudClkOutputDisable(p_cfg->channel);       /** set default setting */
        return err;
    }

    if ((pextend) && (pextend->baudclk_out))
    {
        HW_SCI_BaudClkOutputEnable(p_cfg->channel);        /** enables Baud rate clock output */
    }
    else
    {
        HW_SCI_BaudClkOutputDisable(p_cfg->channel);       /** disables Baud rate clock output */
    }

    return SSP_SUCCESS;
}  /* End of function r_sci_uart_config_set() */

/*******************************************************************************************************************//**
 * This function enables external RTS(using a GPIO) operation
 * @param[in] p_cfg    Pointer to UART configuration structure
 * @retval  SSP_SUCCESS                  Circular buffer for a channel initialized successfully
 * @retval  SSP_ERR_QUEUE_UNAVAILABLE    No queue control blocks available
 * @note This function is reentrant.
 **********************************************************************************************************************/
#if (SCI_UART_CFG_EXTERNAL_RTS_OPERATION)
static void r_sci_uart_external_rts_operation_enable (uart_cfg_t const * const p_cfg)
{
    uart_on_sci_cfg_t * pextend = (uart_on_sci_cfg_t *) p_cfg->p_extend;

    if ((p_cfg->ctsrts_en) && (pextend->p_extpin_ctrl))
    {
        g_sci_ctrl_blk[p_cfg->channel].p_extpin_ctrl = pextend->p_extpin_ctrl;
        g_sci_ctrl_blk[p_cfg->channel].p_extpin_ctrl(p_cfg->channel, 0);   /** user definition function call to control
                                                                            * GPIO */
    }
}  /* End of function r_sci_uart_external_rts_operation_enable () */
#endif /* if (SCI_UART_CFG_EXTERNAL_RTS_OPERATION) */

/*******************************************************************************************************************//**
 * This function attaches queue to the channel.
 * @param[in] p_cfg    Pointer to UART configuration structure
 * @retval  SSP_SUCCESS                  Circular buffer for a channel initialized successfully
 * @retval  SSP_ERR_QUEUE_UNAVAILABLE    No queue control blocks available
 * @note This function is reentrant.
 **********************************************************************************************************************/
static ssp_err_t r_sci_queue_init (uart_cfg_t const * const p_cfg)
{
    uint32_t byte_len = 1;

    if (UART_DATA_BITS_9 == p_cfg->data_bits)
    {
        byte_len = 2;   /* data length per data entry is 2byte if 9bits data length */
    }

#if (SCI_UART_CFG_RX_ENABLE)
    /* channel number verified as legal prior to calling this function */
    SCI_UART_ERROR_RETURN((SSP_SUCCESS ==
                           (R_BYTEQ_Open(p_cfg->p_rx_que_ctrl, p_cfg->p_rx_que, p_cfg->rx_que_len, byte_len))),
                          SSP_ERR_QUEUE_UNAVAILABLE);
#endif
#if (SCI_UART_CFG_TX_ENABLE)
    /* channel number verified as legal prior to calling this function */
    SCI_UART_ERROR_RETURN((SSP_SUCCESS ==
                           (R_BYTEQ_Open(p_cfg->p_tx_que_ctrl, p_cfg->p_tx_que, p_cfg->tx_que_len, byte_len))),
                          SSP_ERR_QUEUE_UNAVAILABLE);
#endif
    return SSP_SUCCESS;
}  /* End of function r_sci_queue_init() */

/*******************************************************************************************************************//**
 * This function detaches queue from the channel.
 * @param[in] p_ctrl    Pointer to the BYTEQ control block for the channel
 * @retval  SSP_SUCCESS                  Circular buffer for a channel finalized successfully
 * @retval  SSP_ERR_QUEUE_UNAVAILABLE    No queue control blocks available
 * @note This function is reentrant.
 **********************************************************************************************************************/
static ssp_err_t r_sci_queue_finalize (byteq_ctrl_t * const p_ctrl)
{
    if (SSP_SUCCESS != R_BYTEQ_Close(p_ctrl))
    {
        return SSP_ERR_QUEUE_UNAVAILABLE;
    }

    return SSP_SUCCESS;
} /* End of function r_sci_queue_finalize() */

/*******************************************************************************************************************//**
 * Reception data read for UART
 * @param[in] channel    Channel number of SCI module
 * @retval    Data read out from the data register (or the FIFO register)
 **********************************************************************************************************************/
static uint16_t r_sci_uart_reg_read (uint32_t const channel)
{
#if (SCI_UART_CFG_HW_FIFO_ENABLE)
    return HW_SCI_ReadFIFO(channel);
#else
    if (HW_SCI_IsDataLength9bits(channel))
    {
        return HW_SCI_Read9bits(channel);
    }
    else
    {
        return HW_SCI_Read(channel);
    }
#endif /* if (SCI_UART_CFG_HW_FIFO_ENABLE) */
}  /* End of function r_sci_uart_reg_read () */

/*******************************************************************************************************************//**
 * Transmit data write for UART
 * @param[in] channel    Channel number of SCI module
 * @param[in] data       Data to write to the data register (or the FIFO register)
 * @retval    none
 **********************************************************************************************************************/
static void r_sci_uart_reg_write (uint32_t const channel, uint16_t data)
{
#if (SCI_UART_CFG_HW_FIFO_ENABLE)
    if (SCI_FIFO_STAGE_NUM != HW_SCI_FIFO_WriteCount(channel))
    {
        HW_SCI_WriteFIFO(channel, data);
    }

#else
    if (HW_SCI_IsDataLength9bits(channel))
    {
        HW_SCI_Write9bits(channel, data);
    }
    else
    {
        HW_SCI_Write(channel, data);
    }
#endif /* if (SCI_UART_CFG_HW_FIFO_ENABLE) */
}  /* End of function r_sci_uart_reg_write () */

#if (SCI_UART_CFG_HW_FIFO_ENABLE)

/*******************************************************************************************************************//**
 * Resets FIFO related registers
 * @param[in]     p_cfg   Pointer to UART specific configuration structure
 * @retval        none
 **********************************************************************************************************************/
static void r_sci_uart_fifo_reset (uart_cfg_t const * const p_cfg)
{
    HW_SCI_FifoDisable(p_cfg->channel);                    /** disables FIFO mode */

#if (SCI_UART_CFG_RX_ENABLE)
    HW_SCI_ReceiveFifoReset(p_cfg->channel);                              /** resets receive FIFO mode */
    HW_SCI_RxTriggerNumberSet(p_cfg->channel, (SCI_FIFO_STAGE_NUM >> 1)); /** sets receive trigger number as half or
                                                                           * FIFO stage */
    HW_SCI_RTSTriggerNumberSet(p_cfg->channel, (SCI_FIFO_STAGE_NUM - 1)); /* sets RTS trigger number */
#endif
#if (SCI_UART_CFG_TX_ENABLE)
    HW_SCI_TransmitFifoReset(p_cfg->channel);                            /** resets transmit FIFO mode */
    HW_SCI_TxTriggerNumberSet(p_cfg->channel, (SCI_FIFO_STAGE_NUM - 1)); /* sets transmit trigger number */
#endif
}  /* End of function r_sci_uart_fifo_reset() */

/*******************************************************************************************************************//**
 * Enable FIFO
 * @param[in]     p_cfg   Pointer to UART specific configuration structure
 * @retval        none
 **********************************************************************************************************************/
static void r_sci_uart_fifo_enable (uart_cfg_t const * const p_cfg)
{
    while (0 != HW_SCI_ReceiveFifoResetStatusRead(p_cfg->channel))
    {
        /* FIFO reset status is automatically cleared after 1 peripheral clock for SCI */
    }

    while (0 != HW_SCI_TransmitFifoResetStatusRead(p_cfg->channel))
    {
        /* FIFO reset status is automatically cleared after 1 peripheral clock for SCI */
    }

    HW_SCI_FifoEnable(p_cfg->channel);                 /** enables FIFO mode */
}  /* End of function r_sci_uart_fifo_enable() */

/*******************************************************************************************************************//**
 * Data transfer from the transmit queue to the FIFO register in TXI interrupt
 * @param[in] channel    Channel number of SCI module
 * @retval    Circular buffer status. Returns QUE_STATUS_EMPTY if queue is empty, or QUE_STATUS_NOT_EMPTY if not.
 **********************************************************************************************************************/
static buf_status_t r_sci_uart_que2reg_fifo_write (uint32_t const channel)
{
    buf_status_t err       = QUE_STATUS_NOT_EMPTY;
    uart_ctrl_t  * puctrl  = (uart_ctrl_t *) g_sci_ctrl_blk[channel].p_context;
    uint16_t     fifo_rest = SCI_FIFO_STAGE_NUM - HW_SCI_FIFO_WriteCount(channel);
    uint16_t     cbuf_rest;
    uint16_t     data;

    HW_SCI_TDFEClear(channel);

    while (fifo_rest--)
    {
        if (SSP_SUCCESS == R_BYTEQ_Get(puctrl->u_tx_data.p_que, &data))
        {
            r_sci_uart_reg_write(channel, data);

            R_BYTEQ_Used(puctrl->u_tx_data.p_que, &cbuf_rest);
            if (0 == cbuf_rest)
            {
                return QUE_STATUS_EMPTY;
            }
        }
        else
        {
            return QUE_STATUS_EMPTY;
        }
    }

    return err;
}  /* End of function r_sci_uart_que2reg_fifo_write () */

#else /* if (SCI_UART_CFG_HW_FIFO_ENABLE) */

/*******************************************************************************************************************//**
 * Data transfer from the transmit queue to the data register in TXI interrupt
 * @param[in] channel    Channel number of SCI module
 * @retval    Circular buffer status. Returns QUE_STATUS_EMPTY if queue is empty, or QUE_STATUS_NOT_EMPTY if not.
 **********************************************************************************************************************/
static buf_status_t r_sci_uart_que2reg_write (uint32_t const channel)
{
    uint16_t    data;
    uart_ctrl_t * pctrl = (uart_ctrl_t *) g_sci_ctrl_blk[channel].p_context;

    if (SSP_SUCCESS == R_BYTEQ_Get(pctrl->u_tx_data.p_que, &data))
    {
        r_sci_uart_reg_write(channel, data);
        return QUE_STATUS_NOT_EMPTY;
    }

    return QUE_STATUS_EMPTY;
}  /* End of function r_sci_uart_que2reg_write () */
#endif /* if (SCI_UART_CFG_HW_FIFO_ENABLE) */

/*******************************************************************************************************************//**
 * Changes baud rate. It evaluates and determines the best possible settings set to the baud rate related registers.
 * @param[in] channel      Channel number of SCI module
 * @param[in] clk_src      A clock source for SCI module (SCI_CLK_SRC_INT|SCI_CLK_SRC_EXT8X|SCI_CLK_SRC_EXT16X)
 * @param[in] baudrate     Baud rate[bps] e.g. 19200, 57600, 115200, etc.
 * @retval  SSP_SUCCESS                  Baud rate is set successfully
 * @retval  SSP_ERR_INVALID_ARGUMENT     Baud rate is '0' or cannot set properly
 * @note   The transmitter and receiver (TE and RE bits in SCR) must be disabled prior to calling this function.
 **********************************************************************************************************************/
static ssp_err_t  r_sci_uart_baud_set (uint32_t const channel, sci_clk_src_t clk_src, uint32_t baudrate)
{
    uint32_t       i   = 8;
    uint32_t       hit = 0;
    uint32_t       brr = 255;
    uint32_t       temp_brr;
    int32_t        bit_err;
    int32_t        temp_bit_err = 10000;
    uint32_t       divisor;
    baud_setting_t * pbaudinfo;

#if (SCI_UART_CFG_PARAM_CHECKING_ENABLE)
    SCI_UART_ERROR_RETURN((0 != baudrate), SSP_ERR_INVALID_ARGUMENT);
#endif

    /* selects proper table based upon mode */
    pbaudinfo = (baud_setting_t *) async_baud;

    if (SCI_CLK_SRC_INT == clk_src)
    {
        /* FIND BEST_BRR_VALUE
         *  In table async_baud", divisor value is associated with BGDM, ABCS, ABCSE and N values, so once best divisor
         * value is found,
         *  baud rate related register setting values are decided. The formula to calculate BRR is as follows and it
         * must be 255 or less.
         *  BRR = (PCLKA/(div_coefficient * baud)) - 1
         */
        for (i = 0; i < NUM_DIVISORS_ASYNC; i++)
        {
            uint32_t freq_hz;
            SCI_UART_ERROR_RETURN((SSP_SUCCESS == (g_cgc_on_cgc.systemClockFreqGet(CGC_SYSTEM_CLOCKS_PCLKA, &freq_hz))),
                                  SSP_ERR_INVALID_ARGUMENT);

            temp_brr = freq_hz / (pbaudinfo[i].div_coefficient * baudrate);
            if (0 < temp_brr)
            {
                temp_brr -= 1;

                /* Calculate the bit rate error and have a best selection. The formula is as follows.
                 *  bit error[%] = {(PCLK / (baud * div_coefficient * (BRR + 1)) - 1} x 100
                 *  calculates bit error[%] to two decimal places
                 */
                divisor   = (temp_brr + 1) * (uint32_t) pbaudinfo[i].div_coefficient;
                divisor  *= baudrate;
                divisor >>= 9;  /* This prevents overflow beyond 32-bit size.  */
                bit_err   = (((freq_hz >> 9) * 10000L) / divisor) - 10000L;
                if (temp_brr < 256)
                {
                    if (bit_err < temp_bit_err)
                    {
                        hit          = i;
                        brr          = temp_brr;
                        temp_bit_err = bit_err;
                    }
                }
            }
        }

        SCI_UART_ERROR_RETURN((10000 != temp_bit_err), SSP_ERR_INVALID_ARGUMENT);

        HW_SCI_BaudRateGenInternalClkSelect(channel);

        HW_SCI_UartBitRateSet(channel, brr, &pbaudinfo[hit]);
    }
    else
    {
        HW_SCI_BitRateDefaultSet(channel);

        HW_SCI_BaudRateGenExternalClkSelect(channel);

        if (SCI_CLK_SRC_EXT8X == clk_src)
        {
            HW_SCI_BaudRateGenExternalClkDivideBy8(channel);
        }
        else
        {
            HW_SCI_BaudRateGenExternalClkDivideBy16(channel);
        }
    }

    return SSP_SUCCESS;
}  /* End of function r_sci_uart_baud_set() */

/*******************************************************************************************************************//**
 * TXI interrupt processing for UART mode. TXI interrupt happens when the data in the data register or FIFO register has
 *  to be transferred to the data shift register, and the next writing data to it is available. This function is
 *  repeatedly called from TXI ISR and continues data transfer until the transmit circular buffer becoming empty.
 * Finally
 *  this function disables TXI interrupt and enables TEI interrupt(@see r_sci_uart_tei()).
 * @param[in] channel    Channel number of SCI module
 * @retval    none
 **********************************************************************************************************************/
void r_sci_uart_txi_common (uint32_t const channel)
{
#if (SCI_UART_CFG_HW_FIFO_ENABLE)
    if (QUE_STATUS_EMPTY == r_sci_uart_que2reg_fifo_write(channel))
#else
    if (QUE_STATUS_EMPTY == r_sci_uart_que2reg_write(channel))
#endif
    {
        /* disables transmit interrupt */
        HW_SCI_InterruptEnable(channel, SCI_TX_INT, false);

        /* enables TEI
         * call-back function will be called when next TEI interrupt comes
         */
        HW_SCI_InterruptEnable(channel, SCI_TE_INT, true);
    }
}  /* End of function r_sci_uart_txi_common() */

/*******************************************************************************************************************//**
 * RXI interrupt processing for UART mode. RXI interrupt happens when data arrives to the data register or the FIFO
 *  register, and queues the data to the receive circular buffer. This function calls callback function when it meets
 *  conditions below.
 *  - The number of data which has been read reaches to the number specified in R_SCI_UartRead()
 *(UART_EVENT_RX_COMPLETE)
 *  - Receive circular buffer overflows (UART_EVENT_ERR_RXBUF_OVERFLOW)
 *  This function also calls the callback function for RTS pin control if it is registered in R_SCI_UartOpen(). This is
 *  special functionality to expand SCI hardware capability and make RTS/CTS hardware flow control possible. If macro
 *  'SCI_UART_CFG_EXTERNAL_RTS_OPERATION' is set, it is called at the beginning in this function, and after queuing the
 * coming
 *  data done, it is called again (just before leaving this function). SCI UART module does not control any GPIOs but
 *  this callback function let user know the timing of RTS signal assert or negate but user have to control the GPIO pin
 *  which is used for RTS pin.
 * @param[in] channel    Channel number of SCI module
 * @retval    none
 **********************************************************************************************************************/
void r_sci_uart_rxi_common (uint32_t const channel)
{
    uint32_t             data             = 0;
    uart_callback_args_t args;
    uart_ctrl_t          * pctrl          = (uart_ctrl_t *) g_sci_ctrl_blk[channel].p_context;
    uint16_t             total_data_cnt   = 0;
    uint16_t             read_cnt;
    bool                 execute_callback = false;

#if (SCI_UART_CFG_EXTERNAL_RTS_OPERATION)
    if (g_sci_ctrl_blk[channel].p_extpin_ctrl)
    {
        g_sci_ctrl_blk[channel].p_extpin_ctrl(channel, 1);         /** user definition function call to control GPIO */
    }
#endif
#if (SCI_UART_CFG_HW_FIFO_ENABLE)
    read_cnt = HW_SCI_FIFO_ReadCount(channel);
#else
    read_cnt = 1;
#endif
    while (read_cnt--)
    {
        /* Read data */
        data = r_sci_uart_reg_read(channel);

        /* Place data into queue */
        if (SSP_SUCCESS != R_BYTEQ_Put(pctrl->u_rx_data.p_que, data))
        {
            args.event       = UART_EVENT_ERR_RXBUF_OVERFLOW;
            execute_callback = true;
        }
        else
        {
            R_BYTEQ_Used(pctrl->u_rx_data.p_que, &total_data_cnt);
            if ((0 != pctrl->expect_rdlen) && (pctrl->expect_rdlen <= total_data_cnt))
            {
                /* Read counter reached to expected read count.
                 * callback AMS function if registered.
                 */
                execute_callback = true;
            }

            args.event = UART_EVENT_RX_COMPLETE;
        }

        /* Do callback if available */
        if (execute_callback && (NULL != pctrl->p_callback))
        {
            args.channel        = channel;
            args.data           = data;
            args.p_context      = pctrl->p_context;
            pctrl->p_callback(&args);
//**EFS**            pctrl->expect_rdlen = 0;
            break;
        }
    }

#if (SCI_UART_CFG_EXTERNAL_RTS_OPERATION)
    if (g_sci_ctrl_blk[channel].p_extpin_ctrl)
    {
        g_sci_ctrl_blk[channel].p_extpin_ctrl(channel, 0);         /** user definition function call to control GPIO */
    }
#endif
}  /* End of function r_sci_uart_rxi_common () */

/*******************************************************************************************************************//**
 * TEI interrupt processing for UART mode. TEI interrupt happens at the timing of data transmit completion. The user
 * callback function is called with UART_EVENT_TX_COMPLETE event code (if it is registered in R_SCI_UartOpen()).
 * @param[in] channel    Channel number of SCI module
 * @retval    none
 **********************************************************************************************************************/
void r_sci_uart_tei (uint32_t const channel)
{
    uart_callback_args_t args;
    uart_ctrl_t          * pctrl = (uart_ctrl_t *) g_sci_ctrl_blk[channel].p_context;

    /* Receiving TEI(transmit end interrupt) means the completion of
     * transmission, so call call-back function here
     */
    HW_SCI_InterruptEnable(channel, SCI_TE_INT, false);
    if (NULL != pctrl->p_callback)
    {
        args.channel   = channel;
        args.data      = 0;
        args.event     = UART_EVENT_TX_COMPLETE;
        args.p_context = pctrl->p_context;
        pctrl->p_callback(&args);
    }

    /* Transmission ended */
    g_sci_ctrl_blk[channel].tx_busy = false;
}  /* End of function r_sci_uart_tei () */

/*******************************************************************************************************************//**
 * ERI interrupt processing for UART mode. When ERI interrupt happens, the user callback function is called if it is
 *  registered in R_SCI_UartOpen() with the event code which happen at the time.
 * @param[in] channel    Channel number of SCI module
 * @retval    none
 **********************************************************************************************************************/
void r_sci_uart_eri_common (uint32_t const channel)
{
    uint32_t             data;
    uart_callback_args_t args;
    uart_ctrl_t          * pctrl = (uart_ctrl_t *) g_sci_ctrl_blk[channel].p_context;

    /* Read data */
    data = r_sci_uart_reg_read(channel);

#if (SCI_UART_CFG_HW_FIFO_ENABLE)
    HW_SCI_RDFClear(channel);
#endif

    /* Error check */
    if (HW_SCI_OverRunErrorCheck(channel))
    {
        args.event = UART_EVENT_ERR_OVERFLOW;
    }
    else if (HW_SCI_FramingErrorCheck(channel))
    {
        if (HW_SCI_BreakDetectionCheck(channel))
        {
            args.event = UART_EVENT_BREAK_DETECT;
        }
        else
        {
            args.event = UART_EVENT_ERR_FRAMING;
        }
    }
    else
    {
        args.event = UART_EVENT_ERR_PARITY;
    }

    /* Do callback if available */
    if (NULL != pctrl->p_callback)
    {
        args.channel   = channel;
        args.data      = data;
        args.p_context = pctrl->p_context;
        pctrl->p_callback(&args);
    }
}  /* End of function r_sci_uart_eri_common () */
#endif /* if (SCI_CFG_ASYNC_INCLUDED) */
