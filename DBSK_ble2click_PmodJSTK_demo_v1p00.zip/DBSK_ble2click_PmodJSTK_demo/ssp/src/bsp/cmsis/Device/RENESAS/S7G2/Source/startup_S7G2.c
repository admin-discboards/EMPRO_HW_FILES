/***********************************************************************************************************************
 * Copyright [2015] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 *
 * The contents of this file (the �contents�) are proprietary and confidential to Renesas Electronics Corporation 
 * and/or its licensors (�Renesas�) and subject to statutory and contractual protections.
 *
 * Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
 * display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
 * purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
 * SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED �AS IS� WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
 * NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
 * OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
 * be subject to different terms.
 **********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : startup_S7G2.c
* Description  : Startup for the S7G2
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 22.07.2014 0.10     First Release
*         : 24.09.2014 0.20     Now use BSP_IRQ_DISABLED for preprocessor checking.
*         : 03.08.2015 0.30     Removed COMP_LP and Vbatt entries as they are specific to S3A7.
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "bsp_api.h"

/* Only build this file if this board is chosen. */
#if defined(BSP_MCU_GROUP_S7G2)

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
/* Defines function pointers to be used with vector table. */
typedef void (* exc_ptr_t)(void);

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
 
/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
void Reset_Handler(void);
int  main(void);

/***********************************************************************************************************************
* Function Name: Reset_Handler
* Description  : MCU starts executing here out of reset. Main stack pointer is setup already.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void Reset_Handler (void)
{
    /* Initialize system using BSP. */
    SystemInit();

    /* Call user application. */
    main();

    while (1)
    {
        /* Infinite Loop. */
    }
}

/***********************************************************************************************************************
* Function Name: Default_Handler
* Description  : Default exception handler.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void Default_Handler (void)
{
    while(1);
}

/* Stacks. */
/* Main stack */
static uint8_t g_main_stack[BSP_CFG_STACK_MAIN_BYTES] BSP_PLACE_IN_SECTION(BSP_SECTION_STACK);

/* Process stack */
#if (BSP_CFG_STACK_PROCESS_BYTES > 0)
BSP_DONT_REMOVE static uint8_t g_process_stack[BSP_CFG_STACK_PROCESS_BYTES] BSP_PLACE_IN_SECTION(BSP_SECTION_STACK);
#endif

/* Heap */
BSP_DONT_REMOVE static uint8_t g_heap[BSP_CFG_HEAP_BYTES] BSP_PLACE_IN_SECTION(BSP_SECTION_HEAP);

/* All system exceptions in the vector table are weak references to Default_Handler. If the user wishes to handle
 * these exceptions in their code they should define their own function with the same name.
 */
#if defined(__ICCARM__)
#define WEAK_REF_ATTRIBUTE

#pragma weak HardFault_Handler                        = Default_Handler
#pragma weak MemManage_Handler                        = Default_Handler
#pragma weak BusFault_Handler                         = Default_Handler
#pragma weak UsageFault_Handler                       = Default_Handler
#pragma weak SVC_Handler                              = Default_Handler
#pragma weak DebugMon_Handler                         = Default_Handler
#pragma weak PendSV_Handler                           = Default_Handler
#pragma weak SysTick_Handler                          = Default_Handler
#pragma weak port0_irq_isr                            = Default_Handler
#pragma weak port1_irq_isr                            = Default_Handler
#pragma weak port2_irq_isr                            = Default_Handler
#pragma weak port3_irq_isr                            = Default_Handler
#pragma weak port4_irq_isr                            = Default_Handler
#pragma weak port5_irq_isr                            = Default_Handler
#pragma weak port6_irq_isr                            = Default_Handler
#pragma weak port7_irq_isr                            = Default_Handler
#pragma weak port8_irq_isr                            = Default_Handler
#pragma weak port9_irq_isr                            = Default_Handler
#pragma weak port10_irq_isr                           = Default_Handler
#pragma weak port11_irq_isr                           = Default_Handler
#pragma weak port12_irq_isr                           = Default_Handler
#pragma weak port13_irq_isr                           = Default_Handler
#pragma weak port14_irq_isr                           = Default_Handler
#pragma weak port15_irq_isr                           = Default_Handler
#pragma weak dmac0_dmac_isr                           = Default_Handler
#pragma weak dmac1_dmac_isr                           = Default_Handler
#pragma weak dmac2_dmac_isr                           = Default_Handler
#pragma weak dmac3_dmac_isr                           = Default_Handler
#pragma weak dmac4_dmac_isr                           = Default_Handler
#pragma weak dmac5_dmac_isr                           = Default_Handler
#pragma weak dmac6_dmac_isr                           = Default_Handler
#pragma weak dmac7_dmac_isr                           = Default_Handler
#pragma weak dtc_transfer_isr                         = Default_Handler
#pragma weak dtc_complete_isr                         = Default_Handler
#pragma weak dtc_dtc_end_isr                          = Default_Handler
#pragma weak exdmac0_exdmac_isr                       = Default_Handler
#pragma weak exdmac1_exdmac_isr                       = Default_Handler
#pragma weak icu_canceling_snooze_mode_isr            = Default_Handler
#pragma weak fcu_fiferr_isr                           = Default_Handler
#pragma weak fcu_frdyi_isr                            = Default_Handler
#pragma weak fcu_eccerr_isr                           = Default_Handler
#pragma weak lvd1_lvd1_isr                            = Default_Handler
#pragma weak lvd2_lvd2_isr                            = Default_Handler
#pragma weak vbatt_vbat_isr                           = Default_Handler
#pragma weak mosc_osc_stop_isr                        = Default_Handler
#pragma weak cpusys_snooze_mode_entry_flag_isr        = Default_Handler
#pragma weak agt0_agti_isr                            = Default_Handler
#pragma weak agt0_agtcmai_isr                         = Default_Handler
#pragma weak agt0_agtcmbi_isr                         = Default_Handler
#pragma weak agt1_agti_isr                            = Default_Handler
#pragma weak agt1_agtcmai_isr                         = Default_Handler
#pragma weak agt1_agtcmbi_isr                         = Default_Handler
#pragma weak iwdt_nmiundf_n_isr                       = Default_Handler
#pragma weak cwdt_nmiundf_n_isr                       = Default_Handler
#pragma weak rtc_alm_isr                              = Default_Handler
#pragma weak rtc_prd_isr                              = Default_Handler
#pragma weak rtc_cup_isr                              = Default_Handler
#pragma weak s12ad0_adi_isr                           = Default_Handler
#pragma weak s12ad0_gbadi_isr                         = Default_Handler
#pragma weak s12ad0_cmpai_isr                         = Default_Handler
#pragma weak s12ad0_cmpbi_isr                         = Default_Handler
#pragma weak s12ad0_compare_match_isr                 = Default_Handler
#pragma weak s12ad0_compare_mismatch_isr              = Default_Handler
#pragma weak s12ad1_adi_isr                           = Default_Handler
#pragma weak s12ad1_gbadi_isr                         = Default_Handler
#pragma weak s12ad1_cmpai_isr                         = Default_Handler
#pragma weak s12ad1_cmpbi_isr                         = Default_Handler
#pragma weak s12ad1_compare_match_isr                 = Default_Handler
#pragma weak s12ad1_compare_mismatch_isr              = Default_Handler
#pragma weak comp_oc0_comp_irq_isr                    = Default_Handler
#pragma weak comp_rd1_comp_irq_isr                    = Default_Handler
#pragma weak comp_rd2_comp_irq_isr                    = Default_Handler
#pragma weak comp_rd3_comp_irq_isr                    = Default_Handler
#pragma weak comp_rd4_comp_irq_isr                    = Default_Handler
#pragma weak comp_rd5_comp_irq_isr                    = Default_Handler
#pragma weak comp_lp_comp_c0irq_isr                   = Default_Handler
#pragma weak comp_lp_comp_c1irq_isr                   = Default_Handler
#pragma weak usbfs_d0fifo_isr                         = Default_Handler
#pragma weak usbfs_d1fifo_isr                         = Default_Handler
#pragma weak usbfs_usbi_isr                           = Default_Handler
#pragma weak usbfs_usbr_isr                           = Default_Handler
#pragma weak riic0_rxi_isr                            = Default_Handler
#pragma weak riic0_txi_isr                            = Default_Handler
#pragma weak riic0_tei_isr                            = Default_Handler
#pragma weak riic0_eei_isr                            = Default_Handler
#pragma weak riic0_wui_isr                            = Default_Handler
#pragma weak riic1_rxi_isr                            = Default_Handler
#pragma weak riic1_txi_isr                            = Default_Handler
#pragma weak riic1_tei_isr                            = Default_Handler
#pragma weak riic1_eei_isr                            = Default_Handler
#pragma weak riic2_rxi_isr                            = Default_Handler
#pragma weak riic2_txi_isr                            = Default_Handler
#pragma weak riic2_tei_isr                            = Default_Handler
#pragma weak riic2_eei_isr                            = Default_Handler
#pragma weak ssi0_ssitxi_isr                          = Default_Handler
#pragma weak ssi0_ssirxi_isr                          = Default_Handler
#pragma weak ssi0_ssirt_isr                           = Default_Handler
#pragma weak ssi0_ssif_isr                            = Default_Handler
#pragma weak ssi1_ssitxi_isr                          = Default_Handler
#pragma weak ssi1_ssirxi_isr                          = Default_Handler
#pragma weak ssi1_ssirt_isr                           = Default_Handler
#pragma weak ssi1_ssif_isr                            = Default_Handler
#pragma weak src_idei_isr                             = Default_Handler
#pragma weak src_odfi_isr                             = Default_Handler
#pragma weak src_ovf_isr                              = Default_Handler
#pragma weak src_udf_isr                              = Default_Handler
#pragma weak src_cef_isr                              = Default_Handler
#pragma weak pdc_pcdfi_isr                            = Default_Handler
#pragma weak pdc_pcfei_isr                            = Default_Handler
#pragma weak pdc_pceri_isr                            = Default_Handler
#pragma weak ctsu_ctsuwr_isr                          = Default_Handler
#pragma weak ctsu_ctsurd_isr                          = Default_Handler
#pragma weak ctsu_ctsufn_isr                          = Default_Handler
#pragma weak key_intkr_isr                            = Default_Handler
#pragma weak doc_dopcf_isr                            = Default_Handler
#pragma weak cac_ferrf_isr                            = Default_Handler
#pragma weak cac_mendf_isr                            = Default_Handler
#pragma weak cac_ovff_isr                             = Default_Handler
#pragma weak rcan20_ers_isr                           = Default_Handler
#pragma weak rcan20_rxf_isr                           = Default_Handler
#pragma weak rcan20_txf_isr                           = Default_Handler
#pragma weak rcan20_rxm_isr                           = Default_Handler
#pragma weak rcan20_txm_isr                           = Default_Handler
#pragma weak rcan21_ers_isr                           = Default_Handler
#pragma weak rcan21_rxf_isr                           = Default_Handler
#pragma weak rcan21_txf_isr                           = Default_Handler
#pragma weak rcan21_rxm_isr                           = Default_Handler
#pragma weak rcan21_txm_isr                           = Default_Handler
#pragma weak gpio_port_group_a_isr                    = Default_Handler
#pragma weak gpio_port_group_b_isr                    = Default_Handler
#pragma weak gpio_port_group_c_isr                    = Default_Handler
#pragma weak gpio_port_group_d_isr                    = Default_Handler
#pragma weak elc0_software_event_isr                  = Default_Handler
#pragma weak elc1_software_event_isr                  = Default_Handler
#pragma weak poeg_group_event0_isr                    = Default_Handler
#pragma weak poeg_group_event1_isr                    = Default_Handler
#pragma weak poeg_group_event2_isr                    = Default_Handler
#pragma weak poeg_group_event3_isr                    = Default_Handler
#pragma weak gpt0_capture_compare_int_a_isr           = Default_Handler
#pragma weak gpt0_capture_compare_int_b_isr           = Default_Handler
#pragma weak gpt0_compare_int_c_isr                   = Default_Handler
#pragma weak gpt0_compare_int_d_isr                   = Default_Handler
#pragma weak gpt0_compare_int_e_isr                   = Default_Handler
#pragma weak gpt0_compare_int_f_isr                   = Default_Handler
#pragma weak gpt0_counter_overflow_isr                = Default_Handler
#pragma weak gpt0_counter_underflow_isr               = Default_Handler
#pragma weak gpt0_ad_trig_a_isr                       = Default_Handler
#pragma weak gpt0_ad_trig_b_isr                       = Default_Handler
#pragma weak gpt1_capture_compare_int_a_isr           = Default_Handler
#pragma weak gpt1_capture_compare_int_b_isr           = Default_Handler
#pragma weak gpt1_compare_int_c_isr                   = Default_Handler
#pragma weak gpt1_compare_int_d_isr                   = Default_Handler
#pragma weak gpt1_compare_int_e_isr                   = Default_Handler
#pragma weak gpt1_compare_int_f_isr                   = Default_Handler
#pragma weak gpt1_counter_overflow_isr                = Default_Handler
#pragma weak gpt1_counter_underflow_isr               = Default_Handler
#pragma weak gpt1_ad_trig_a_isr                       = Default_Handler
#pragma weak gpt1_ad_trig_b_isr                       = Default_Handler
#pragma weak gpt2_capture_compare_int_a_isr           = Default_Handler
#pragma weak gpt2_capture_compare_int_b_isr           = Default_Handler
#pragma weak gpt2_compare_int_c_isr                   = Default_Handler
#pragma weak gpt2_compare_int_d_isr                   = Default_Handler
#pragma weak gpt2_compare_int_e_isr                   = Default_Handler
#pragma weak gpt2_compare_int_f_isr                   = Default_Handler
#pragma weak gpt2_counter_overflow_isr                = Default_Handler
#pragma weak gpt2_counter_underflow_isr               = Default_Handler
#pragma weak gpt2_ad_trig_a_isr                       = Default_Handler
#pragma weak gpt2_ad_trig_b_isr                       = Default_Handler
#pragma weak gpt3_capture_compare_int_a_isr           = Default_Handler
#pragma weak gpt3_capture_compare_int_b_isr           = Default_Handler
#pragma weak gpt3_compare_int_c_isr                   = Default_Handler
#pragma weak gpt3_compare_int_d_isr                   = Default_Handler
#pragma weak gpt3_compare_int_e_isr                   = Default_Handler
#pragma weak gpt3_compare_int_f_isr                   = Default_Handler
#pragma weak gpt3_counter_overflow_isr                = Default_Handler
#pragma weak gpt3_counter_underflow_isr               = Default_Handler
#pragma weak gpt3_ad_trig_a_isr                       = Default_Handler
#pragma weak gpt3_ad_trig_b_isr                       = Default_Handler
#pragma weak gpt4_capture_compare_int_a_isr           = Default_Handler
#pragma weak gpt4_capture_compare_int_b_isr           = Default_Handler
#pragma weak gpt4_compare_int_c_isr                   = Default_Handler
#pragma weak gpt4_compare_int_d_isr                   = Default_Handler
#pragma weak gpt4_compare_int_e_isr                   = Default_Handler
#pragma weak gpt4_compare_int_f_isr                   = Default_Handler
#pragma weak gpt4_counter_overflow_isr                = Default_Handler
#pragma weak gpt4_counter_underflow_isr               = Default_Handler
#pragma weak gpt4_ad_trig_a_isr                       = Default_Handler
#pragma weak gpt4_ad_trig_b_isr                       = Default_Handler
#pragma weak gpt5_capture_compare_int_a_isr           = Default_Handler
#pragma weak gpt5_capture_compare_int_b_isr           = Default_Handler
#pragma weak gpt5_compare_int_c_isr                   = Default_Handler
#pragma weak gpt5_compare_int_d_isr                   = Default_Handler
#pragma weak gpt5_compare_int_e_isr                   = Default_Handler
#pragma weak gpt5_compare_int_f_isr                   = Default_Handler
#pragma weak gpt5_counter_overflow_isr                = Default_Handler
#pragma weak gpt5_counter_underflow_isr               = Default_Handler
#pragma weak gpt5_ad_trig_a_isr                       = Default_Handler
#pragma weak gpt5_ad_trig_b_isr                       = Default_Handler
#pragma weak gpt6_capture_compare_int_a_isr           = Default_Handler
#pragma weak gpt6_capture_compare_int_b_isr           = Default_Handler
#pragma weak gpt6_compare_int_c_isr                   = Default_Handler
#pragma weak gpt6_compare_int_d_isr                   = Default_Handler
#pragma weak gpt6_compare_int_e_isr                   = Default_Handler
#pragma weak gpt6_compare_int_f_isr                   = Default_Handler
#pragma weak gpt6_counter_overflow_isr                = Default_Handler
#pragma weak gpt6_counter_underflow_isr               = Default_Handler
#pragma weak gpt6_ad_trig_a_isr                       = Default_Handler
#pragma weak gpt6_ad_trig_b_isr                       = Default_Handler
#pragma weak gpt7_capture_compare_int_a_isr           = Default_Handler
#pragma weak gpt7_capture_compare_int_b_isr           = Default_Handler
#pragma weak gpt7_compare_int_c_isr                   = Default_Handler
#pragma weak gpt7_compare_int_d_isr                   = Default_Handler
#pragma weak gpt7_compare_int_e_isr                   = Default_Handler
#pragma weak gpt7_compare_int_f_isr                   = Default_Handler
#pragma weak gpt7_counter_overflow_isr                = Default_Handler
#pragma weak gpt7_counter_underflow_isr               = Default_Handler
#pragma weak gpt7_ad_trig_a_isr                       = Default_Handler
#pragma weak gpt7_ad_trig_b_isr                       = Default_Handler
#pragma weak gpt8_capture_compare_int_a_isr           = Default_Handler
#pragma weak gpt8_capture_compare_int_b_isr           = Default_Handler
#pragma weak gpt8_compare_int_c_isr                   = Default_Handler
#pragma weak gpt8_compare_int_d_isr                   = Default_Handler
#pragma weak gpt8_compare_int_e_isr                   = Default_Handler
#pragma weak gpt8_compare_int_f_isr                   = Default_Handler
#pragma weak gpt8_counter_overflow_isr                = Default_Handler
#pragma weak gpt8_counter_underflow_isr               = Default_Handler
#pragma weak gpt8_ad_trig_a_isr                       = Default_Handler
#pragma weak gpt8_ad_trig_b_isr                       = Default_Handler
#pragma weak gpt9_capture_compare_int_a_isr           = Default_Handler
#pragma weak gpt9_capture_compare_int_b_isr           = Default_Handler
#pragma weak gpt9_compare_int_c_isr                   = Default_Handler
#pragma weak gpt9_compare_int_d_isr                   = Default_Handler
#pragma weak gpt9_compare_int_e_isr                   = Default_Handler
#pragma weak gpt9_compare_int_f_isr                   = Default_Handler
#pragma weak gpt9_counter_overflow_isr                = Default_Handler
#pragma weak gpt9_counter_underflow_isr               = Default_Handler
#pragma weak gpt9_ad_trig_a_isr                       = Default_Handler
#pragma weak gpt9_ad_trig_b_isr                       = Default_Handler
#pragma weak gpt10_capture_compare_int_a_isr          = Default_Handler
#pragma weak gpt10_capture_compare_int_b_isr          = Default_Handler
#pragma weak gpt10_compare_int_c_isr                  = Default_Handler
#pragma weak gpt10_compare_int_d_isr                  = Default_Handler
#pragma weak gpt10_compare_int_e_isr                  = Default_Handler
#pragma weak gpt10_compare_int_f_isr                  = Default_Handler
#pragma weak gpt10_counter_overflow_isr               = Default_Handler
#pragma weak gpt10_counter_underflow_isr              = Default_Handler
#pragma weak gpt10_ad_trig_a_isr                      = Default_Handler
#pragma weak gpt10_ad_trig_b_isr                      = Default_Handler
#pragma weak gpt11_capture_compare_int_a_isr          = Default_Handler
#pragma weak gpt11_capture_compare_int_b_isr          = Default_Handler
#pragma weak gpt11_compare_int_c_isr                  = Default_Handler
#pragma weak gpt11_compare_int_d_isr                  = Default_Handler
#pragma weak gpt11_compare_int_e_isr                  = Default_Handler
#pragma weak gpt11_compare_int_f_isr                  = Default_Handler
#pragma weak gpt11_counter_overflow_isr               = Default_Handler
#pragma weak gpt11_counter_underflow_isr              = Default_Handler
#pragma weak gpt11_ad_trig_a_isr                      = Default_Handler
#pragma weak gpt11_ad_trig_b_isr                      = Default_Handler
#pragma weak gpt12_capture_compare_int_a_isr          = Default_Handler
#pragma weak gpt12_capture_compare_int_b_isr          = Default_Handler
#pragma weak gpt12_compare_int_c_isr                  = Default_Handler
#pragma weak gpt12_compare_int_d_isr                  = Default_Handler
#pragma weak gpt12_compare_int_e_isr                  = Default_Handler
#pragma weak gpt12_compare_int_f_isr                  = Default_Handler
#pragma weak gpt12_counter_overflow_isr               = Default_Handler
#pragma weak gpt12_counter_underflow_isr              = Default_Handler
#pragma weak gpt12_ad_trig_a_isr                      = Default_Handler
#pragma weak gpt12_ad_trig_b_isr                      = Default_Handler
#pragma weak gpt13_capture_compare_int_a_isr          = Default_Handler
#pragma weak gpt13_capture_compare_int_b_isr          = Default_Handler
#pragma weak gpt13_compare_int_c_isr                  = Default_Handler
#pragma weak gpt13_compare_int_d_isr                  = Default_Handler
#pragma weak gpt13_compare_int_e_isr                  = Default_Handler
#pragma weak gpt13_compare_int_f_isr                  = Default_Handler
#pragma weak gpt13_counter_overflow_isr               = Default_Handler
#pragma weak gpt13_counter_underflow_isr              = Default_Handler
#pragma weak gpt13_ad_trig_a_isr                      = Default_Handler
#pragma weak gpt13_ad_trig_b_isr                      = Default_Handler
#pragma weak gpt14_capture_compare_int_a_isr          = Default_Handler
#pragma weak gpt14_capture_compare_int_b_isr          = Default_Handler
#pragma weak gpt14_compare_int_c_isr                  = Default_Handler
#pragma weak gpt14_compare_int_d_isr                  = Default_Handler
#pragma weak gpt14_compare_int_e_isr                  = Default_Handler
#pragma weak gpt14_compare_int_f_isr                  = Default_Handler
#pragma weak gpt14_counter_overflow_isr               = Default_Handler
#pragma weak gpt14_counter_underflow_isr              = Default_Handler
#pragma weak gpt14_ad_trig_a_isr                      = Default_Handler
#pragma weak gpt14_ad_trig_b_isr                      = Default_Handler
#pragma weak gpt15_capture_compare_int_a_isr          = Default_Handler
#pragma weak gpt15_capture_compare_int_b_isr          = Default_Handler
#pragma weak gpt15_compare_int_c_isr                  = Default_Handler
#pragma weak gpt15_compare_int_d_isr                  = Default_Handler
#pragma weak gpt15_compare_int_e_isr                  = Default_Handler
#pragma weak gpt15_compare_int_f_isr                  = Default_Handler
#pragma weak gpt15_counter_overflow_isr               = Default_Handler
#pragma weak gpt15_counter_underflow_isr              = Default_Handler
#pragma weak gpt15_ad_trig_a_isr                      = Default_Handler
#pragma weak gpt15_ad_trig_b_isr                      = Default_Handler
#pragma weak gpt_uvw_edge_isr                         = Default_Handler
#pragma weak ether_ipls_isr                           = Default_Handler
#pragma weak ether_mint_isr                           = Default_Handler
#pragma weak ether_pint_isr                           = Default_Handler
#pragma weak ether_eint0_isr                          = Default_Handler
#pragma weak ether_eint1_isr                          = Default_Handler
#pragma weak ether_ether0_rise_isr                    = Default_Handler
#pragma weak ether_ether1_rise_isr                    = Default_Handler
#pragma weak ether_ether2_rise_isr                    = Default_Handler
#pragma weak ether_ether3_rise_isr                    = Default_Handler
#pragma weak ether_ether4_rise_isr                    = Default_Handler
#pragma weak ether_ether5_rise_isr                    = Default_Handler
#pragma weak ether_ether0_fall_isr                    = Default_Handler
#pragma weak ether_ether1_fall_isr                    = Default_Handler
#pragma weak ether_ether2_fall_isr                    = Default_Handler
#pragma weak ether_ether3_fall_isr                    = Default_Handler
#pragma weak ether_ether4_fall_isr                    = Default_Handler
#pragma weak ether_ether5_fall_isr                    = Default_Handler
#pragma weak usbhs_d0fifo_isr                         = Default_Handler
#pragma weak usbhs_d1fifo_isr                         = Default_Handler
#pragma weak usbhs_usbir_isr                          = Default_Handler
#pragma weak sci0_rxi_isr                             = Default_Handler
#pragma weak sci0_txi_isr                             = Default_Handler
#pragma weak sci0_tei_isr                             = Default_Handler
#pragma weak sci0_eri_isr                             = Default_Handler
#pragma weak sci0_am_isr                              = Default_Handler
#pragma weak sci0_rxi_or_eri_isr                      = Default_Handler
#pragma weak sci1_rxi_isr                             = Default_Handler
#pragma weak sci1_txi_isr                             = Default_Handler
#pragma weak sci1_tei_isr                             = Default_Handler
#pragma weak sci1_eri_isr                             = Default_Handler
#pragma weak sci1_am_isr                              = Default_Handler
#pragma weak sci2_rxi_isr                             = Default_Handler
#pragma weak sci2_txi_isr                             = Default_Handler
#pragma weak sci2_tei_isr                             = Default_Handler
#pragma weak sci2_eri_isr                             = Default_Handler
#pragma weak sci2_am_isr                              = Default_Handler
#pragma weak sci3_rxi_isr                             = Default_Handler
#pragma weak sci3_txi_isr                             = Default_Handler
#pragma weak sci3_tei_isr                             = Default_Handler
#pragma weak sci3_eri_isr                             = Default_Handler
#pragma weak sci3_am_isr                              = Default_Handler
#pragma weak sci4_rxi_isr                             = Default_Handler
#pragma weak sci4_txi_isr                             = Default_Handler
#pragma weak sci4_tei_isr                             = Default_Handler
#pragma weak sci4_eri_isr                             = Default_Handler
#pragma weak sci4_am_isr                              = Default_Handler
#pragma weak sci5_rxi_isr                             = Default_Handler
#pragma weak sci5_txi_isr                             = Default_Handler
#pragma weak sci5_tei_isr                             = Default_Handler
#pragma weak sci5_eri_isr                             = Default_Handler
#pragma weak sci5_am_isr                              = Default_Handler
#pragma weak sci6_rxi_isr                             = Default_Handler
#pragma weak sci6_txi_isr                             = Default_Handler
#pragma weak sci6_tei_isr                             = Default_Handler
#pragma weak sci6_eri_isr                             = Default_Handler
#pragma weak sci6_am_isr                              = Default_Handler
#pragma weak sci7_rxi_isr                             = Default_Handler
#pragma weak sci7_txi_isr                             = Default_Handler
#pragma weak sci7_tei_isr                             = Default_Handler
#pragma weak sci7_eri_isr                             = Default_Handler
#pragma weak sci7_am_isr                              = Default_Handler
#pragma weak sci8_rxi_isr                             = Default_Handler
#pragma weak sci8_txi_isr                             = Default_Handler
#pragma weak sci8_tei_isr                             = Default_Handler
#pragma weak sci8_eri_isr                             = Default_Handler
#pragma weak sci8_am_isr                              = Default_Handler
#pragma weak sci9_rxi_isr                             = Default_Handler
#pragma weak sci9_txi_isr                             = Default_Handler
#pragma weak sci9_tei_isr                             = Default_Handler
#pragma weak sci9_eri_isr                             = Default_Handler
#pragma weak sci9_am_isr                              = Default_Handler
#pragma weak rspi0_spri_isr                           = Default_Handler
#pragma weak rspi0_spti_isr                           = Default_Handler
#pragma weak rspi0_spii_isr                           = Default_Handler
#pragma weak rspi0_spei_isr                           = Default_Handler
#pragma weak rspi0_sp_elctend_isr                     = Default_Handler
#pragma weak rspi1_spri_isr                           = Default_Handler
#pragma weak rspi1_spti_isr                           = Default_Handler
#pragma weak rspi1_spii_isr                           = Default_Handler
#pragma weak rspi1_spei_isr                           = Default_Handler
#pragma weak rspi1_sp_elctend_isr                     = Default_Handler
#pragma weak qspi_intr_isr                            = Default_Handler
#pragma weak sdhi_mmc0_accs_isr                       = Default_Handler
#pragma weak sdhi_mmc0_sdio_isr                       = Default_Handler
#pragma weak sdhi_mmc0_card_isr                       = Default_Handler
#pragma weak sdhi_mmc0_odmsdbreq_isr                  = Default_Handler
#pragma weak sdhi_mmc1_accs_isr                       = Default_Handler
#pragma weak sdhi_mmc1_sdio_isr                       = Default_Handler
#pragma weak sdhi_mmc1_card_isr                       = Default_Handler
#pragma weak sdhi_mmc1_odmsdbreq_isr                  = Default_Handler
#pragma weak ext_divider_intmd_isr                    = Default_Handler
#pragma weak tsip_proc_busy_n_isr                     = Default_Handler
#pragma weak tsip_romok_n_isr                         = Default_Handler
#pragma weak tsip_long_plg_n_isr                      = Default_Handler
#pragma weak tsip_test_busy_n_isr                     = Default_Handler
#pragma weak tsip_wrrdy_0_n_isr                       = Default_Handler
#pragma weak tsip_wrrdy_1_n_isr                       = Default_Handler
#pragma weak tsip_wrrdy_4_n_isr                       = Default_Handler
#pragma weak tsip_rdrdy_0_n_isr                       = Default_Handler
#pragma weak tsip_rdrdy_1_n_isr                       = Default_Handler
#pragma weak tsip_integrate_wrrdy_n_isr               = Default_Handler
#pragma weak tsip_integrate_rdrdy_n_isr               = Default_Handler
#pragma weak lcdc_lcdc_level_0_isr                    = Default_Handler
#pragma weak lcdc_lcdc_level_1_isr                    = Default_Handler
#pragma weak lcdc_lcdc_level_2_isr                    = Default_Handler
#pragma weak twod_engine_irq_isr                      = Default_Handler
#pragma weak jpeg_jedi_isr                            = Default_Handler
#pragma weak jpeg_jdti_isr                            = Default_Handler
#elif defined(__GNUC__)
#define WEAK_REF_ATTRIBUTE      __attribute__ ((weak, alias("Default_Handler")))
#endif

void NMI_Handler(void);                      //NMI has many sources and is handled by BSP
void HardFault_Handler                       (void) WEAK_REF_ATTRIBUTE;
void MemManage_Handler                       (void) WEAK_REF_ATTRIBUTE;
void BusFault_Handler                        (void) WEAK_REF_ATTRIBUTE;
void UsageFault_Handler                      (void) WEAK_REF_ATTRIBUTE;
void SVC_Handler                             (void) WEAK_REF_ATTRIBUTE;
void DebugMon_Handler                        (void) WEAK_REF_ATTRIBUTE;
void PendSV_Handler                          (void) WEAK_REF_ATTRIBUTE;
void SysTick_Handler                         (void) WEAK_REF_ATTRIBUTE;
void port0_irq_isr                           (void) WEAK_REF_ATTRIBUTE;
void port1_irq_isr                           (void) WEAK_REF_ATTRIBUTE;
void port2_irq_isr                           (void) WEAK_REF_ATTRIBUTE;
void port3_irq_isr                           (void) WEAK_REF_ATTRIBUTE;
void port4_irq_isr                           (void) WEAK_REF_ATTRIBUTE;
void port5_irq_isr                           (void) WEAK_REF_ATTRIBUTE;
void port6_irq_isr                           (void) WEAK_REF_ATTRIBUTE;
void port7_irq_isr                           (void) WEAK_REF_ATTRIBUTE;
void port8_irq_isr                           (void) WEAK_REF_ATTRIBUTE;
void port9_irq_isr                           (void) WEAK_REF_ATTRIBUTE;
void port10_irq_isr                          (void) WEAK_REF_ATTRIBUTE;
void port11_irq_isr                          (void) WEAK_REF_ATTRIBUTE;
void port12_irq_isr                          (void) WEAK_REF_ATTRIBUTE;
void port13_irq_isr                          (void) WEAK_REF_ATTRIBUTE;
void port14_irq_isr                          (void) WEAK_REF_ATTRIBUTE;
void port15_irq_isr                          (void) WEAK_REF_ATTRIBUTE;
void dmac0_dmac_isr                          (void) WEAK_REF_ATTRIBUTE;
void dmac1_dmac_isr                          (void) WEAK_REF_ATTRIBUTE;
void dmac2_dmac_isr                          (void) WEAK_REF_ATTRIBUTE;
void dmac3_dmac_isr                          (void) WEAK_REF_ATTRIBUTE;
void dmac4_dmac_isr                          (void) WEAK_REF_ATTRIBUTE;
void dmac5_dmac_isr                          (void) WEAK_REF_ATTRIBUTE;
void dmac6_dmac_isr                          (void) WEAK_REF_ATTRIBUTE;
void dmac7_dmac_isr                          (void) WEAK_REF_ATTRIBUTE;
void dtc_transfer_isr                        (void) WEAK_REF_ATTRIBUTE;
void dtc_complete_isr                        (void) WEAK_REF_ATTRIBUTE;
void dtc_dtc_end_isr                         (void) WEAK_REF_ATTRIBUTE;
void exdmac0_exdmac_isr                      (void) WEAK_REF_ATTRIBUTE;
void exdmac1_exdmac_isr                      (void) WEAK_REF_ATTRIBUTE;
void icu_canceling_snooze_mode_isr           (void) WEAK_REF_ATTRIBUTE;
void fcu_fiferr_isr                          (void) WEAK_REF_ATTRIBUTE;
void fcu_frdyi_isr                           (void) WEAK_REF_ATTRIBUTE;
void fcu_eccerr_isr                          (void) WEAK_REF_ATTRIBUTE;
void lvd1_lvd1_isr                           (void) WEAK_REF_ATTRIBUTE;
void lvd2_lvd2_isr                           (void) WEAK_REF_ATTRIBUTE;
void mosc_osc_stop_isr                       (void) WEAK_REF_ATTRIBUTE;
void cpusys_snooze_mode_entry_flag_isr       (void) WEAK_REF_ATTRIBUTE;
void agt0_agti_isr                           (void) WEAK_REF_ATTRIBUTE;
void agt0_agtcmai_isr                        (void) WEAK_REF_ATTRIBUTE;
void agt0_agtcmbi_isr                        (void) WEAK_REF_ATTRIBUTE;
void agt1_agti_isr                           (void) WEAK_REF_ATTRIBUTE;
void agt1_agtcmai_isr                        (void) WEAK_REF_ATTRIBUTE;
void agt1_agtcmbi_isr                        (void) WEAK_REF_ATTRIBUTE;
void iwdt_nmiundf_n_isr                      (void) WEAK_REF_ATTRIBUTE;
void cwdt_nmiundf_n_isr                      (void) WEAK_REF_ATTRIBUTE;
void rtc_alm_isr                             (void) WEAK_REF_ATTRIBUTE;
void rtc_prd_isr                             (void) WEAK_REF_ATTRIBUTE;
void rtc_cup_isr                             (void) WEAK_REF_ATTRIBUTE;
void s12ad0_adi_isr                          (void) WEAK_REF_ATTRIBUTE;
void s12ad0_gbadi_isr                        (void) WEAK_REF_ATTRIBUTE;
void s12ad0_cmpai_isr                        (void) WEAK_REF_ATTRIBUTE;
void s12ad0_cmpbi_isr                        (void) WEAK_REF_ATTRIBUTE;
void s12ad0_compare_match_isr                (void) WEAK_REF_ATTRIBUTE;
void s12ad0_compare_mismatch_isr             (void) WEAK_REF_ATTRIBUTE;
void s12ad1_adi_isr                          (void) WEAK_REF_ATTRIBUTE;
void s12ad1_gbadi_isr                        (void) WEAK_REF_ATTRIBUTE;
void s12ad1_cmpai_isr                        (void) WEAK_REF_ATTRIBUTE;
void s12ad1_cmpbi_isr                        (void) WEAK_REF_ATTRIBUTE;
void s12ad1_compare_match_isr                (void) WEAK_REF_ATTRIBUTE;
void s12ad1_compare_mismatch_isr             (void) WEAK_REF_ATTRIBUTE;
void comp_oc0_comp_irq_isr                   (void) WEAK_REF_ATTRIBUTE;
void comp_rd1_comp_irq_isr                   (void) WEAK_REF_ATTRIBUTE;
void comp_rd2_comp_irq_isr                   (void) WEAK_REF_ATTRIBUTE;
void comp_rd3_comp_irq_isr                   (void) WEAK_REF_ATTRIBUTE;
void comp_rd4_comp_irq_isr                   (void) WEAK_REF_ATTRIBUTE;
void comp_rd5_comp_irq_isr                   (void) WEAK_REF_ATTRIBUTE;
void usbfs_d0fifo_isr                        (void) WEAK_REF_ATTRIBUTE;
void usbfs_d1fifo_isr                        (void) WEAK_REF_ATTRIBUTE;
void usbfs_usbi_isr                          (void) WEAK_REF_ATTRIBUTE;
void usbfs_usbr_isr                          (void) WEAK_REF_ATTRIBUTE;
void riic0_rxi_isr                           (void) WEAK_REF_ATTRIBUTE;
void riic0_txi_isr                           (void) WEAK_REF_ATTRIBUTE;
void riic0_tei_isr                           (void) WEAK_REF_ATTRIBUTE;
void riic0_eei_isr                           (void) WEAK_REF_ATTRIBUTE;
void riic0_wui_isr                           (void) WEAK_REF_ATTRIBUTE;
void riic1_rxi_isr                           (void) WEAK_REF_ATTRIBUTE;
void riic1_txi_isr                           (void) WEAK_REF_ATTRIBUTE;
void riic1_tei_isr                           (void) WEAK_REF_ATTRIBUTE;
void riic1_eei_isr                           (void) WEAK_REF_ATTRIBUTE;
void riic2_rxi_isr                           (void) WEAK_REF_ATTRIBUTE;
void riic2_txi_isr                           (void) WEAK_REF_ATTRIBUTE;
void riic2_tei_isr                           (void) WEAK_REF_ATTRIBUTE;
void riic2_eei_isr                           (void) WEAK_REF_ATTRIBUTE;
void ssi0_ssitxi_isr                         (void) WEAK_REF_ATTRIBUTE;
void ssi0_ssirxi_isr                         (void) WEAK_REF_ATTRIBUTE;
void ssi0_ssirt_isr                          (void) WEAK_REF_ATTRIBUTE;
void ssi0_ssif_isr                           (void) WEAK_REF_ATTRIBUTE;
void ssi1_ssitxi_isr                         (void) WEAK_REF_ATTRIBUTE;
void ssi1_ssirxi_isr                         (void) WEAK_REF_ATTRIBUTE;
void ssi1_ssirt_isr                          (void) WEAK_REF_ATTRIBUTE;
void ssi1_ssif_isr                           (void) WEAK_REF_ATTRIBUTE;
void src_idei_isr                            (void) WEAK_REF_ATTRIBUTE;
void src_odfi_isr                            (void) WEAK_REF_ATTRIBUTE;
void src_ovf_isr                             (void) WEAK_REF_ATTRIBUTE;
void src_udf_isr                             (void) WEAK_REF_ATTRIBUTE;
void src_cef_isr                             (void) WEAK_REF_ATTRIBUTE;
void pdc_pcdfi_isr                           (void) WEAK_REF_ATTRIBUTE;
void pdc_pcfei_isr                           (void) WEAK_REF_ATTRIBUTE;
void pdc_pceri_isr                           (void) WEAK_REF_ATTRIBUTE;
void ctsu_ctsuwr_isr                         (void) WEAK_REF_ATTRIBUTE;
void ctsu_ctsurd_isr                         (void) WEAK_REF_ATTRIBUTE;
void ctsu_ctsufn_isr                         (void) WEAK_REF_ATTRIBUTE;
void key_intkr_isr                           (void) WEAK_REF_ATTRIBUTE;
void doc_dopcf_isr                           (void) WEAK_REF_ATTRIBUTE;
void cac_ferrf_isr                           (void) WEAK_REF_ATTRIBUTE;
void cac_mendf_isr                           (void) WEAK_REF_ATTRIBUTE;
void cac_ovff_isr                            (void) WEAK_REF_ATTRIBUTE;
void rcan20_ers_isr                          (void) WEAK_REF_ATTRIBUTE;
void rcan20_rxf_isr                          (void) WEAK_REF_ATTRIBUTE;
void rcan20_txf_isr                          (void) WEAK_REF_ATTRIBUTE;
void rcan20_rxm_isr                          (void) WEAK_REF_ATTRIBUTE;
void rcan20_txm_isr                          (void) WEAK_REF_ATTRIBUTE;
void rcan21_ers_isr                          (void) WEAK_REF_ATTRIBUTE;
void rcan21_rxf_isr                          (void) WEAK_REF_ATTRIBUTE;
void rcan21_txf_isr                          (void) WEAK_REF_ATTRIBUTE;
void rcan21_rxm_isr                          (void) WEAK_REF_ATTRIBUTE;
void rcan21_txm_isr                          (void) WEAK_REF_ATTRIBUTE;
void gpio_port_group_a_isr                   (void) WEAK_REF_ATTRIBUTE;
void gpio_port_group_b_isr                   (void) WEAK_REF_ATTRIBUTE;
void gpio_port_group_c_isr                   (void) WEAK_REF_ATTRIBUTE;
void gpio_port_group_d_isr                   (void) WEAK_REF_ATTRIBUTE;
void elc0_software_event_isr                 (void) WEAK_REF_ATTRIBUTE;
void elc1_software_event_isr                 (void) WEAK_REF_ATTRIBUTE;
void poeg_group_event0_isr                   (void) WEAK_REF_ATTRIBUTE;
void poeg_group_event1_isr                   (void) WEAK_REF_ATTRIBUTE;
void poeg_group_event2_isr                   (void) WEAK_REF_ATTRIBUTE;
void poeg_group_event3_isr                   (void) WEAK_REF_ATTRIBUTE;
void gpt0_capture_compare_int_a_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt0_capture_compare_int_b_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt0_compare_int_c_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt0_compare_int_d_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt0_compare_int_e_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt0_compare_int_f_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt0_counter_overflow_isr               (void) WEAK_REF_ATTRIBUTE;
void gpt0_counter_underflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt0_ad_trig_a_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt0_ad_trig_b_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt1_capture_compare_int_a_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt1_capture_compare_int_b_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt1_compare_int_c_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt1_compare_int_d_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt1_compare_int_e_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt1_compare_int_f_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt1_counter_overflow_isr               (void) WEAK_REF_ATTRIBUTE;
void gpt1_counter_underflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt1_ad_trig_a_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt1_ad_trig_b_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt2_capture_compare_int_a_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt2_capture_compare_int_b_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt2_compare_int_c_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt2_compare_int_d_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt2_compare_int_e_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt2_compare_int_f_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt2_counter_overflow_isr               (void) WEAK_REF_ATTRIBUTE;
void gpt2_counter_underflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt2_ad_trig_a_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt2_ad_trig_b_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt3_capture_compare_int_a_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt3_capture_compare_int_b_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt3_compare_int_c_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt3_compare_int_d_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt3_compare_int_e_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt3_compare_int_f_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt3_counter_overflow_isr               (void) WEAK_REF_ATTRIBUTE;
void gpt3_counter_underflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt3_ad_trig_a_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt3_ad_trig_b_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt4_capture_compare_int_a_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt4_capture_compare_int_b_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt4_compare_int_c_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt4_compare_int_d_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt4_compare_int_e_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt4_compare_int_f_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt4_counter_overflow_isr               (void) WEAK_REF_ATTRIBUTE;
void gpt4_counter_underflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt4_ad_trig_a_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt4_ad_trig_b_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt5_capture_compare_int_a_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt5_capture_compare_int_b_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt5_compare_int_c_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt5_compare_int_d_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt5_compare_int_e_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt5_compare_int_f_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt5_counter_overflow_isr               (void) WEAK_REF_ATTRIBUTE;
void gpt5_counter_underflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt5_ad_trig_a_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt5_ad_trig_b_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt6_capture_compare_int_a_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt6_capture_compare_int_b_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt6_compare_int_c_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt6_compare_int_d_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt6_compare_int_e_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt6_compare_int_f_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt6_counter_overflow_isr               (void) WEAK_REF_ATTRIBUTE;
void gpt6_counter_underflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt6_ad_trig_a_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt6_ad_trig_b_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt7_capture_compare_int_a_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt7_capture_compare_int_b_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt7_compare_int_c_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt7_compare_int_d_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt7_compare_int_e_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt7_compare_int_f_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt7_counter_overflow_isr               (void) WEAK_REF_ATTRIBUTE;
void gpt7_counter_underflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt7_ad_trig_a_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt7_ad_trig_b_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt8_capture_compare_int_a_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt8_capture_compare_int_b_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt8_compare_int_c_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt8_compare_int_d_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt8_compare_int_e_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt8_compare_int_f_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt8_counter_overflow_isr               (void) WEAK_REF_ATTRIBUTE;
void gpt8_counter_underflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt8_ad_trig_a_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt8_ad_trig_b_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt9_capture_compare_int_a_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt9_capture_compare_int_b_isr          (void) WEAK_REF_ATTRIBUTE;
void gpt9_compare_int_c_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt9_compare_int_d_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt9_compare_int_e_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt9_compare_int_f_isr                  (void) WEAK_REF_ATTRIBUTE;
void gpt9_counter_overflow_isr               (void) WEAK_REF_ATTRIBUTE;
void gpt9_counter_underflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt9_ad_trig_a_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt9_ad_trig_b_isr                      (void) WEAK_REF_ATTRIBUTE;
void gpt10_capture_compare_int_a_isr         (void) WEAK_REF_ATTRIBUTE;
void gpt10_capture_compare_int_b_isr         (void) WEAK_REF_ATTRIBUTE;
void gpt10_compare_int_c_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt10_compare_int_d_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt10_compare_int_e_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt10_compare_int_f_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt10_counter_overflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt10_counter_underflow_isr             (void) WEAK_REF_ATTRIBUTE;
void gpt10_ad_trig_a_isr                     (void) WEAK_REF_ATTRIBUTE;
void gpt10_ad_trig_b_isr                     (void) WEAK_REF_ATTRIBUTE;
void gpt11_capture_compare_int_a_isr         (void) WEAK_REF_ATTRIBUTE;
void gpt11_capture_compare_int_b_isr         (void) WEAK_REF_ATTRIBUTE;
void gpt11_compare_int_c_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt11_compare_int_d_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt11_compare_int_e_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt11_compare_int_f_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt11_counter_overflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt11_counter_underflow_isr             (void) WEAK_REF_ATTRIBUTE;
void gpt11_ad_trig_a_isr                     (void) WEAK_REF_ATTRIBUTE;
void gpt11_ad_trig_b_isr                     (void) WEAK_REF_ATTRIBUTE;
void gpt12_capture_compare_int_a_isr         (void) WEAK_REF_ATTRIBUTE;
void gpt12_capture_compare_int_b_isr         (void) WEAK_REF_ATTRIBUTE;
void gpt12_compare_int_c_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt12_compare_int_d_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt12_compare_int_e_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt12_compare_int_f_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt12_counter_overflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt12_counter_underflow_isr             (void) WEAK_REF_ATTRIBUTE;
void gpt12_ad_trig_a_isr                     (void) WEAK_REF_ATTRIBUTE;
void gpt12_ad_trig_b_isr                     (void) WEAK_REF_ATTRIBUTE;
void gpt13_capture_compare_int_a_isr         (void) WEAK_REF_ATTRIBUTE;
void gpt13_capture_compare_int_b_isr         (void) WEAK_REF_ATTRIBUTE;
void gpt13_compare_int_c_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt13_compare_int_d_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt13_compare_int_e_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt13_compare_int_f_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt13_counter_overflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt13_counter_underflow_isr             (void) WEAK_REF_ATTRIBUTE;
void gpt13_ad_trig_a_isr                     (void) WEAK_REF_ATTRIBUTE;
void gpt13_ad_trig_b_isr                     (void) WEAK_REF_ATTRIBUTE;
void gpt14_capture_compare_int_a_isr         (void) WEAK_REF_ATTRIBUTE;
void gpt14_capture_compare_int_b_isr         (void) WEAK_REF_ATTRIBUTE;
void gpt14_compare_int_c_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt14_compare_int_d_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt14_compare_int_e_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt14_compare_int_f_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt14_counter_overflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt14_counter_underflow_isr             (void) WEAK_REF_ATTRIBUTE;
void gpt14_ad_trig_a_isr                     (void) WEAK_REF_ATTRIBUTE;
void gpt14_ad_trig_b_isr                     (void) WEAK_REF_ATTRIBUTE;
void gpt15_capture_compare_int_a_isr         (void) WEAK_REF_ATTRIBUTE;
void gpt15_capture_compare_int_b_isr         (void) WEAK_REF_ATTRIBUTE;
void gpt15_compare_int_c_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt15_compare_int_d_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt15_compare_int_e_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt15_compare_int_f_isr                 (void) WEAK_REF_ATTRIBUTE;
void gpt15_counter_overflow_isr              (void) WEAK_REF_ATTRIBUTE;
void gpt15_counter_underflow_isr             (void) WEAK_REF_ATTRIBUTE;
void gpt15_ad_trig_a_isr                     (void) WEAK_REF_ATTRIBUTE;
void gpt15_ad_trig_b_isr                     (void) WEAK_REF_ATTRIBUTE;
void gpt_uvw_edge_isr                        (void) WEAK_REF_ATTRIBUTE;
void ether_ipls_isr                          (void) WEAK_REF_ATTRIBUTE;
void ether_mint_isr                          (void) WEAK_REF_ATTRIBUTE;
void ether_pint_isr                          (void) WEAK_REF_ATTRIBUTE;
void ether_eint0_isr                         (void) WEAK_REF_ATTRIBUTE;
void ether_eint1_isr                         (void) WEAK_REF_ATTRIBUTE;
void ether_ether0_rise_isr                   (void) WEAK_REF_ATTRIBUTE;
void ether_ether1_rise_isr                   (void) WEAK_REF_ATTRIBUTE;
void ether_ether2_rise_isr                   (void) WEAK_REF_ATTRIBUTE;
void ether_ether3_rise_isr                   (void) WEAK_REF_ATTRIBUTE;
void ether_ether4_rise_isr                   (void) WEAK_REF_ATTRIBUTE;
void ether_ether5_rise_isr                   (void) WEAK_REF_ATTRIBUTE;
void ether_ether0_fall_isr                   (void) WEAK_REF_ATTRIBUTE;
void ether_ether1_fall_isr                   (void) WEAK_REF_ATTRIBUTE;
void ether_ether2_fall_isr                   (void) WEAK_REF_ATTRIBUTE;
void ether_ether3_fall_isr                   (void) WEAK_REF_ATTRIBUTE;
void ether_ether4_fall_isr                   (void) WEAK_REF_ATTRIBUTE;
void ether_ether5_fall_isr                   (void) WEAK_REF_ATTRIBUTE;
void usbhs_d0fifo_isr                        (void) WEAK_REF_ATTRIBUTE;
void usbhs_d1fifo_isr                        (void) WEAK_REF_ATTRIBUTE;
void usbhs_usbir_isr                         (void) WEAK_REF_ATTRIBUTE;
void sci0_rxi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci0_txi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci0_tei_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci0_eri_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci0_am_isr                             (void) WEAK_REF_ATTRIBUTE;
void sci0_rxi_or_eri_isr                     (void) WEAK_REF_ATTRIBUTE;
void sci1_rxi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci1_txi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci1_tei_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci1_eri_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci1_am_isr                             (void) WEAK_REF_ATTRIBUTE;
void sci2_rxi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci2_txi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci2_tei_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci2_eri_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci2_am_isr                             (void) WEAK_REF_ATTRIBUTE;
void sci3_rxi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci3_txi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci3_tei_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci3_eri_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci3_am_isr                             (void) WEAK_REF_ATTRIBUTE;
void sci4_rxi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci4_txi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci4_tei_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci4_eri_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci4_am_isr                             (void) WEAK_REF_ATTRIBUTE;
void sci5_rxi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci5_txi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci5_tei_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci5_eri_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci5_am_isr                             (void) WEAK_REF_ATTRIBUTE;
void sci6_rxi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci6_txi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci6_tei_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci6_eri_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci6_am_isr                             (void) WEAK_REF_ATTRIBUTE;
void sci7_rxi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci7_txi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci7_tei_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci7_eri_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci7_am_isr                             (void) WEAK_REF_ATTRIBUTE;
void sci8_rxi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci8_txi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci8_tei_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci8_eri_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci8_am_isr                             (void) WEAK_REF_ATTRIBUTE;
void sci9_rxi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci9_txi_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci9_tei_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci9_eri_isr                            (void) WEAK_REF_ATTRIBUTE;
void sci9_am_isr                             (void) WEAK_REF_ATTRIBUTE;
void rspi0_spri_isr                          (void) WEAK_REF_ATTRIBUTE;
void rspi0_spti_isr                          (void) WEAK_REF_ATTRIBUTE;
void rspi0_spii_isr                          (void) WEAK_REF_ATTRIBUTE;
void rspi0_spei_isr                          (void) WEAK_REF_ATTRIBUTE;
void rspi0_sp_elctend_isr                    (void) WEAK_REF_ATTRIBUTE;
void rspi1_spri_isr                          (void) WEAK_REF_ATTRIBUTE;
void rspi1_spti_isr                          (void) WEAK_REF_ATTRIBUTE;
void rspi1_spii_isr                          (void) WEAK_REF_ATTRIBUTE;
void rspi1_spei_isr                          (void) WEAK_REF_ATTRIBUTE;
void rspi1_sp_elctend_isr                    (void) WEAK_REF_ATTRIBUTE;
void qspi_intr_isr                           (void) WEAK_REF_ATTRIBUTE;
void sdhi_mmc0_accs_isr                      (void) WEAK_REF_ATTRIBUTE;
void sdhi_mmc0_sdio_isr                      (void) WEAK_REF_ATTRIBUTE;
void sdhi_mmc0_card_isr                      (void) WEAK_REF_ATTRIBUTE;
void sdhi_mmc0_odmsdbreq_isr                 (void) WEAK_REF_ATTRIBUTE;
void sdhi_mmc1_accs_isr                      (void) WEAK_REF_ATTRIBUTE;
void sdhi_mmc1_sdio_isr                      (void) WEAK_REF_ATTRIBUTE;
void sdhi_mmc1_card_isr                      (void) WEAK_REF_ATTRIBUTE;
void sdhi_mmc1_odmsdbreq_isr                 (void) WEAK_REF_ATTRIBUTE;
void ext_divider_intmd_isr                   (void) WEAK_REF_ATTRIBUTE;
void tsip_proc_busy_n_isr                    (void) WEAK_REF_ATTRIBUTE;
void tsip_romok_n_isr                        (void) WEAK_REF_ATTRIBUTE;
void tsip_long_plg_n_isr                     (void) WEAK_REF_ATTRIBUTE;
void tsip_test_busy_n_isr                    (void) WEAK_REF_ATTRIBUTE;
void tsip_wrrdy_0_n_isr                      (void) WEAK_REF_ATTRIBUTE;
void tsip_wrrdy_1_n_isr                      (void) WEAK_REF_ATTRIBUTE;
void tsip_wrrdy_4_n_isr                      (void) WEAK_REF_ATTRIBUTE;
void tsip_rdrdy_0_n_isr                      (void) WEAK_REF_ATTRIBUTE;
void tsip_rdrdy_1_n_isr                      (void) WEAK_REF_ATTRIBUTE;
void tsip_integrate_wrrdy_n_isr              (void) WEAK_REF_ATTRIBUTE;
void tsip_integrate_rdrdy_n_isr              (void) WEAK_REF_ATTRIBUTE;
void lcdc_lcdc_level_0_isr                   (void) WEAK_REF_ATTRIBUTE;
void lcdc_lcdc_level_1_isr                   (void) WEAK_REF_ATTRIBUTE;
void lcdc_lcdc_level_2_isr                   (void) WEAK_REF_ATTRIBUTE;
void twod_engine_irq_isr                     (void) WEAK_REF_ATTRIBUTE;
void jpeg_jedi_isr                           (void) WEAK_REF_ATTRIBUTE;
void jpeg_jdti_isr                           (void) WEAK_REF_ATTRIBUTE;

/* Vector table. */
BSP_DONT_REMOVE const exc_ptr_t __Vectors[112] BSP_PLACE_IN_SECTION(BSP_SECTION_VECTOR) =
{
    (exc_ptr_t)(&g_main_stack[0] + BSP_CFG_STACK_MAIN_BYTES),           /*      Initial Stack Pointer     */
    Reset_Handler,                                                      /*      Reset Handler             */
    NMI_Handler,                                                        /*      NMI Handler               */
    HardFault_Handler,                                                  /*      Hard Fault Handler        */
    MemManage_Handler,                                                  /*      MPU Fault Handler         */
    BusFault_Handler,                                                   /*      Bus Fault Handler         */
    UsageFault_Handler,                                                 /*      Usage Fault Handler       */
    0,                                                                  /*      Reserved                  */
    0,                                                                  /*      Reserved                  */
    0,                                                                  /*      Reserved                  */
    0,                                                                  /*      Reserved                  */
    SVC_Handler,                                                        /*      SVCall Handler            */
    DebugMon_Handler,                                                   /*      Debug Monitor Handler     */
    0,                                                                  /*      Reserved                  */
    PendSV_Handler,                                                     /*      PendSV Handler            */
    SysTick_Handler,                                                    /*      SysTick Handler           */
#if (BSP_IRQ_CFG_PORT0_IRQ != BSP_IRQ_DISABLED)
    port0_irq_isr,
#endif
#if (BSP_IRQ_CFG_PORT1_IRQ != BSP_IRQ_DISABLED)
    port1_irq_isr,
#endif
#if (BSP_IRQ_CFG_PORT2_IRQ != BSP_IRQ_DISABLED)
    port2_irq_isr,
#endif
#if (BSP_IRQ_CFG_PORT3_IRQ != BSP_IRQ_DISABLED)
    port3_irq_isr,
#endif
#if (BSP_IRQ_CFG_PORT4_IRQ != BSP_IRQ_DISABLED)
    port4_irq_isr,
#endif
#if (BSP_IRQ_CFG_PORT5_IRQ != BSP_IRQ_DISABLED)
    port5_irq_isr,
#endif
#if (BSP_IRQ_CFG_PORT6_IRQ != BSP_IRQ_DISABLED)
    port6_irq_isr,
#endif
#if (BSP_IRQ_CFG_PORT7_IRQ != BSP_IRQ_DISABLED)
    port7_irq_isr,
#endif
#if (BSP_IRQ_CFG_PORT8_IRQ != BSP_IRQ_DISABLED)
    port8_irq_isr,
#endif
#if (BSP_IRQ_CFG_PORT9_IRQ != BSP_IRQ_DISABLED)
    port9_irq_isr,
#endif
#if (BSP_IRQ_CFG_PORT10_IRQ != BSP_IRQ_DISABLED)
    port10_irq_isr,
#endif
#if (BSP_IRQ_CFG_PORT11_IRQ != BSP_IRQ_DISABLED)
    port11_irq_isr,
#endif
#if (BSP_IRQ_CFG_PORT12_IRQ != BSP_IRQ_DISABLED)
    port12_irq_isr,
#endif
#if (BSP_IRQ_CFG_PORT13_IRQ != BSP_IRQ_DISABLED)
    port13_irq_isr,
#endif
#if (BSP_IRQ_CFG_PORT14_IRQ != BSP_IRQ_DISABLED)
    port14_irq_isr,
#endif
#if (BSP_IRQ_CFG_PORT15_IRQ != BSP_IRQ_DISABLED)
    port15_irq_isr,
#endif
#if (BSP_IRQ_CFG_DMAC0_DMAC != BSP_IRQ_DISABLED)
    dmac0_dmac_isr,
#endif
#if (BSP_IRQ_CFG_DMAC1_DMAC != BSP_IRQ_DISABLED)
    dmac1_dmac_isr,
#endif
#if (BSP_IRQ_CFG_DMAC2_DMAC != BSP_IRQ_DISABLED)
    dmac2_dmac_isr,
#endif
#if (BSP_IRQ_CFG_DMAC3_DMAC != BSP_IRQ_DISABLED)
    dmac3_dmac_isr,
#endif
#if (BSP_IRQ_CFG_DMAC4_DMAC != BSP_IRQ_DISABLED)
    dmac4_dmac_isr,
#endif
#if (BSP_IRQ_CFG_DMAC5_DMAC != BSP_IRQ_DISABLED)
    dmac5_dmac_isr,
#endif
#if (BSP_IRQ_CFG_DMAC6_DMAC != BSP_IRQ_DISABLED)
    dmac6_dmac_isr,
#endif
#if (BSP_IRQ_CFG_DMAC7_DMAC != BSP_IRQ_DISABLED)
    dmac7_dmac_isr,
#endif
#if (BSP_IRQ_CFG_DTC_TRANSFER != BSP_IRQ_DISABLED)
    dtc_transfer_isr,
#endif
#if (BSP_IRQ_CFG_DTC_COMPLETE != BSP_IRQ_DISABLED)
    dtc_complete_isr,
#endif
#if (BSP_IRQ_CFG_DTC_DTC_END != BSP_IRQ_DISABLED)
    dtc_dtc_end_isr,
#endif
#if (BSP_IRQ_CFG_EXDMAC0_EXDMAC != BSP_IRQ_DISABLED)
    exdmac0_exdmac_isr,
#endif
#if (BSP_IRQ_CFG_EXDMAC1_EXDMAC != BSP_IRQ_DISABLED)
    exdmac1_exdmac_isr,
#endif
#if (BSP_IRQ_CFG_ICU_CANCELING_SNOOZE_MODE != BSP_IRQ_DISABLED)
    icu_canceling_snooze_mode_isr,
#endif
#if (BSP_IRQ_CFG_FCU_FIFERR != BSP_IRQ_DISABLED)
    fcu_fiferr_isr,
#endif
#if (BSP_IRQ_CFG_FCU_FRDYI != BSP_IRQ_DISABLED)
    fcu_frdyi_isr,
#endif
#if (BSP_IRQ_CFG_FCU_ECCERR != BSP_IRQ_DISABLED)
    fcu_eccerr_isr,
#endif
#if (BSP_IRQ_CFG_LVD1_LVD1 != BSP_IRQ_DISABLED)
    lvd1_lvd1_isr,
#endif
#if (BSP_IRQ_CFG_LVD2_LVD2 != BSP_IRQ_DISABLED)
    lvd2_lvd2_isr,
#endif
#if (BSP_IRQ_CFG_MOSC_OSC_STOP != BSP_IRQ_DISABLED)
    mosc_osc_stop_isr,
#endif
#if (BSP_IRQ_CFG_CPUSYS_SNOOZE_MODE_ENTRY_FLAG != BSP_IRQ_DISABLED)
    cpusys_snooze_mode_entry_flag_isr,
#endif
#if (BSP_IRQ_CFG_AGT0_AGTI != BSP_IRQ_DISABLED)
    agt0_agti_isr,
#endif
#if (BSP_IRQ_CFG_AGT0_AGTCMAI != BSP_IRQ_DISABLED)
    agt0_agtcmai_isr,
#endif
#if (BSP_IRQ_CFG_AGT0_AGTCMBI != BSP_IRQ_DISABLED)
    agt0_agtcmbi_isr,
#endif
#if (BSP_IRQ_CFG_AGT1_AGTI != BSP_IRQ_DISABLED)
    agt1_agti_isr,
#endif
#if (BSP_IRQ_CFG_AGT1_AGTCMAI != BSP_IRQ_DISABLED)
    agt1_agtcmai_isr,
#endif
#if (BSP_IRQ_CFG_AGT1_AGTCMBI != BSP_IRQ_DISABLED)
    agt1_agtcmbi_isr,
#endif
#if (BSP_IRQ_CFG_IWDT_NMIUNDF_N != BSP_IRQ_DISABLED)
    iwdt_nmiundf_n_isr,
#endif
#if (BSP_IRQ_CFG_CWDT_NMIUNDF_N != BSP_IRQ_DISABLED)
    cwdt_nmiundf_n_isr,
#endif
#if (BSP_IRQ_CFG_RTC_ALM != BSP_IRQ_DISABLED)
    rtc_alm_isr,
#endif
#if (BSP_IRQ_CFG_RTC_PRD != BSP_IRQ_DISABLED)
    rtc_prd_isr,
#endif
#if (BSP_IRQ_CFG_RTC_CUP != BSP_IRQ_DISABLED)
    rtc_cup_isr,
#endif
#if (BSP_IRQ_CFG_S12AD0_ADI != BSP_IRQ_DISABLED)
    s12ad0_adi_isr,
#endif
#if (BSP_IRQ_CFG_S12AD0_GBADI != BSP_IRQ_DISABLED)
    s12ad0_gbadi_isr,
#endif
#if (BSP_IRQ_CFG_S12AD0_CMPAI != BSP_IRQ_DISABLED)
    s12ad0_cmpai_isr,
#endif
#if (BSP_IRQ_CFG_S12AD0_CMPBI != BSP_IRQ_DISABLED)
    s12ad0_cmpbi_isr,
#endif
#if (BSP_IRQ_CFG_S12AD0_COMPARE_MATCH != BSP_IRQ_DISABLED)
    s12ad0_compare_match_isr,
#endif
#if (BSP_IRQ_CFG_S12AD0_COMPARE_MISMATCH != BSP_IRQ_DISABLED)
    s12ad0_compare_mismatch_isr,
#endif
#if (BSP_IRQ_CFG_S12AD1_ADI != BSP_IRQ_DISABLED)
    s12ad1_adi_isr,
#endif
#if (BSP_IRQ_CFG_S12AD1_GBADI != BSP_IRQ_DISABLED)
    s12ad1_gbadi_isr,
#endif
#if (BSP_IRQ_CFG_S12AD1_CMPAI != BSP_IRQ_DISABLED)
    s12ad1_cmpai_isr,
#endif
#if (BSP_IRQ_CFG_S12AD1_CMPBI != BSP_IRQ_DISABLED)
    s12ad1_cmpbi_isr,
#endif
#if (BSP_IRQ_CFG_S12AD1_COMPARE_MATCH != BSP_IRQ_DISABLED)
    s12ad1_compare_match_isr,
#endif
#if (BSP_IRQ_CFG_S12AD1_COMPARE_MISMATCH != BSP_IRQ_DISABLED)
    s12ad1_compare_mismatch_isr,
#endif
#if (BSP_IRQ_CFG_COMP_OC0_COMP_IRQ != BSP_IRQ_DISABLED)
    comp_oc0_comp_irq_isr,
#endif
#if (BSP_IRQ_CFG_COMP_RD1_COMP_IRQ != BSP_IRQ_DISABLED)
    comp_rd1_comp_irq_isr,
#endif
#if (BSP_IRQ_CFG_COMP_RD2_COMP_IRQ != BSP_IRQ_DISABLED)
    comp_rd2_comp_irq_isr,
#endif
#if (BSP_IRQ_CFG_COMP_RD3_COMP_IRQ != BSP_IRQ_DISABLED)
    comp_rd3_comp_irq_isr,
#endif
#if (BSP_IRQ_CFG_COMP_RD4_COMP_IRQ != BSP_IRQ_DISABLED)
    comp_rd4_comp_irq_isr,
#endif
#if (BSP_IRQ_CFG_COMP_RD5_COMP_IRQ != BSP_IRQ_DISABLED)
    comp_rd5_comp_irq_isr,
#endif
#if (BSP_IRQ_CFG_USBFS_D0FIFO != BSP_IRQ_DISABLED)
    usbfs_d0fifo_isr,
#endif
#if (BSP_IRQ_CFG_USBFS_D1FIFO != BSP_IRQ_DISABLED)
    usbfs_d1fifo_isr,
#endif
#if (BSP_IRQ_CFG_USBFS_USBI != BSP_IRQ_DISABLED)
    usbfs_usbi_isr,
#endif
#if (BSP_IRQ_CFG_USBFS_USBR != BSP_IRQ_DISABLED)
    usbfs_usbr_isr,
#endif
#if (BSP_IRQ_CFG_RIIC0_RXI != BSP_IRQ_DISABLED)
    riic0_rxi_isr,
#endif
#if (BSP_IRQ_CFG_RIIC0_TXI != BSP_IRQ_DISABLED)
    riic0_txi_isr,
#endif
#if (BSP_IRQ_CFG_RIIC0_TEI != BSP_IRQ_DISABLED)
    riic0_tei_isr,
#endif
#if (BSP_IRQ_CFG_RIIC0_EEI != BSP_IRQ_DISABLED)
    riic0_eei_isr,
#endif
#if (BSP_IRQ_CFG_RIIC0_WUI != BSP_IRQ_DISABLED)
    riic0_wui_isr,
#endif
#if (BSP_IRQ_CFG_RIIC1_RXI != BSP_IRQ_DISABLED)
    riic1_rxi_isr,
#endif
#if (BSP_IRQ_CFG_RIIC1_TXI != BSP_IRQ_DISABLED)
    riic1_txi_isr,
#endif
#if (BSP_IRQ_CFG_RIIC1_TEI != BSP_IRQ_DISABLED)
    riic1_tei_isr,
#endif
#if (BSP_IRQ_CFG_RIIC1_EEI != BSP_IRQ_DISABLED)
    riic1_eei_isr,
#endif
#if (BSP_IRQ_CFG_RIIC2_RXI != BSP_IRQ_DISABLED)
    riic2_rxi_isr,
#endif
#if (BSP_IRQ_CFG_RIIC2_TXI != BSP_IRQ_DISABLED)
    riic2_txi_isr,
#endif
#if (BSP_IRQ_CFG_RIIC2_TEI != BSP_IRQ_DISABLED)
    riic2_tei_isr,
#endif
#if (BSP_IRQ_CFG_RIIC2_EEI != BSP_IRQ_DISABLED)
    riic2_eei_isr,
#endif
#if (BSP_IRQ_CFG_SSI0_SSITXI != BSP_IRQ_DISABLED)
    ssi0_ssitxi_isr,
#endif
#if (BSP_IRQ_CFG_SSI0_SSIRXI != BSP_IRQ_DISABLED)
    ssi0_ssirxi_isr,
#endif
#if (BSP_IRQ_CFG_SSI0_SSIRT != BSP_IRQ_DISABLED)
    ssi0_ssirt_isr,
#endif
#if (BSP_IRQ_CFG_SSI0_SSIF != BSP_IRQ_DISABLED)
    ssi0_ssif_isr,
#endif
#if (BSP_IRQ_CFG_SSI1_SSITXI != BSP_IRQ_DISABLED)
    ssi1_ssitxi_isr,
#endif
#if (BSP_IRQ_CFG_SSI1_SSIRXI != BSP_IRQ_DISABLED)
    ssi1_ssirxi_isr,
#endif
#if (BSP_IRQ_CFG_SSI1_SSIRT != BSP_IRQ_DISABLED)
    ssi1_ssirt_isr,
#endif
#if (BSP_IRQ_CFG_SSI1_SSIF != BSP_IRQ_DISABLED)
    ssi1_ssif_isr,
#endif
#if (BSP_IRQ_CFG_SRC_IDEI != BSP_IRQ_DISABLED)
    src_idei_isr,
#endif
#if (BSP_IRQ_CFG_SRC_ODFI != BSP_IRQ_DISABLED)
    src_odfi_isr,
#endif
#if (BSP_IRQ_CFG_SRC_OVF != BSP_IRQ_DISABLED)
    src_ovf_isr,
#endif
#if (BSP_IRQ_CFG_SRC_UDF != BSP_IRQ_DISABLED)
    src_udf_isr,
#endif
#if (BSP_IRQ_CFG_SRC_CEF != BSP_IRQ_DISABLED)
    src_cef_isr,
#endif
#if (BSP_IRQ_CFG_PDC_PCDFI != BSP_IRQ_DISABLED)
    pdc_pcdfi_isr,
#endif
#if (BSP_IRQ_CFG_PDC_PCFEI != BSP_IRQ_DISABLED)
    pdc_pcfei_isr,
#endif
#if (BSP_IRQ_CFG_PDC_PCERI != BSP_IRQ_DISABLED)
    pdc_pceri_isr,
#endif
#if (BSP_IRQ_CFG_CTSU_CTSUWR != BSP_IRQ_DISABLED)
    ctsu_ctsuwr_isr,
#endif
#if (BSP_IRQ_CFG_CTSU_CTSURD != BSP_IRQ_DISABLED)
    ctsu_ctsurd_isr,
#endif
#if (BSP_IRQ_CFG_CTSU_CTSUFN != BSP_IRQ_DISABLED)
    ctsu_ctsufn_isr,
#endif
#if (BSP_IRQ_CFG_KEY_INTKR != BSP_IRQ_DISABLED)
    key_intkr_isr,
#endif
#if (BSP_IRQ_CFG_DOC_DOPCF != BSP_IRQ_DISABLED)
    doc_dopcf_isr,
#endif
#if (BSP_IRQ_CFG_CAC_FERRF != BSP_IRQ_DISABLED)
    cac_ferrf_isr,
#endif
#if (BSP_IRQ_CFG_CAC_MENDF != BSP_IRQ_DISABLED)
    cac_mendf_isr,
#endif
#if (BSP_IRQ_CFG_CAC_OVFF != BSP_IRQ_DISABLED)
    cac_ovff_isr,
#endif
#if (BSP_IRQ_CFG_RCAN20_ERS != BSP_IRQ_DISABLED)
    rcan20_ers_isr,
#endif
#if (BSP_IRQ_CFG_RCAN20_RXF != BSP_IRQ_DISABLED)
    rcan20_rxf_isr,
#endif
#if (BSP_IRQ_CFG_RCAN20_TXF != BSP_IRQ_DISABLED)
    rcan20_txf_isr,
#endif
#if (BSP_IRQ_CFG_RCAN20_RXM != BSP_IRQ_DISABLED)
    rcan20_rxm_isr,
#endif
#if (BSP_IRQ_CFG_RCAN20_TXM != BSP_IRQ_DISABLED)
    rcan20_txm_isr,
#endif
#if (BSP_IRQ_CFG_RCAN21_ERS != BSP_IRQ_DISABLED)
    rcan21_ers_isr,
#endif
#if (BSP_IRQ_CFG_RCAN21_RXF != BSP_IRQ_DISABLED)
    rcan21_rxf_isr,
#endif
#if (BSP_IRQ_CFG_RCAN21_TXF != BSP_IRQ_DISABLED)
    rcan21_txf_isr,
#endif
#if (BSP_IRQ_CFG_RCAN21_RXM != BSP_IRQ_DISABLED)
    rcan21_rxm_isr,
#endif
#if (BSP_IRQ_CFG_RCAN21_TXM != BSP_IRQ_DISABLED)
    rcan21_txm_isr,
#endif
#if (BSP_IRQ_CFG_GPIO_PORT_GROUP_A != BSP_IRQ_DISABLED)
    gpio_port_group_a_isr,
#endif
#if (BSP_IRQ_CFG_GPIO_PORT_GROUP_B != BSP_IRQ_DISABLED)
    gpio_port_group_b_isr,
#endif
#if (BSP_IRQ_CFG_GPIO_PORT_GROUP_C != BSP_IRQ_DISABLED)
    gpio_port_group_c_isr,
#endif
#if (BSP_IRQ_CFG_GPIO_PORT_GROUP_D != BSP_IRQ_DISABLED)
    gpio_port_group_d_isr,
#endif
#if (BSP_IRQ_CFG_ELC0_SOFTWARE_EVENT != BSP_IRQ_DISABLED)
    elc0_software_event_isr,
#endif
#if (BSP_IRQ_CFG_ELC1_SOFTWARE_EVENT != BSP_IRQ_DISABLED)
    elc1_software_event_isr,
#endif
#if (BSP_IRQ_CFG_POEG_GROUP_EVENT0 != BSP_IRQ_DISABLED)
    poeg_group_event0_isr,
#endif
#if (BSP_IRQ_CFG_POEG_GROUP_EVENT1 != BSP_IRQ_DISABLED)
    poeg_group_event1_isr,
#endif
#if (BSP_IRQ_CFG_POEG_GROUP_EVENT2 != BSP_IRQ_DISABLED)
    poeg_group_event2_isr,
#endif
#if (BSP_IRQ_CFG_POEG_GROUP_EVENT3 != BSP_IRQ_DISABLED)
    poeg_group_event3_isr,
#endif
#if (BSP_IRQ_CFG_GPT0_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt0_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT0_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt0_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT0_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt0_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT0_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt0_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT0_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt0_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT0_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt0_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT0_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt0_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT0_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt0_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT0_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt0_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT0_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt0_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT1_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt1_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT1_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt1_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT1_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt1_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT1_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt1_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT1_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt1_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT1_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt1_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT1_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt1_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT1_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt1_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT1_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt1_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT1_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt1_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT2_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt2_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT2_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt2_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT2_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt2_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT2_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt2_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT2_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt2_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT2_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt2_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT2_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt2_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT2_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt2_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT2_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt2_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT2_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt2_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT3_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt3_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT3_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt3_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT3_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt3_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT3_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt3_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT3_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt3_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT3_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt3_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT3_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt3_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT3_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt3_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT3_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt3_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT3_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt3_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT4_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt4_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT4_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt4_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT4_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt4_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT4_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt4_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT4_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt4_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT4_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt4_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT4_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt4_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT4_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt4_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT4_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt4_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT4_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt4_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT5_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt5_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT5_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt5_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT5_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt5_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT5_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt5_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT5_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt5_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT5_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt5_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT5_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt5_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT5_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt5_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT5_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt5_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT5_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt5_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT6_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt6_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT6_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt6_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT6_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt6_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT6_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt6_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT6_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt6_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT6_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt6_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT6_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt6_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT6_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt6_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT6_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt6_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT6_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt6_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT7_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt7_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT7_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt7_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT7_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt7_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT7_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt7_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT7_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt7_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT7_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt7_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT7_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt7_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT7_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt7_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT7_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt7_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT7_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt7_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT8_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt8_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT8_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt8_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT8_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt8_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT8_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt8_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT8_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt8_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT8_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt8_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT8_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt8_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT8_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt8_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT8_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt8_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT8_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt8_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT9_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt9_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT9_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt9_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT9_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt9_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT9_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt9_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT9_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt9_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT9_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt9_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT9_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt9_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT9_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt9_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT9_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt9_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT9_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt9_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT10_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt10_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT10_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt10_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT10_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt10_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT10_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt10_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT10_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt10_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT10_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt10_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT10_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt10_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT10_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt10_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT10_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt10_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT10_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt10_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT11_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt11_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT11_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt11_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT11_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt11_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT11_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt11_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT11_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt11_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT11_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt11_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT11_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt11_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT11_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt11_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT11_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt11_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT11_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt11_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT12_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt12_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT12_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt12_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT12_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt12_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT12_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt12_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT12_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt12_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT12_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt12_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT12_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt12_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT12_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt12_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT12_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt12_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT12_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt12_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT13_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt13_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT13_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt13_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT13_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt13_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT13_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt13_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT13_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt13_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT13_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt13_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT13_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt13_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT13_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt13_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT13_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt13_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT13_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt13_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT14_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt14_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT14_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt14_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT14_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt14_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT14_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt14_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT14_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt14_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT14_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt14_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT14_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt14_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT14_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt14_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT14_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt14_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT14_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt14_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT15_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    gpt15_capture_compare_int_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT15_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    gpt15_capture_compare_int_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT15_COMPARE_INT_C != BSP_IRQ_DISABLED)
    gpt15_compare_int_c_isr,
#endif
#if (BSP_IRQ_CFG_GPT15_COMPARE_INT_D != BSP_IRQ_DISABLED)
    gpt15_compare_int_d_isr,
#endif
#if (BSP_IRQ_CFG_GPT15_COMPARE_INT_E != BSP_IRQ_DISABLED)
    gpt15_compare_int_e_isr,
#endif
#if (BSP_IRQ_CFG_GPT15_COMPARE_INT_F != BSP_IRQ_DISABLED)
    gpt15_compare_int_f_isr,
#endif
#if (BSP_IRQ_CFG_GPT15_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    gpt15_counter_overflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT15_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    gpt15_counter_underflow_isr,
#endif
#if (BSP_IRQ_CFG_GPT15_AD_TRIG_A != BSP_IRQ_DISABLED)
    gpt15_ad_trig_a_isr,
#endif
#if (BSP_IRQ_CFG_GPT15_AD_TRIG_B != BSP_IRQ_DISABLED)
    gpt15_ad_trig_b_isr,
#endif
#if (BSP_IRQ_CFG_GPT_UVW_EDGE != BSP_IRQ_DISABLED)
    gpt_uvw_edge_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_IPLS != BSP_IRQ_DISABLED)
    ether_ipls_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_MINT != BSP_IRQ_DISABLED)
    ether_mint_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_PINT != BSP_IRQ_DISABLED)
    ether_pint_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_EINT0 != BSP_IRQ_DISABLED)
    ether_eint0_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_EINT1 != BSP_IRQ_DISABLED)
    ether_eint1_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER0_RISE != BSP_IRQ_DISABLED)
    ether_ether0_rise_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER1_RISE != BSP_IRQ_DISABLED)
    ether_ether1_rise_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER2_RISE != BSP_IRQ_DISABLED)
    ether_ether2_rise_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER3_RISE != BSP_IRQ_DISABLED)
    ether_ether3_rise_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER4_RISE != BSP_IRQ_DISABLED)
    ether_ether4_rise_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER5_RISE != BSP_IRQ_DISABLED)
    ether_ether5_rise_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER0_FALL != BSP_IRQ_DISABLED)
    ether_ether0_fall_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER1_FALL != BSP_IRQ_DISABLED)
    ether_ether1_fall_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER2_FALL != BSP_IRQ_DISABLED)
    ether_ether2_fall_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER3_FALL != BSP_IRQ_DISABLED)
    ether_ether3_fall_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER4_FALL != BSP_IRQ_DISABLED)
    ether_ether4_fall_isr,
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER5_FALL != BSP_IRQ_DISABLED)
    ether_ether5_fall_isr,
#endif
#if (BSP_IRQ_CFG_USBHS_D0FIFO != BSP_IRQ_DISABLED)
    usbhs_d0fifo_isr,
#endif
#if (BSP_IRQ_CFG_USBHS_D1FIFO != BSP_IRQ_DISABLED)
    usbhs_d1fifo_isr,
#endif
#if (BSP_IRQ_CFG_USBHS_USBIR != BSP_IRQ_DISABLED)
    usbhs_usbir_isr,
#endif
#if (BSP_IRQ_CFG_SCI0_RXI != BSP_IRQ_DISABLED)
    sci0_rxi_isr,
#endif
#if (BSP_IRQ_CFG_SCI0_TXI != BSP_IRQ_DISABLED)
    sci0_txi_isr,
#endif
#if (BSP_IRQ_CFG_SCI0_TEI != BSP_IRQ_DISABLED)
    sci0_tei_isr,
#endif
#if (BSP_IRQ_CFG_SCI0_ERI != BSP_IRQ_DISABLED)
    sci0_eri_isr,
#endif
#if (BSP_IRQ_CFG_SCI0_AM != BSP_IRQ_DISABLED)
    sci0_am_isr,
#endif
#if (BSP_IRQ_CFG_SCI0_RXI_OR_ERI != BSP_IRQ_DISABLED)
    sci0_rxi_or_eri_isr,
#endif
#if (BSP_IRQ_CFG_SCI1_RXI != BSP_IRQ_DISABLED)
    sci1_rxi_isr,
#endif
#if (BSP_IRQ_CFG_SCI1_TXI != BSP_IRQ_DISABLED)
    sci1_txi_isr,
#endif
#if (BSP_IRQ_CFG_SCI1_TEI != BSP_IRQ_DISABLED)
    sci1_tei_isr,
#endif
#if (BSP_IRQ_CFG_SCI1_ERI != BSP_IRQ_DISABLED)
    sci1_eri_isr,
#endif
#if (BSP_IRQ_CFG_SCI1_AM != BSP_IRQ_DISABLED)
    sci1_am_isr,
#endif
#if (BSP_IRQ_CFG_SCI2_RXI != BSP_IRQ_DISABLED)
    sci2_rxi_isr,
#endif
#if (BSP_IRQ_CFG_SCI2_TXI != BSP_IRQ_DISABLED)
    sci2_txi_isr,
#endif
#if (BSP_IRQ_CFG_SCI2_TEI != BSP_IRQ_DISABLED)
    sci2_tei_isr,
#endif
#if (BSP_IRQ_CFG_SCI2_ERI != BSP_IRQ_DISABLED)
    sci2_eri_isr,
#endif
#if (BSP_IRQ_CFG_SCI2_AM != BSP_IRQ_DISABLED)
    sci2_am_isr,
#endif
#if (BSP_IRQ_CFG_SCI3_RXI != BSP_IRQ_DISABLED)
    sci3_rxi_isr,
#endif
#if (BSP_IRQ_CFG_SCI3_TXI != BSP_IRQ_DISABLED)
    sci3_txi_isr,
#endif
#if (BSP_IRQ_CFG_SCI3_TEI != BSP_IRQ_DISABLED)
    sci3_tei_isr,
#endif
#if (BSP_IRQ_CFG_SCI3_ERI != BSP_IRQ_DISABLED)
    sci3_eri_isr,
#endif
#if (BSP_IRQ_CFG_SCI3_AM != BSP_IRQ_DISABLED)
    sci3_am_isr,
#endif
#if (BSP_IRQ_CFG_SCI4_RXI != BSP_IRQ_DISABLED)
    sci4_rxi_isr,
#endif
#if (BSP_IRQ_CFG_SCI4_TXI != BSP_IRQ_DISABLED)
    sci4_txi_isr,
#endif
#if (BSP_IRQ_CFG_SCI4_TEI != BSP_IRQ_DISABLED)
    sci4_tei_isr,
#endif
#if (BSP_IRQ_CFG_SCI4_ERI != BSP_IRQ_DISABLED)
    sci4_eri_isr,
#endif
#if (BSP_IRQ_CFG_SCI4_AM != BSP_IRQ_DISABLED)
    sci4_am_isr,
#endif
#if (BSP_IRQ_CFG_SCI5_RXI != BSP_IRQ_DISABLED)
    sci5_rxi_isr,
#endif
#if (BSP_IRQ_CFG_SCI5_TXI != BSP_IRQ_DISABLED)
    sci5_txi_isr,
#endif
#if (BSP_IRQ_CFG_SCI5_TEI != BSP_IRQ_DISABLED)
    sci5_tei_isr,
#endif
#if (BSP_IRQ_CFG_SCI5_ERI != BSP_IRQ_DISABLED)
    sci5_eri_isr,
#endif
#if (BSP_IRQ_CFG_SCI5_AM != BSP_IRQ_DISABLED)
    sci5_am_isr,
#endif
#if (BSP_IRQ_CFG_SCI6_RXI != BSP_IRQ_DISABLED)
    sci6_rxi_isr,
#endif
#if (BSP_IRQ_CFG_SCI6_TXI != BSP_IRQ_DISABLED)
    sci6_txi_isr,
#endif
#if (BSP_IRQ_CFG_SCI6_TEI != BSP_IRQ_DISABLED)
    sci6_tei_isr,
#endif
#if (BSP_IRQ_CFG_SCI6_ERI != BSP_IRQ_DISABLED)
    sci6_eri_isr,
#endif
#if (BSP_IRQ_CFG_SCI6_AM != BSP_IRQ_DISABLED)
    sci6_am_isr,
#endif
#if (BSP_IRQ_CFG_SCI7_RXI != BSP_IRQ_DISABLED)
    sci7_rxi_isr,
#endif
#if (BSP_IRQ_CFG_SCI7_TXI != BSP_IRQ_DISABLED)
    sci7_txi_isr,
#endif
#if (BSP_IRQ_CFG_SCI7_TEI != BSP_IRQ_DISABLED)
    sci7_tei_isr,
#endif
#if (BSP_IRQ_CFG_SCI7_ERI != BSP_IRQ_DISABLED)
    sci7_eri_isr,
#endif
#if (BSP_IRQ_CFG_SCI7_AM != BSP_IRQ_DISABLED)
    sci7_am_isr,
#endif
#if (BSP_IRQ_CFG_SCI8_RXI != BSP_IRQ_DISABLED)
    sci8_rxi_isr,
#endif
#if (BSP_IRQ_CFG_SCI8_TXI != BSP_IRQ_DISABLED)
    sci8_txi_isr,
#endif
#if (BSP_IRQ_CFG_SCI8_TEI != BSP_IRQ_DISABLED)
    sci8_tei_isr,
#endif
#if (BSP_IRQ_CFG_SCI8_ERI != BSP_IRQ_DISABLED)
    sci8_eri_isr,
#endif
#if (BSP_IRQ_CFG_SCI8_AM != BSP_IRQ_DISABLED)
    sci8_am_isr,
#endif
#if (BSP_IRQ_CFG_SCI9_RXI != BSP_IRQ_DISABLED)
    sci9_rxi_isr,
#endif
#if (BSP_IRQ_CFG_SCI9_TXI != BSP_IRQ_DISABLED)
    sci9_txi_isr,
#endif
#if (BSP_IRQ_CFG_SCI9_TEI != BSP_IRQ_DISABLED)
    sci9_tei_isr,
#endif
#if (BSP_IRQ_CFG_SCI9_ERI != BSP_IRQ_DISABLED)
    sci9_eri_isr,
#endif
#if (BSP_IRQ_CFG_SCI9_AM != BSP_IRQ_DISABLED)
    sci9_am_isr,
#endif
#if (BSP_IRQ_CFG_RSPI0_SPRI != BSP_IRQ_DISABLED)
    rspi0_spri_isr,
#endif
#if (BSP_IRQ_CFG_RSPI0_SPTI != BSP_IRQ_DISABLED)
    rspi0_spti_isr,
#endif
#if (BSP_IRQ_CFG_RSPI0_SPII != BSP_IRQ_DISABLED)
    rspi0_spii_isr,
#endif
#if (BSP_IRQ_CFG_RSPI0_SPEI != BSP_IRQ_DISABLED)
    rspi0_spei_isr,
#endif
#if (BSP_IRQ_CFG_RSPI0_SP_ELCTEND != BSP_IRQ_DISABLED)
    rspi0_sp_elctend_isr,
#endif
#if (BSP_IRQ_CFG_RSPI1_SPRI != BSP_IRQ_DISABLED)
    rspi1_spri_isr,
#endif
#if (BSP_IRQ_CFG_RSPI1_SPTI != BSP_IRQ_DISABLED)
    rspi1_spti_isr,
#endif
#if (BSP_IRQ_CFG_RSPI1_SPII != BSP_IRQ_DISABLED)
    rspi1_spii_isr,
#endif
#if (BSP_IRQ_CFG_RSPI1_SPEI != BSP_IRQ_DISABLED)
    rspi1_spei_isr,
#endif
#if (BSP_IRQ_CFG_RSPI1_SP_ELCTEND != BSP_IRQ_DISABLED)
    rspi1_sp_elctend_isr,
#endif
#if (BSP_IRQ_CFG_QSPI_INTR != BSP_IRQ_DISABLED)
    qspi_intr_isr,
#endif
#if (BSP_IRQ_CFG_SDHI_MMC0_ACCS != BSP_IRQ_DISABLED)
    sdhi_mmc0_accs_isr,
#endif
#if (BSP_IRQ_CFG_SDHI_MMC0_SDIO != BSP_IRQ_DISABLED)
    sdhi_mmc0_sdio_isr,
#endif
#if (BSP_IRQ_CFG_SDHI_MMC0_CARD != BSP_IRQ_DISABLED)
    sdhi_mmc0_card_isr,
#endif
#if (BSP_IRQ_CFG_SDHI_MMC0_ODMSDBREQ != BSP_IRQ_DISABLED)
    sdhi_mmc0_odmsdbreq_isr,
#endif
#if (BSP_IRQ_CFG_SDHI_MMC1_ACCS != BSP_IRQ_DISABLED)
    sdhi_mmc1_accs_isr,
#endif
#if (BSP_IRQ_CFG_SDHI_MMC1_SDIO != BSP_IRQ_DISABLED)
    sdhi_mmc1_sdio_isr,
#endif
#if (BSP_IRQ_CFG_SDHI_MMC1_CARD != BSP_IRQ_DISABLED)
    sdhi_mmc1_card_isr,
#endif
#if (BSP_IRQ_CFG_SDHI_MMC1_ODMSDBREQ != BSP_IRQ_DISABLED)
    sdhi_mmc1_odmsdbreq_isr,
#endif
#if (BSP_IRQ_CFG_EXT_DIVIDER_INTMD != BSP_IRQ_DISABLED)
    ext_divider_intmd_isr,
#endif
#if (BSP_IRQ_CFG_TSIP_PROC_BUSY_N != BSP_IRQ_DISABLED)
    tsip_proc_busy_n_isr,
#endif
#if (BSP_IRQ_CFG_TSIP_ROMOK_N != BSP_IRQ_DISABLED)
    tsip_romok_n_isr,
#endif
#if (BSP_IRQ_CFG_TSIP_LONG_PLG_N != BSP_IRQ_DISABLED)
    tsip_long_plg_n_isr,
#endif
#if (BSP_IRQ_CFG_TSIP_TEST_BUSY_N != BSP_IRQ_DISABLED)
    tsip_test_busy_n_isr,
#endif
#if (BSP_IRQ_CFG_TSIP_WRRDY_0_N != BSP_IRQ_DISABLED)
    tsip_wrrdy_0_n_isr,
#endif
#if (BSP_IRQ_CFG_TSIP_WRRDY_1_N != BSP_IRQ_DISABLED)
    tsip_wrrdy_1_n_isr,
#endif
#if (BSP_IRQ_CFG_TSIP_WRRDY_4_N != BSP_IRQ_DISABLED)
    tsip_wrrdy_4_n_isr,
#endif
#if (BSP_IRQ_CFG_TSIP_RDRDY_0_N != BSP_IRQ_DISABLED)
    tsip_rdrdy_0_n_isr,
#endif
#if (BSP_IRQ_CFG_TSIP_RDRDY_1_N != BSP_IRQ_DISABLED)
    tsip_rdrdy_1_n_isr,
#endif
#if (BSP_IRQ_CFG_TSIP_INTEGRATE_WRRDY_N != BSP_IRQ_DISABLED)
    tsip_integrate_wrrdy_n_isr,
#endif
#if (BSP_IRQ_CFG_TSIP_INTEGRATE_RDRDY_N != BSP_IRQ_DISABLED)
    tsip_integrate_rdrdy_n_isr,
#endif
#if (BSP_IRQ_CFG_LCDC_LCDC_LEVEL_0 != BSP_IRQ_DISABLED)
    lcdc_lcdc_level_0_isr,
#endif
#if (BSP_IRQ_CFG_LCDC_LCDC_LEVEL_1 != BSP_IRQ_DISABLED)
    lcdc_lcdc_level_1_isr,
#endif
#if (BSP_IRQ_CFG_LCDC_LCDC_LEVEL_2 != BSP_IRQ_DISABLED)
    lcdc_lcdc_level_2_isr,
#endif
#if (BSP_IRQ_CFG_TWOD_ENGINE_IRQ != BSP_IRQ_DISABLED)
    twod_engine_irq_isr,
#endif
#if (BSP_IRQ_CFG_JPEG_JEDI != BSP_IRQ_DISABLED)
    jpeg_jedi_isr,
#endif
#if (BSP_IRQ_CFG_JPEG_JDTI != BSP_IRQ_DISABLED)
    jpeg_jdti_isr,
#endif
};

#endif
