/*****************************************************************************
 * Copyright (C) 2015 by Embedded Product Design, LLC                        *
 *                                                                           *
 * FILENAME: support.c    PART OF PROJECT: DBSK_ble2click_PmodJSTK_demo      *
 *                                                                           *
 * FILE DESCRIPTION:                                                         *
 * Low-level support functions for the BLE and related functionality.        *
 *                                                                           *
 * HISTORY:                                                                  *
 * Date          By               Description                                *
 * 2015-10-09    Ed Strehle       Initial release for Renesas DevCon 2015    *
 * 2015-10-22    EPD/Ed Strehle   v1.1.0 update for SSP v1.0.0               *
 *                                                                           *
 * NOTES:                                                                    *
 *                                                                           *
 * KNOWN TODOs:                                                              *
 * <none>                                                                    *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
#include <string.h>
#include "hal_data.h"
#include "support.h"

// private prototypes
char low_nibble_to_hex (uint8_t Value);


// clears the selected buffer
void flush_rx_buff(void) {
	memset((char *)g_rx_buff, 0, g_data_len);
	g_data_len = 0;
	g_ble_data_ready = false;
}


char low_nibble_to_hex (uint8_t Value) {
	char tempval = ((char) Value) & 0x0F;

	if (tempval > 9) {
		return (char)(tempval + ASCII_A - 10);
	}
	else {
		return (char)(tempval + ASCII_0);
	}
}

// cconverts uint8_t to 2-character string
void byte_to_ascii_hex(uint8_t	Value, char * txt) {
	uint8_t tempval = Value;
	uint8_t i;

	for (i=0; i<2; i++) {
		txt[i] = low_nibble_to_hex(tempval & 0x0F);
		tempval >>= 4;
	}
	txt[2] = 0;  // terminate the string
}


// converts uint16_t to 4-character string
void word_to_ascii_hex(uint16_t Value, char * txt) {
	uint16_t tempval = Value;
	uint8_t i;

	for (i=0; i<4; i++) {
		txt[i] = low_nibble_to_hex(tempval & 0x0F);
		tempval >>= 4;
	}
	txt[4] = 0;  // terminate the string
}

// sends raw text string to uart2
void uart2_send_text(char * line) {
	ssp_err_t	err;
	uint32_t 	null_term_loc =  strlen(line);

	if (0 == null_term_loc) {
		return;
	}
	else {
		if ( null_term_loc > (MAX_BUFFER_LEN-1) ) {
			null_term_loc = MAX_BUFFER_LEN-1;
		}

		err = g_uart_on_sci.write (g_uart2.p_ctrl, (uint8_t *) &line[0], null_term_loc );
		dbsk_wait_for_uart2_tx_complete();
	}
}

// sends single raw character to uart2
void uart2_send_char(char letter) {
	ssp_err_t	err;

	err = g_uart_on_sci.write (g_uart2.p_ctrl, (uint8_t *) &letter, 1 );
	dbsk_wait_for_uart2_tx_complete();
}


// waiting for UART tx complete ... bits out of UART
void dbsk_wait_for_uart2_tx_complete(void) {
	while (!g_uart2_tx_complete) {
		R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);
	}
	g_uart2_tx_complete = false;	// clear the flag for the next run
}
