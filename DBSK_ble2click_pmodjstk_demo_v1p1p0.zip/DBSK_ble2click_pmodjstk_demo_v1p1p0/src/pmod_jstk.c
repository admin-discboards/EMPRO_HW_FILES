/*****************************************************************************
 * Copyright (C) 2015 by Embedded Product Design, LLC                        *
 *                                                                           *
 * FILENAME: pmod_jstk.c    PART OF PROJECT: DBSK_ble2click_PmodJSTK_demo    *
 *                                                                           *
 * FILE DESCRIPTION:                                                         *
 * Data structures matching the packets sent to and from the PmodJSTK        *
 * module.                                                                   *
 *                                                                           *
 * HISTORY:                                                                  *
 * Date          By               Description                                *
 * 2015-10-09    Ed Strehle       Initial release for Renesas DevCon 2015    *
 * 2015-10-22    EPD/Ed Strehle   v1.1.0 update for SSP v1.0.0               *
 *                                                                           *
 * NOTES:                                                                    *
 *                                                                           *
 * KNOWN TODOs:                                                              *
 * <none>                                                                    *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
#include "pmod_jstk.h"

u_pmodjstk_misobytes g_jstk_readbytes = {
							.members = {
									.x_rdg = PMODJSTK_JSTK_DEF,
									.y_rdg = PMODJSTK_JSTK_DEF,
									.buttons = PMODJSTK_BTN_DEF
								}
							};

u_pmodjstk_mosibytes g_jstk_ledcmds = { .mosi_a = {PMODJSTK_LEDCMD_DEF,0,0,0,0} };
