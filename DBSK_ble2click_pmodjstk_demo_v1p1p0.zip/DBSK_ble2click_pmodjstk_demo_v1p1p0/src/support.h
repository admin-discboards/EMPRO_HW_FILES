/*****************************************************************************
 * Copyright (C) 2015 by Embedded Product Design, LLC                        *
 *                                                                           *
 * FILENAME: support.h    PART OF PROJECT: DBSK_ble2click_PmodJSTK_demo      *
 *                                                                           *
 * FILE DESCRIPTION:                                                         *
 * Low-level support functions for the BLE and related functionality.        *
 *                                                                           *
 * HISTORY:                                                                  *
 * Date          By               Description                                *
 * 2015-10-09    Ed Strehle       Initial release for Renesas DevCon 2015    *
 * 2015-10-22    EPD/Ed Strehle   v1.1.0 update for SSP v1.0.0               *
 *                                                                           *
 * NOTES:                                                                    *
 *                                                                           *
 * KNOWN TODOs:                                                              *
 * <none>                                                                    *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
#include "hal_data.h"
#ifndef SUPPORT_H_
#define SUPPORT_H_

/** DiscBoard user button */
#define DBSK_BUTTON01		((ioport_port_pin_t) IOPORT_PORT_01_PIN_11)

/** DiscBoard LEDs */
#define DB_LED_CPU          ((ioport_port_pin_t) IOPORT_PORT_01_PIN_09)
#define	DBSK_LED_D3         ((ioport_port_pin_t) IOPORT_PORT_02_PIN_00)
#define DBSK_LED_D4         ((ioport_port_pin_t) IOPORT_PORT_04_PIN_02)

/** BLE2_Click interface pins */
#define RGBLED_DATA_PIN		((ioport_port_pin_t) IOPORT_PORT_00_PIN_10)

#define CLICK_L1_AN_BLE2CONN     	((ioport_port_pin_t) IOPORT_PORT_00_PIN_00)
#define CLICK_L2_RST_BLE2SWAKE   	((ioport_port_pin_t) IOPORT_PORT_00_PIN_10)
#define CLICK_R1_PWM_BLE2CMD_MLDP	((ioport_port_pin_t) IOPORT_PORT_04_PIN_08)
#define CLICK_R3_RX_BLE2uartTX   	((ioport_port_pin_t) IOPORT_PORT_03_PIN_01)
#define CLICK_R4_TX_BLE2uartRX   	((ioport_port_pin_t) IOPORT_PORT_01_PIN_12)

// PMOD pins for Type 2A expanded UART (Pmod_JSTK uses pins 1-6)
#define PMOD2A_01_SS				((ioport_port_pin_t) IOPORT_PORT_03_PIN_07)
#define PMOD2A_02_MOSI            	((ioport_port_pin_t) IOPORT_PORT_03_PIN_05)
#define PMOD2A_03_MISO            	((ioport_port_pin_t) IOPORT_PORT_03_PIN_04)
#define PMOD2A_04_SCK             	((ioport_port_pin_t) IOPORT_PORT_03_PIN_06)
//#define PMOD2A_07_INT				((ioport_port_pin_t) IOPORT_PORT_00_PIN_09)
//#define PMOD2A_08_RESET           ((ioport_port_pin_t) IOPORT_PORT_06_PIN_03)
//#define PMOD2A_09_NS            	((ioport_port_pin_t) IOPORT_PORT_06_PIN_04)
//#define PMOD2A_10_NS             	((ioport_port_pin_t) IOPORT_PORT_06_PIN_05)

#define ASCII_A		0x41
#define ASCII_0		0x30
#define ASCII_CR	0x0D
#define ASCII_LF	0x0A
#define MAX_BUFFER_LEN        0x40

// globals shared from hal_entry.c
extern volatile bool 		g_ble_data_ready;
extern volatile bool 		g_uart2_tx_complete;
extern volatile bool		g_ble_connected;
extern volatile uint8_t 	g_data_len;
extern volatile char        g_rx_buff[MAX_BUFFER_LEN];
extern volatile char        g_tx_buff[MAX_BUFFER_LEN];

//functions prototypes
void flush_rx_buff(void);
void byte_to_ascii_hex(uint8_t	Value, char * txt);
void word_to_ascii_hex(uint16_t Value, char * txt);
void uart2_send_text(char * line);
void uart2_send_char(char letter);
void dbsk_wait_for_uart2_tx_complete(void);

#endif /* SUPPORT_H_ */
