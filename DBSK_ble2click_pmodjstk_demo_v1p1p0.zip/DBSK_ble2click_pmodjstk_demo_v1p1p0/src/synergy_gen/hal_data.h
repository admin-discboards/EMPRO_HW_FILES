/* generated HAL header file - do not edit */
#ifndef HAL_DATA_H_
#define HAL_DATA_H_
#include <stdint.h>
#include "bsp_api.h"
#include "r_icu.h"
#include "r_external_irq_api.h"
#include "r_agt.h"
#include "r_timer_api.h"
#include "r_sci_uart.h"
#include "r_uart_api.h"
#include "r_sci_spi.h"
#include "r_spi_api.h"
#include "r_ioport.h"
#include "r_ioport_api.h"
#include "r_elc.h"
#include "r_elc_api.h"
#include "r_cgc.h"
#include "r_cgc_api.h"
/** SPI on SCI Instance. */
extern const spi_instance_t g_sci_spi6;
#ifdef callback_sci_spi6
#define SPI_ON_SCI_SPI_CALLBACK_USED_g_sci_spi6 (0)
#else
#define SPI_ON_SCI_SPI_CALLBACK_USED_g_sci_spi6 (1)
#endif
#if SPI_ON_SCI_SPI_CALLBACK_USED_g_sci_spi6
void callback_sci_spi6(spi_callback_args_t * p_args);
#endif
/* External IRQ on ICU Instance. */
extern const external_irq_instance_t g_ext_irq6;
#ifdef callback_dbskPinP000
#define EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_ext_irq6 (0)
#else
#define EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_ext_irq6 (1)
#endif
#if EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_ext_irq6
void callback_dbskPinP000(external_irq_callback_args_t * p_args);
#endif
/** AGT Timer Instance */
extern const timer_instance_t g_timer;
#ifdef callback_g_timer
#define TIMER_ON_AGT_CALLBACK_USED_g_timer (0)
#else
#define TIMER_ON_AGT_CALLBACK_USED_g_timer (1)
#endif
#if TIMER_ON_AGT_CALLBACK_USED_g_timer
void callback_g_timer(timer_callback_args_t * p_args);
#endif
/** UART on SCI Instance. */
extern const uart_instance_t g_uart2;
#ifdef NULL
#else
extern void NULL(uint32_t channel, uint32_t level);
#endif
#ifdef callback_uart2
#define UART_ON_SCI_UART_CALLBACK_USED_g_uart2 (0)
#else
#define UART_ON_SCI_UART_CALLBACK_USED_g_uart2 (1)
#endif
#if UART_ON_SCI_UART_CALLBACK_USED_g_uart2
void callback_uart2(uart_callback_args_t * p_args);
#endif
/* External IRQ on ICU Instance. */
extern const external_irq_instance_t g_ext_irq4;
#ifdef callback_buttonS1
#define EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_ext_irq4 (0)
#else
#define EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_ext_irq4 (1)
#endif
#if EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_ext_irq4
void callback_buttonS1(external_irq_callback_args_t * p_args);
#endif
/** IOPORT Instance */
extern const ioport_instance_t g_ioport;
/** ELC Instance */
extern const elc_instance_t g_elc;
/** CGC Instance */
extern const cgc_instance_t g_cgc;
/** Prototypes for generated HAL functions. */
void hal_entry(void);
void g_hal_init(void);
#endif /* HAL_DATA_H_ */
