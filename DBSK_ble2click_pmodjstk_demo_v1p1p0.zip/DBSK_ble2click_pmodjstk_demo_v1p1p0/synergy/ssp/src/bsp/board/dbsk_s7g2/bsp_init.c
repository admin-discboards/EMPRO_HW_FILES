/***********************************************************************************************************************
 * Copyright [2015] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 * 
 * This file is part of Renesas SynergyTM Software Package (SSP)
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * This file is subject to a Renesas SSP license agreement. Unless otherwise agreed in an SSP license agreement with
 * Renesas: 1) you may not use, copy, modify, distribute, display, or perform the contents; 2) you may not use any name
 * or mark of Renesas for advertising or publicity purposes or in connection with your use of the contents; 3) RENESAS
 * MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED
 * "AS IS" WITHOUT ANY EXPRESS OR IMPLIED WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR
 * CONSEQUENTIAL DAMAGES, INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF
 * CONTRACT OR TORT, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents
 * included in this file may be subject to different terms.
 **********************************************************************************************************************/
/*****************************************************************************
 * Copyright (C) 2015 by Embedded Product Design, LLC                        *
 *                                                                           *
 * FILENAME: bsp_init.c           PART OF PROJECT: BSP dbsk_s7g2 v 1.0.0     *
 *                                                                           *
 * FILE DESCRIPTION:                                                         *
 * Used BSP dk_s7g2 as a starting point for new DiscBoards SK S7G2 BSP.      *
 * Checked for use with Renesas SSP v1.0.0.                                  *
 *                                                                           *
 * HISTORY:                                                                  *
 * Date          By               Description                                *
 * 2015-10-20    EPD/Ed Strehle   Initial DiscBoards SK S7G2 BSP v1.0.0      *
 *                                                                           *
 * NOTES:                                                                    *
 *                                                                           *
 * KNOWN TODOs:                                                              *
 * <none>                                                                    *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
/***********************************************************************************************************************
* File Name    : bsp_init.c
* Description  : This module calls any initialization code specific to this BSP.
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @addtogroup BSP_BOARD_DK2M_INIT
 *
 * @{
 **********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "bsp_api.h"

#if defined(BSP_BOARD_DBSK_S7G2)

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
 
/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief      Performs any initialization specific to this BSP.
 *
 * @param[in]  p_args         Pointer to arguments of the user's choice.
 **********************************************************************************************************************/
void bsp_init (void * p_args)
{
    SSP_PARAMETER_NOT_USED(p_args);

    /** Set VBTICTLR=0 to prevent P402-P404 reverting to RTC function powered from the NC VBAT pins.
     *  VBTICTLR is skipped in R_SYSTEM_TYPE in R7FS7G2x.h.
     *  DiscBoard SK S7G2 uses->  P402=DBSK_LED_D3, P403=GPIO, P404=GPIO
     *  See S7 User's Manual section 20.5.5 for more information.
     */
    R_BSP_RegisterProtectDisable(BSP_REG_PROTECT_OM_LPC_BATT);
    *((uint8_t *) ADDR_VBTICTLR) = 0x0;                             // disable VBAT in function
    R_BSP_RegisterProtectEnable(BSP_REG_PROTECT_OM_LPC_BATT);
}

#endif

/** @} (end addtogroup BSP_BOARD_DK2M_INIT) */

