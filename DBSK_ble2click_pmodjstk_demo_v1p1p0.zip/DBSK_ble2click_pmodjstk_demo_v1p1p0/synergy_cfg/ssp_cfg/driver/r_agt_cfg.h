/* generated configuration header file - do not edit */
#ifndef R_AGT_CFG_H_
#define R_AGT_CFG_H_
#define AGT_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* R_AGT_CFG_H_ */
