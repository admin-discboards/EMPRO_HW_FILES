/* generated config header file - do not edit */
#ifndef R_CGC_CFG_H_
#define R_CGC_CFG_H_
#define CGC_CFG_MAIN_OSC_WAIT (9)
#define CGC_CFG_MAIN_OSC_CLOCK_SOURCE (1)
#define CGC_CFG_OSC_STOP_DET_USED (1)
#define CGC_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLED)
#define CGC_CFG_SUBCLOCK_DRIVE (0)
#endif /* R_CGC_CFG_H_ */
