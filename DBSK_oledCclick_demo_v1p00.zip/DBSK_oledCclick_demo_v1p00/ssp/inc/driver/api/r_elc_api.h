/***********************************************************************************************************************
 * Copyright [2015] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
 * display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
 * purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
 * SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
 * NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
 * OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
 * be subject to different terms.
 **********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : r_elc_api.h
 * Description  : ELC Interface
 ***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *           ELC  1.00    Initial Release.
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @ingroup Interface_Library
 * @defgroup ELC_API ELC Interface
 * @brief Event Link Controller APIs
 *
 * @{
 **********************************************************************************************************************/

#ifndef DRV_ELC_API_H
#define DRV_ELC_API_H

/***********************************************************************************************************************
 * Includes
 **********************************************************************************************************************/
/* Register definitions, common services and error codes. */
#include "bsp_api.h"

/**********************************************************************************************************************
 * Macro definitions
 **********************************************************************************************************************/
#define ELC_API_VERSION_MAJOR (01)
#define ELC_API_VERSION_MINOR (00)

/**********************************************************************************************************************
 * Typedef definitions
 **********************************************************************************************************************/
/** Possible peripherals to be linked to event signals */
typedef enum e_elc_peripheral
{
    ELC_PERIPHERAL_GPT_A        = (0),  ///< General purpose timer event A
    ELC_PERIPHERAL_GPT_B        = (1),  ///< General purpose timer event B
    ELC_PERIPHERAL_GPT_C        = (2),  ///< General purpose timer event C
    ELC_PERIPHERAL_GPT_D        = (3),  ///< General purpose timer event D
    ELC_PERIPHERAL_GPT_E        = (4),  ///< General purpose timer event E
    ELC_PERIPHERAL_GPT_F        = (5),  ///< General purpose timer event F
    ELC_PERIPHERAL_GPT_G        = (6),  ///< General purpose timer event G
    ELC_PERIPHERAL_GPT_H        = (7),  ///< General purpose timer event H
    ELC_PERIPHERAL_S12ADA0      = (8),  ///< 12 bit ADC Unit 0 Group A
    ELC_PERIPHERAL_S12ADB0      = (9),  ///< 12 bit ADC Unit 0 Group B
    ELC_PERIPHERAL_S12ADA1      = (10), ///< 12 bit ADC Unit 1 Group A
    ELC_PERIPHERAL_S12ADB1      = (11), ///< 12 bit ADC Unit 1 Group B
    ELC_PERIPHERAL_DA0          = (12), ///< 12 bit DAC Channel 0
    ELC_PERIPHERAL_DA1          = (13), ///< 12 bit DAC Channel 1
    ELC_PERIPHERAL_PORT_GROUP_A = (14), ///< GPIO Port Group A
    ELC_PERIPHERAL_PORT_GROUP_B = (15), ///< GPIO Port Group B
    ELC_PERIPHERAL_PORT_GROUP_C = (16), ///< GPIO Port Group C
    ELC_PERIPHERAL_PORT_GROUP_D = (17), ///< GPIO Port Group D
    ELC_PERIPHERAL_CTSU         = (18), ///< Capacitive Touch Sensing Unit
} elc_peripheral_t;

/** Sources of event signals to be linked to other peripherals or the CPU
 * @note This list may change based on device. This list is for S7G2.
 * */
typedef enum e_elc_event
{
    ELC_EVENT_PORT0_IRQ                     = (0x1),      ///< IRQ0
    ELC_EVENT_PORT1_IRQ                     = (0x2),      ///< IRQ1
    ELC_EVENT_PORT2_IRQ                     = (0x3),      ///< IRQ2
    ELC_EVENT_PORT3_IRQ                     = (0x4),      ///< IRQ3
    ELC_EVENT_PORT4_IRQ                     = (0x5),      ///< IRQ4
    ELC_EVENT_PORT5_IRQ                     = (0x6),      ///< IRQ5
    ELC_EVENT_PORT6_IRQ                     = (0x7),      ///< IRQ6
    ELC_EVENT_PORT7_IRQ                     = (0x8),      ///< IRQ7
    ELC_EVENT_PORT8_IRQ                     = (0x9),      ///< IRQ8
    ELC_EVENT_PORT9_IRQ                     = (0xA),      ///< IRQ9
    ELC_EVENT_PORT10_IRQ                    = (0xB),      ///< IRQ10
    ELC_EVENT_PORT11_IRQ                    = (0xC),      ///< IRQ11
    ELC_EVENT_PORT12_IRQ                    = (0xD),      ///< IRQ12
    ELC_EVENT_PORT13_IRQ                    = (0xE),      ///< IRQ13
    ELC_EVENT_PORT14_IRQ                    = (0xF),      ///< IRQ14
    ELC_EVENT_PORT15_IRQ                    = (0x10),     ///< IRQ15
    ELC_EVENT_DMAC0_DMAC                    = (0x20),     ///< Transfer end or escape transfer end
    ELC_EVENT_DMAC1_DMAC                    = (0x21),     ///< Transfer end or escape transfer end
    ELC_EVENT_DMAC2_DMAC                    = (0x22),     ///< Transfer end or escape transfer end
    ELC_EVENT_DMAC3_DMAC                    = (0x23),     ///< Transfer end or escape transfer end
    ELC_EVENT_DMAC4_DMAC                    = (0x24),     ///< Transfer end or escape transfer end
    ELC_EVENT_DMAC5_DMAC                    = (0x25),     ///< Transfer end or escape transfer end
    ELC_EVENT_DMAC6_DMAC                    = (0x26),     ///< Transfer end or escape transfer end
    ELC_EVENT_DMAC7_DMAC                    = (0x27),     ///< Transfer end or escape transfer end
    ELC_EVENT_DTC_TRANSFER                  = (0x28),     ///< DTC Transfer
    ELC_EVENT_DTC_COMPLETE                  = (0x29),     ///< DTC Complete
    ELC_EVENT_DTC_DTC_END                   = (0x2A),     ///< DTC End
    ELC_EVENT_EXDMAC0_EXDMAC                = (0x2B),     ///< EXDMAC0_EXDMAC
    ELC_EVENT_EXDMAC1_EXDMAC                = (0x2C),     ///< EXDMAC1_EXDMAC
    ELC_EVENT_ICU_CANCELING_SNOOZE_MODE     = (0x2D),     ///< ICU_CANCELING_SNOOZE_MODE
    ELC_EVENT_FCU_FIFERR                    = (0x30),     ///< FCU_FIFERR
    ELC_EVENT_FCU_FRDYI                     = (0x31),     ///< FCU_FRDYI
    ELC_EVENT_FCU_ECCERR                    = (0x32),     ///< FCU_ECCERR
    ELC_EVENT_LVD1_LVD1                     = (0x38),     ///< Voltage-monitoring 1 interrupt
    ELC_EVENT_LVD2_LVD2                     = (0x39),     ///< Voltage-monitoring 2 interrupt
    ELC_EVENT_VBATT_VBAT                    = (0x3A),     ///< VBAT
    ELC_EVENT_MOSC_OSC_STOP                 = (0x3B),     ///< OSC_STOP
    ELC_EVENT_CPUSYS_SNOOZE_MODE_ENTRY_FLAG = (0x3C),     ///< CPUSYS_SNOOZE_MODE_ENTRY_FLAG
    ELC_EVENT_AGT0_AGTI                     = (0x40),     ///< AGT interrupt
    ELC_EVENT_AGT0_AGTCMAI                  = (0x41),     ///< The values of AGT and AGTCMA matched
    ELC_EVENT_AGT0_AGTCMBI                  = (0x42),     ///< The values of AGT and AGTCMB matched
    ELC_EVENT_AGT1_AGTI                     = (0x43),     ///< AGT interrupt
    ELC_EVENT_AGT1_AGTCMAI                  = (0x44),     ///< The values of AGT and AGTCMA matched
    ELC_EVENT_AGT1_AGTCMBI                  = (0x45),     ///< The values of AGT and AGTCMB matched
    ELC_EVENT_IWDT_NMIUNDF_N                = (0x46),     ///< IWDT_NMIUNDF_N
    ELC_EVENT_CWDT_NMIUNDF_N                = (0x47),     ///< Down-counter underflows or
    ELC_EVENT_RTC_ALM                       = (0x48),     ///< RTC alarm
    ELC_EVENT_RTC_PRD                       = (0x49),     ///< Periodic interrupt
    ELC_EVENT_RTC_CUP                       = (0x4A),     ///< RTC_CUP
    ELC_EVENT_S12AD0_ADI                    = (0x4B),     ///< A/D scan end interrupt
    ELC_EVENT_S12AD0_GBADI                  = (0x4C),     ///< A/D scan end interrupt for group B
    ELC_EVENT_S12AD0_CMPAI                  = (0x4D),     ///< S12AD0_CMPAI
    ELC_EVENT_S12AD0_CMPBI                  = (0x4E),     ///< S12AD0_CMPBI
    ELC_EVENT_S12AD0_COMPARE_MATCH          = (0x4F),     ///< Compare match
    ELC_EVENT_S12AD0_COMPARE_MISMATCH       = (0x50),     ///< Compare mismatch
    ELC_EVENT_S12AD1_ADI                    = (0x51),     ///< A/D scan end interrupt
    ELC_EVENT_S12AD1_GBADI                  = (0x52),     ///< A/D scan end interrupt for group B
    ELC_EVENT_S12AD1_CMPAI                  = (0x53),     ///< S12AD1_CMPAI
    ELC_EVENT_S12AD1_CMPBI                  = (0x54),     ///< S12AD1_CMPBI
    ELC_EVENT_S12AD1_COMPARE_MATCH          = (0x55),     ///< Compare match
    ELC_EVENT_S12AD1_COMPARE_MISMATCH       = (0x56),     ///< Compare mismatch
    ELC_EVENT_COMP_OC0_COMP_IRQ             = (0x57),     ///< Comparator interrupt
    ELC_EVENT_COMP_RD1_COMP_IRQ             = (0x58),     ///< Comparator interrupt
    ELC_EVENT_COMP_RD2_COMP_IRQ             = (0x59),     ///< Comparator interrupt
    ELC_EVENT_COMP_RD3_COMP_IRQ             = (0x5A),     ///< Comparator interrupt
    ELC_EVENT_COMP_RD4_COMP_IRQ             = (0x5B),     ///< Comparator interrupt
    ELC_EVENT_COMP_RD5_COMP_IRQ             = (0x5C),     ///< Comparator interrupt
    ELC_EVENT_COMP_LP_COMP_C0IRQ            = (0x5D),     ///< COMP_LP_COMP_C0IRQ
    ELC_EVENT_COMP_LP_COMP_C1IRQ            = (0x5E),     ///< COMP_LP_COMP_C1IRQ
    ELC_EVENT_USBFS_D0FIFO                  = (0x5F),     ///< USBFS_D0FIFO
    ELC_EVENT_USBFS_D1FIFO                  = (0x60),     ///< USBFS_D1FIFO
    ELC_EVENT_USBFS_USBI                    = (0x61),     ///< USBFS_USBI
    ELC_EVENT_USBFS_USBR                    = (0x62),     ///< USBFS_USBR
    ELC_EVENT_RIIC0_RXI                     = (0x63),     ///< Receive data full
    ELC_EVENT_RIIC0_TXI                     = (0x64),     ///< Transmit data empty
    ELC_EVENT_RIIC0_TEI                     = (0x65),     ///< Transmit end
    ELC_EVENT_RIIC0_EEI0                    = (0x66),     ///< Transfer error/event generation
    ELC_EVENT_RIIC0_WUI                     = (0x67),     ///< RIIC0_WUI
    ELC_EVENT_RIIC1_RXI                     = (0x68),     ///< Receive data full
    ELC_EVENT_RIIC1_TXI                     = (0x69),     ///< Transmit data empty
    ELC_EVENT_RIIC1_TEI                     = (0x6A),     ///< Transmit end
    ELC_EVENT_RIIC1_EEI0                    = (0x6B),     ///< Transfer error/event generation
    ELC_EVENT_RIIC2_RXI                     = (0x6D),     ///< Receive data full
    ELC_EVENT_RIIC2_TXI                     = (0x6E),     ///< Transmit data empty
    ELC_EVENT_RIIC2_TEI                     = (0x6F),     ///< Transmit end
    ELC_EVENT_RIIC2_EEI0                    = (0x70),     ///< Transfer error/event generation
    ELC_EVENT_SSI0_SSITXI                   = (0x72),     ///< SSI0_SSITXI
    ELC_EVENT_SSI0_SSIRXI                   = (0x73),     ///< SSI0_SSIRXI
    ELC_EVENT_SSI0_SSIRT                    = (0x74),     ///< SSI0_SSIRT
    ELC_EVENT_SSI0_SSIF                     = (0x75),     ///< SSI0_SSIF
    ELC_EVENT_SSI1_SSITXI                   = (0x76),     ///< SSI1_SSITXI
    ELC_EVENT_SSI1_SSIRXI                   = (0x77),     ///< SSI1_SSIRXI
    ELC_EVENT_SSI1_SSIRT                    = (0x78),     ///< SSI1_SSIRT
    ELC_EVENT_SSI1_SSIF                     = (0x79),     ///< SSI1_SSIF
    ELC_EVENT_SRC_IDEI                      = (0x7A),     ///< SRC_IDEI
    ELC_EVENT_SRC_ODFI                      = (0x7B),     ///< SRC_ODFI
    ELC_EVENT_SRC_OVF                       = (0x7C),     ///< SRC_OVF
    ELC_EVENT_SRC_UDF                       = (0x7D),     ///< SRC_UDF
    ELC_EVENT_SRC_CEF                       = (0x7E),     ///< SRC_CEF
    ELC_EVENT_PDC_PCDFI                     = (0x7F),     ///< PDC_PCDFI
    ELC_EVENT_PDC_PCFEI                     = (0x80),     ///< PDC_PCFEI
    ELC_EVENT_PDC_PCERI                     = (0x81),     ///< PDC_PCERI
    ELC_EVENT_CTSU_CTSUWR                   = (0x82),     ///< CTSU_CTSUWR
    ELC_EVENT_CTSU_CTSURD                   = (0x83),     ///< CTSU_CTSURD
    ELC_EVENT_CTSU_CTSUFN                   = (0x84),     ///< CTSU_CTSUFN
    ELC_EVENT_KEY_INTKR                     = (0x85),     ///< KEY_INTKR
    ELC_EVENT_DOC_DOPCF                     = (0x86),     ///< Data operation circuit interrupt
    ELC_EVENT_CAC_FERRF                     = (0x87),     ///< CAC_FERRF
    ELC_EVENT_CAC_MENDF                     = (0x88),     ///< CAC_MENDF
    ELC_EVENT_CAC_OVFF                      = (0x89),     ///< CAC_OVFF
    ELC_EVENT_RCAN20_ERS                    = (0x8A),     ///< RCAN20_ERS
    ELC_EVENT_RCAN20_RXF                    = (0x8B),     ///< RCAN20_RXF
    ELC_EVENT_RCAN20_TXF                    = (0x8C),     ///< RCAN20_TXF
    ELC_EVENT_RCAN20_RXM                    = (0x8D),     ///< RCAN20_RXM
    ELC_EVENT_RCAN20_TXM                    = (0x8E),     ///< RCAN20_TXM
    ELC_EVENT_RCAN21_ERS                    = (0x8F),     ///< RCAN21_ERS
    ELC_EVENT_RCAN21_RXF                    = (0x90),     ///< RCAN21_RXF
    ELC_EVENT_RCAN21_TXF                    = (0x91),     ///< RCAN21_TXF
    ELC_EVENT_RCAN21_RXM                    = (0x92),     ///< RCAN21_RXM
    ELC_EVENT_RCAN21_TXM                    = (0x93),     ///< RCAN21_TXM
    ELC_EVENT_GPIO_PORT_GROUP_A             = (0x94),     ///< GPIO_PORT_GROUP_A
    ELC_EVENT_GPIO_PORT_GROUP_B             = (0x95),     ///< GPIO_PORT_GROUP_B
    ELC_EVENT_GPIO_PORT_GROUP_C             = (0x96),     ///< GPIO_PORT_GROUP_C
    ELC_EVENT_GPIO_PORT_GROUP_D             = (0x97),     ///< GPIO_PORT_GROUP_D
    ELC_EVENT_ELC0_SOFTWARE_EVENT           = (0x98),     ///< ELC0_SOFTWARE_EVENT
    ELC_EVENT_ELC1_SOFTWARE_EVENT           = (0x99),     ///< ELC1_SOFTWARE_EVENT
    ELC_EVENT_POEG_GROUP_EVENT0             = (0x9A),     ///< POEG_GROUP_EVENT0
    ELC_EVENT_POEG_GROUP_EVENT1             = (0x9B),     ///< POEG_GROUP_EVENT1
    ELC_EVENT_POEG_GROUP_EVENT2             = (0x9C),     ///< POEG_GROUP_EVENT2
    ELC_EVENT_POEG_GROUP_EVENT3             = (0x9D),     ///< POEG_GROUP_EVENT3
    ELC_EVENT_GPT0_CAPTURE_COMPARE_INT_A    = (0xB0),     ///< GTCCRA input capture/compare match
    ELC_EVENT_GPT0_CAPTURE_COMPARE_INT_B    = (0xB1),     ///< GTCCRB input capture/compare match
    ELC_EVENT_GPT0_COMPARE_INT_C            = (0xB2),     ///< GTCCRC compare match
    ELC_EVENT_GPT0_COMPARE_INT_D            = (0xB3),     ///< GTCCRD compare match
    ELC_EVENT_GPT0_COMPARE_INT_E            = (0xB4),     ///< GTCCRE compare match
    ELC_EVENT_GPT0_COMPARE_INT_F            = (0xB5),     ///< GTCCRF compare match
    ELC_EVENT_GPT0_COUNTER_OVERFLOW         = (0xB6),     ///< GTCNT overflow
    ELC_EVENT_GPT0_COUNTER_UNDERFLOW        = (0xB7),     ///< GTCNT underflow
    ELC_EVENT_GPT0_AD_TRIG_A                = (0xB8),     ///< GTADTRA compare match
    ELC_EVENT_GPT0_AD_TRIG_B                = (0xB9),     ///< GTADTRB compare match
    ELC_EVENT_GPT1_CAPTURE_COMPARE_INT_A    = (0xBA),     ///< GTCCRA input capture/compare match
    ELC_EVENT_GPT1_CAPTURE_COMPARE_INT_B    = (0xBB),     ///< GTCCRB input capture/compare match
    ELC_EVENT_GPT1_COMPARE_INT_C            = (0xBC),     ///< GTCCRC compare match
    ELC_EVENT_GPT1_COMPARE_INT_D            = (0xBD),     ///< GTCCRD compare match
    ELC_EVENT_GPT1_COMPARE_INT_E            = (0xBE),     ///< GTCCRE compare match
    ELC_EVENT_GPT1_COMPARE_INT_F            = (0xBF),     ///< GTCCRF compare match
    ELC_EVENT_GPT1_COUNTER_OVERFLOW         = (0xC0),     ///< GTCNT overflow
    ELC_EVENT_GPT1_COUNTER_UNDERFLOW        = (0xC1),     ///< GTCNT underflow
    ELC_EVENT_GPT1_AD_TRIG_A                = (0xC2),     ///< GTADTRA compare match
    ELC_EVENT_GPT1_AD_TRIG_B                = (0xC3),     ///< GTADTRB compare match
    ELC_EVENT_GPT2_CAPTURE_COMPARE_INT_A    = (0xC4),     ///< GTCCRA input capture/compare match
    ELC_EVENT_GPT2_CAPTURE_COMPARE_INT_B    = (0xC5),     ///< GTCCRB input capture/compare match
    ELC_EVENT_GPT2_COMPARE_INT_C            = (0xC6),     ///< GTCCRC compare match
    ELC_EVENT_GPT2_COMPARE_INT_D            = (0xC7),     ///< GTCCRD compare match
    ELC_EVENT_GPT2_COMPARE_INT_E            = (0xC8),     ///< GTCCRE compare match
    ELC_EVENT_GPT2_COMPARE_INT_F            = (0xC9),     ///< GTCCRF compare match
    ELC_EVENT_GPT2_COUNTER_OVERFLOW         = (0xCA),     ///< GTCNT overflow
    ELC_EVENT_GPT2_COUNTER_UNDERFLOW        = (0xCB),     ///< GTCNT underflow
    ELC_EVENT_GPT2_AD_TRIG_A                = (0xCC),     ///< GTADTRA compare match
    ELC_EVENT_GPT2_AD_TRIG_B                = (0xCD),     ///< GTADTRB compare match
    ELC_EVENT_GPT3_CAPTURE_COMPARE_INT_A    = (0xCE),     ///< GTCCRA input capture/compare match
    ELC_EVENT_GPT3_CAPTURE_COMPARE_INT_B    = (0xCF),     ///< GTCCRB input capture/compare match
    ELC_EVENT_GPT3_COMPARE_INT_C            = (0xD0),     ///< GTCCRC compare match
    ELC_EVENT_GPT3_COMPARE_INT_D            = (0xD1),     ///< GTCCRD compare match
    ELC_EVENT_GPT3_COMPARE_INT_E            = (0xD2),     ///< GTCCRE compare match
    ELC_EVENT_GPT3_COMPARE_INT_F            = (0xD3),     ///< GTCCRF compare match
    ELC_EVENT_GPT3_COUNTER_OVERFLOW         = (0xD4),     ///< GTCNT overflow
    ELC_EVENT_GPT3_COUNTER_UNDERFLOW        = (0xD5),     ///< GTCNT underflow
    ELC_EVENT_GPT3_AD_TRIG_A                = (0xD6),     ///< GTADTRA compare match
    ELC_EVENT_GPT3_AD_TRIG_B                = (0xD7),     ///< GTADTRB compare match
    ELC_EVENT_GPT4_CAPTURE_COMPARE_INT_A    = (0xD8),     ///< GTCCRA input capture/compare match
    ELC_EVENT_GPT4_CAPTURE_COMPARE_INT_B    = (0xD9),     ///< GTCCRB input capture/compare match
    ELC_EVENT_GPT4_COMPARE_INT_C            = (0xDA),     ///< GTCCRC compare match
    ELC_EVENT_GPT4_COMPARE_INT_D            = (0xDB),     ///< GTCCRD compare match
    ELC_EVENT_GPT4_COMPARE_INT_E            = (0xDC),     ///< GTCCRE compare match
    ELC_EVENT_GPT4_COMPARE_INT_F            = (0xDD),     ///< GTCCRF compare match
    ELC_EVENT_GPT4_COUNTER_OVERFLOW         = (0xDE),     ///< GTCNT overflow
    ELC_EVENT_GPT4_COUNTER_UNDERFLOW        = (0xDF),     ///< GTCNT underflow
    ELC_EVENT_GPT4_AD_TRIG_A                = (0xE0),     ///< GTADTRA compare match
    ELC_EVENT_GPT4_AD_TRIG_B                = (0xE1),     ///< GTADTRB compare match
    ELC_EVENT_GPT5_CAPTURE_COMPARE_INT_A    = (0xE2),     ///< GTCCRA input capture/compare match
    ELC_EVENT_GPT5_CAPTURE_COMPARE_INT_B    = (0xE3),     ///< GTCCRB input capture/compare match
    ELC_EVENT_GPT5_COMPARE_INT_C            = (0xE4),     ///< GTCCRC compare match
    ELC_EVENT_GPT5_COMPARE_INT_D            = (0xE5),     ///< GTCCRD compare match
    ELC_EVENT_GPT5_COMPARE_INT_E            = (0xE6),     ///< GTCCRE compare match
    ELC_EVENT_GPT5_COMPARE_INT_F            = (0xE7),     ///< GTCCRF compare match
    ELC_EVENT_GPT5_COUNTER_OVERFLOW         = (0xE8),     ///< GTCNT overflow
    ELC_EVENT_GPT5_COUNTER_UNDERFLOW        = (0xE9),     ///< GTCNT underflow
    ELC_EVENT_GPT5_AD_TRIG_A                = (0xEA),     ///< GTADTRA compare match
    ELC_EVENT_GPT5_AD_TRIG_B                = (0xEB),     ///< GTADTRB compare match
    ELC_EVENT_GPT6_CAPTURE_COMPARE_INT_A    = (0xEC),     ///< GTCCRA input capture/compare match
    ELC_EVENT_GPT6_CAPTURE_COMPARE_INT_B    = (0xED),     ///< GTCCRB input capture/compare match
    ELC_EVENT_GPT6_COMPARE_INT_C            = (0xEE),     ///< GTCCRC compare match
    ELC_EVENT_GPT6_COMPARE_INT_D            = (0xEF),     ///< GTCCRD compare match
    ELC_EVENT_GPT6_COMPARE_INT_E            = (0xF0),     ///< GTCCRE compare match
    ELC_EVENT_GPT6_COMPARE_INT_F            = (0xF1),     ///< GTCCRF compare match
    ELC_EVENT_GPT6_COUNTER_OVERFLOW         = (0xF2),     ///< GTCNT overflow
    ELC_EVENT_GPT6_COUNTER_UNDERFLOW        = (0xF3),     ///< GTCNT underflow
    ELC_EVENT_GPT6_AD_TRIG_A                = (0xF4),     ///< GTADTRA compare match
    ELC_EVENT_GPT6_AD_TRIG_B                = (0xF5),     ///< GTADTRB compare match
    ELC_EVENT_GPT7_CAPTURE_COMPARE_INT_A    = (0xF6),     ///< GTCCRA input capture/compare match
    ELC_EVENT_GPT7_CAPTURE_COMPARE_INT_B    = (0xF7),     ///< GTCCRB input capture/compare match
    ELC_EVENT_GPT7_COMPARE_INT_C            = (0xF8),     ///< GTCCRC compare match
    ELC_EVENT_GPT7_COMPARE_INT_D            = (0xF9),     ///< GTCCRD compare match
    ELC_EVENT_GPT7_COMPARE_INT_E            = (0xFA),     ///< GTCCRE compare match
    ELC_EVENT_GPT7_COMPARE_INT_F            = (0xFB),     ///< GTCCRF compare match
    ELC_EVENT_GPT7_COUNTER_OVERFLOW         = (0xFC),     ///< GTCNT overflow
    ELC_EVENT_GPT7_COUNTER_UNDERFLOW        = (0xFD),     ///< GTCNT underflow
    ELC_EVENT_GPT7_AD_TRIG_A                = (0xFE),     ///< GTADTRA compare match
    ELC_EVENT_GPT7_AD_TRIG_B                = (0xFF),     ///< GTADTRB compare match
    ELC_EVENT_GPT8_CAPTURE_COMPARE_INT_A    = (0x100),    ///< GTCCRA input capture/compare match
    ELC_EVENT_GPT8_CAPTURE_COMPARE_INT_B    = (0x101),    ///< GTCCRB input capture/compare match
    ELC_EVENT_GPT8_COMPARE_INT_C            = (0x102),    ///< GTCCRC compare match
    ELC_EVENT_GPT8_COMPARE_INT_D            = (0x103),    ///< GTCCRD compare match
    ELC_EVENT_GPT8_COMPARE_INT_E            = (0x104),    ///< GTCCRE compare match
    ELC_EVENT_GPT8_COMPARE_INT_F            = (0x105),    ///< GTCCRF compare match
    ELC_EVENT_GPT8_COUNTER_OVERFLOW         = (0x106),    ///< GTCNT overflow
    ELC_EVENT_GPT8_COUNTER_UNDERFLOW        = (0x107),    ///< GTCNT underflow
    ELC_EVENT_GPT8_AD_TRIG_A                = (0x108),    ///< GTADTRA compare match
    ELC_EVENT_GPT8_AD_TRIG_B                = (0x109),    ///< GTADTRB compare match
    ELC_EVENT_GPT9_CAPTURE_COMPARE_INT_A    = (0x10A),    ///< GTCCRA input capture/compare match
    ELC_EVENT_GPT9_CAPTURE_COMPARE_INT_B    = (0x10B),    ///< GTCCRB input capture/compare match
    ELC_EVENT_GPT9_COMPARE_INT_C            = (0x10C),    ///< GTCCRC compare match
    ELC_EVENT_GPT9_COMPARE_INT_D            = (0x10D),    ///< GTCCRD compare match
    ELC_EVENT_GPT9_COMPARE_INT_E            = (0x10E),    ///< GTCCRE compare match
    ELC_EVENT_GPT9_COMPARE_INT_F            = (0x10F),    ///< GTCCRF compare match
    ELC_EVENT_GPT9_COUNTER_OVERFLOW         = (0x110),    ///< GTCNT overflow
    ELC_EVENT_GPT9_COUNTER_UNDERFLOW        = (0x111),    ///< GTCNT underflow
    ELC_EVENT_GPT9_AD_TRIG_A                = (0x112),    ///< GTADTRA compare match
    ELC_EVENT_GPT9_AD_TRIG_B                = (0x113),    ///< GTADTRB compare match
    ELC_EVENT_GPT10_CAPTURE_COMPARE_INT_A   = (0x114),    ///< GTCCRA input capture/compare match
    ELC_EVENT_GPT10_CAPTURE_COMPARE_INT_B   = (0x115),    ///< GTCCRB input capture/compare match
    ELC_EVENT_GPT10_COMPARE_INT_C           = (0x116),    ///< GTCCRC compare match
    ELC_EVENT_GPT10_COMPARE_INT_D           = (0x117),    ///< GTCCRD compare match
    ELC_EVENT_GPT10_COMPARE_INT_E           = (0x118),    ///< GTCCRE compare match
    ELC_EVENT_GPT10_COMPARE_INT_F           = (0x119),    ///< GTCCRF compare match
    ELC_EVENT_GPT10_COUNTER_OVERFLOW        = (0x11A),    ///< GTCNT overflow
    ELC_EVENT_GPT10_COUNTER_UNDERFLOW       = (0x11B),    ///< GTCNT underflow
    ELC_EVENT_GPT10_AD_TRIG_A               = (0x11C),    ///< GTADTRA compare match
    ELC_EVENT_GPT10_AD_TRIG_B               = (0x11D),    ///< GTADTRB compare match
    ELC_EVENT_GPT11_CAPTURE_COMPARE_INT_A   = (0x11E),    ///< GTCCRA input capture/compare match
    ELC_EVENT_GPT11_CAPTURE_COMPARE_INT_B   = (0x11F),    ///< GTCCRB input capture/compare match
    ELC_EVENT_GPT11_COMPARE_INT_C           = (0x120),    ///< GTCCRC compare match
    ELC_EVENT_GPT11_COMPARE_INT_D           = (0x121),    ///< GTCCRD compare match
    ELC_EVENT_GPT11_COMPARE_INT_E           = (0x122),    ///< GTCCRE compare match
    ELC_EVENT_GPT11_COMPARE_INT_F           = (0x123),    ///< GTCCRF compare match
    ELC_EVENT_GPT11_COUNTER_OVERFLOW        = (0x124),    ///< GTCNT overflow
    ELC_EVENT_GPT11_COUNTER_UNDERFLOW       = (0x125),    ///< GTCNT underflow
    ELC_EVENT_GPT11_AD_TRIG_A               = (0x126),    ///< GTADTRA compare match
    ELC_EVENT_GPT11_AD_TRIG_B               = (0x127),    ///< GTADTRB compare match
    ELC_EVENT_GPT12_CAPTURE_COMPARE_INT_A   = (0x128),    ///< GTCCRA input capture/compare match
    ELC_EVENT_GPT12_CAPTURE_COMPARE_INT_B   = (0x129),    ///< GTCCRB input capture/compare match
    ELC_EVENT_GPT12_COMPARE_INT_C           = (0x12A),    ///< GTCCRC compare match
    ELC_EVENT_GPT12_COMPARE_INT_D           = (0x12B),    ///< GTCCRD compare match
    ELC_EVENT_GPT12_COMPARE_INT_E           = (0x12C),    ///< GTCCRE compare match
    ELC_EVENT_GPT12_COMPARE_INT_F           = (0x12D),    ///< GTCCRF compare match
    ELC_EVENT_GPT12_COUNTER_OVERFLOW        = (0x12E),    ///< GTCNT overflow
    ELC_EVENT_GPT12_COUNTER_UNDERFLOW       = (0x12F),    ///< GTCNT underflow
    ELC_EVENT_GPT12_AD_TRIG_A               = (0x130),    ///< GTADTRA compare match
    ELC_EVENT_GPT12_AD_TRIG_B               = (0x131),    ///< GTADTRB compare match
    ELC_EVENT_GPT13_CAPTURE_COMPARE_INT_A   = (0x132),    ///< GTCCRA input capture/compare match
    ELC_EVENT_GPT13_CAPTURE_COMPARE_INT_B   = (0x133),    ///< GTCCRB input capture/compare match
    ELC_EVENT_GPT13_COMPARE_INT_C           = (0x134),    ///< GTCCRC compare match
    ELC_EVENT_GPT13_COMPARE_INT_D           = (0x135),    ///< GTCCRD compare match
    ELC_EVENT_GPT13_COMPARE_INT_E           = (0x136),    ///< GTCCRE compare match
    ELC_EVENT_GPT13_COMPARE_INT_F           = (0x137),    ///< GTCCRF compare match
    ELC_EVENT_GPT13_COUNTER_OVERFLOW        = (0x138),    ///< GTCNT overflow
    ELC_EVENT_GPT13_COUNTER_UNDERFLOW       = (0x139),    ///< GTCNT underflow
    ELC_EVENT_GPT13_AD_TRIG_A               = (0x13A),    ///< GTADTRA compare match
    ELC_EVENT_GPT13_AD_TRIG_B               = (0x13B),    ///< GTADTRB compare match
    ELC_EVENT_GPT14_CAPTURE_COMPARE_INT_A   = (0x13C),    ///< GPT14_CAPTURE_COMPARE_INT_A
    ELC_EVENT_GPT14_CAPTURE_COMPARE_INT_B   = (0x13D),    ///< GPT14_CAPTURE_COMPARE_INT_B
    ELC_EVENT_GPT14_COMPARE_INT_C           = (0x13E),    ///< GPT14_COMPARE_INT_C
    ELC_EVENT_GPT14_COMPARE_INT_D           = (0x13F),    ///< GPT14_COMPARE_INT_D
    ELC_EVENT_GPT14_COMPARE_INT_E           = (0x140),    ///< GPT14_COMPARE_INT_E
    ELC_EVENT_GPT14_COMPARE_INT_F           = (0x141),    ///< GPT14_COMPARE_INT_F
    ELC_EVENT_GPT14_COUNTER_OVERFLOW        = (0x142),    ///< GPT14_COUNTER_OVERFLOW
    ELC_EVENT_GPT14_COUNTER_UNDERFLOW       = (0x143),    ///< GPT14_COUNTER_UNDERFLOW
    ELC_EVENT_GPT14_AD_TRIG_A               = (0x144),    ///< GPT14_AD_TRIG_A
    ELC_EVENT_GPT14_AD_TRIG_B               = (0x145),    ///< GPT14_AD_TRIG_B
    ELC_EVENT_GPT15_CAPTURE_COMPARE_INT_A   = (0x146),    ///< GPT15_CAPTURE_COMPARE_INT_A
    ELC_EVENT_GPT15_CAPTURE_COMPARE_INT_B   = (0x147),    ///< GPT15_CAPTURE_COMPARE_INT_B
    ELC_EVENT_GPT15_COMPARE_INT_C           = (0x148),    ///< GPT15_COMPARE_INT_C
    ELC_EVENT_GPT15_COMPARE_INT_D           = (0x149),    ///< GPT15_COMPARE_INT_D
    ELC_EVENT_GPT15_COMPARE_INT_E           = (0x14A),    ///< GPT15_COMPARE_INT_E
    ELC_EVENT_GPT15_COMPARE_INT_F           = (0x14B),    ///< GPT15_COMPARE_INT_F
    ELC_EVENT_GPT15_COUNTER_OVERFLOW        = (0x14C),    ///< GPT15_COUNTER_OVERFLOW
    ELC_EVENT_GPT15_COUNTER_UNDERFLOW       = (0x14D),    ///< GPT15_COUNTER_UNDERFLOW
    ELC_EVENT_GPT15_AD_TRIG_A               = (0x14E),    ///< GPT15_AD_TRIG_A
    ELC_EVENT_GPT15_AD_TRIG_B               = (0x14F),    ///< GPT15_AD_TRIG_B
    ELC_EVENT_GPT_UVW_EDGE                  = (0x150),    ///< UVW edge event
    ELC_EVENT_ETHER_IPLS                    = (0x160),    ///< ETHER_IPLS
    ELC_EVENT_ETHER_MINT                    = (0x161),    ///< ETHER_MINT
    ELC_EVENT_ETHER_PINT                    = (0x162),    ///< ETHER_PINT
    ELC_EVENT_ETHER_EINT0                   = (0x163),    ///< ETHER_EINT0
    ELC_EVENT_ETHER_EINT1                   = (0x164),    ///< ETHER_EINT1
    ELC_EVENT_ETHER_ETHER0_RISE             = (0x165),    ///< Pulse output timer 0 rising edge detection
    ELC_EVENT_ETHER_ETHER1_RISE             = (0x166),    ///< Pulse output timer 1 rising edge detection
    ELC_EVENT_ETHER_ETHER2_RISE             = (0x167),    ///< Pulse output timer 2 rising edge detection
    ELC_EVENT_ETHER_ETHER3_RISE             = (0x168),    ///< Pulse output timer 3 rising edge detection
    ELC_EVENT_ETHER_ETHER4_RISE             = (0x169),    ///< Pulse output timer 4 rising edge detection
    ELC_EVENT_ETHER_ETHER5_RISE             = (0x16A),    ///< Pulse output timer 5 rising edge detection
    ELC_EVENT_ETHER_ETHER0_FALL             = (0x16B),    ///< Pulse output timer 0 falling edge detection
    ELC_EVENT_ETHER_ETHER1_FALL             = (0x16C),    ///< Pulse output timer 1 falling edge detection
    ELC_EVENT_ETHER_ETHER2_FALL             = (0x16D),    ///< Pulse output timer 2 falling edge detection
    ELC_EVENT_ETHER_ETHER3_FALL             = (0x16E),    ///< Pulse output timer 3 falling edge detection
    ELC_EVENT_ETHER_ETHER4_FALL             = (0x16F),    ///< Pulse output timer 4 falling edge detection
    ELC_EVENT_ETHER_ETHER5_FALL             = (0x170),    ///< Pulse output timer 5 falling edge detection
    ELC_EVENT_USBHS_D0FIFO                  = (0x171),    ///< USBHS_D0FIFO
    ELC_EVENT_USBHS_D1FIFO                  = (0x172),    ///< USBHS_D1FIFO
    ELC_EVENT_USBHS_USBIR                   = (0x173),    ///< USBHS_USBIR
    ELC_EVENT_SCI0_RXI                      = (0x174),    ///< Receive data full interrupt
    ELC_EVENT_SCI0_TXI                      = (0x175),    ///< Transmit data empty interrupt
    ELC_EVENT_SCI0_TEI                      = (0x176),    ///< Transmit end interrupt
    ELC_EVENT_SCI0_ERI                      = (0x177),    ///< Receive error interrupt
    ELC_EVENT_SCI0_AM                       = (0x178),    ///< Address match event
    ELC_EVENT_SCI0_RXI_OR_ERI               = (0x179),    ///< SCI0_RXI_OR_ERI
    ELC_EVENT_SCI1_RXI                      = (0x17A),    ///< Receive data full interrupt
    ELC_EVENT_SCI1_TXI                      = (0x17B),    ///< Transmit data empty interrupt
    ELC_EVENT_SCI1_TEI                      = (0x17C),    ///< Transmit end interrupt
    ELC_EVENT_SCI1_ERI                      = (0x17D),    ///< Receive error interrupt
    ELC_EVENT_SCI1_AM                       = (0x17E),    ///< Address match event
    ELC_EVENT_SCI2_RXI                      = (0x180),    ///< Receive data full interrupt
    ELC_EVENT_SCI2_TXI                      = (0x181),    ///< Transmit data empty interrupt
    ELC_EVENT_SCI2_TEI                      = (0x182),    ///< Transmit end interrupt
    ELC_EVENT_SCI2_ERI                      = (0x183),    ///< Receive error interrupt
    ELC_EVENT_SCI2_AM                       = (0x184),    ///< Address match event
    ELC_EVENT_SCI3_RXI                      = (0x186),    ///< Receive data full interrupt
    ELC_EVENT_SCI3_TXI                      = (0x187),    ///< Transmit data empty interrupt
    ELC_EVENT_SCI3_TEI                      = (0x188),    ///< Transmit end interrupt
    ELC_EVENT_SCI3_ERI                      = (0x189),    ///< Receive error interrupt
    ELC_EVENT_SCI3_AM                       = (0x18A),    ///< Address match event
    ELC_EVENT_SCI4_RXI                      = (0x18C),    ///< Receive data full interrupt
    ELC_EVENT_SCI4_TXI                      = (0x18D),    ///< Transmit data empty interrupt
    ELC_EVENT_SCI4_TEI                      = (0x18E),    ///< Transmit end interrupt
    ELC_EVENT_SCI4_ERI                      = (0x18F),    ///< Receive error interrupt
    ELC_EVENT_SCI4_AM                       = (0x190),    ///< Address match event
    ELC_EVENT_SCI5_RXI                      = (0x192),    ///< Receive data full interrupt
    ELC_EVENT_SCI5_TXI                      = (0x193),    ///< Transmit data empty interrupt
    ELC_EVENT_SCI5_TEI                      = (0x194),    ///< Transmit end interrupt
    ELC_EVENT_SCI5_ERI                      = (0x195),    ///< Receive error interrupt
    ELC_EVENT_SCI5_AM                       = (0x196),    ///< Address match event
    ELC_EVENT_SCI6_RXI                      = (0x198),    ///< Receive data full interrupt
    ELC_EVENT_SCI6_TXI                      = (0x199),    ///< Transmit data empty interrupt
    ELC_EVENT_SCI6_TEI                      = (0x19A),    ///< Transmit end interrupt
    ELC_EVENT_SCI6_ERI                      = (0x19B),    ///< Receive error interrupt
    ELC_EVENT_SCI6_AM                       = (0x19C),    ///< Address match event
    ELC_EVENT_SCI7_RXI                      = (0x19E),    ///< Receive data full interrupt
    ELC_EVENT_SCI7_TXI                      = (0x19F),    ///< Transmit data empty interrupt
    ELC_EVENT_SCI7_TEI                      = (0x1A0),    ///< Transmit end interrupt
    ELC_EVENT_SCI7_ERI                      = (0x1A1),    ///< Receive error interrupt
    ELC_EVENT_SCI7_AM                       = (0x1A2),    ///< Address match event
    ELC_EVENT_SCI8_RXI                      = (0x1A4),    ///< Receive data full interrupt
    ELC_EVENT_SCI8_TXI                      = (0x1A5),    ///< Transmit data empty interrupt
    ELC_EVENT_SCI8_TEI                      = (0x1A6),    ///< Transmit end interrupt
    ELC_EVENT_SCI8_ERI                      = (0x1A7),    ///< Receive error interrupt
    ELC_EVENT_SCI8_AM                       = (0x1A8),    ///< Address match event
    ELC_EVENT_SCI9_RXI                      = (0x1AA),    ///< Receive data full interrupt
    ELC_EVENT_SCI9_TXI                      = (0x1AB),    ///< Transmit data empty interrupt
    ELC_EVENT_SCI9_TEI                      = (0x1AC),    ///< Transmit end interrupt
    ELC_EVENT_SCI9_ERI                      = (0x1AD),    ///< Receive error interrupt
    ELC_EVENT_SCI9_AM                       = (0x1AE),    ///< Address match event
    ELC_EVENT_RSPI0_SPRI                    = (0x1BC),    ///< Receive buffer full interrupt
    ELC_EVENT_RSPI0_SPTI                    = (0x1BD),    ///< Transmit buffer empty interrupt
    ELC_EVENT_RSPI0_SPII                    = (0x1BE),    ///< Idle interrupt
    ELC_EVENT_RSPI0_SPEI                    = (0x1BF),    ///< Error interrupt
    ELC_EVENT_RSPI0_SP_ELCTEND              = (0x1C0),    ///< Transmission completed event
    ELC_EVENT_RSPI1_SPRI                    = (0x1C1),    ///< Receive buffer full interrupt
    ELC_EVENT_RSPI1_SPTI                    = (0x1C2),    ///< Transmit buffer empty interrupt
    ELC_EVENT_RSPI1_SPII                    = (0x1C3),    ///< Idle interrupt
    ELC_EVENT_RSPI1_SPEI                    = (0x1C4),    ///< Error interrupt
    ELC_EVENT_RSPI1_SP_ELCTEND              = (0x1C5),    ///< Transmission completed event
    ELC_EVENT_QSPI_INTR                     = (0x1C6),    ///< QSPI_INTR
    ELC_EVENT_SDHI_MMC0_ACCS                = (0x1C7),    ///< SDHI_MMC0_ACCS
    ELC_EVENT_SDHI_MMC0_SDIO                = (0x1C8),    ///< SDHI_MMC0_SDIO
    ELC_EVENT_SDHI_MMC0_CARD                = (0x1C9),    ///< SDHI_MMC0_CARD
    ELC_EVENT_SDHI_MMC0_ODMSDBREQ           = (0x1CA),    ///< SDHI_MMC0_ODMSDBREQ
    ELC_EVENT_SDHI_MMC1_ACCS                = (0x1CB),    ///< SDHI_MMC1_ACCS
    ELC_EVENT_SDHI_MMC1_SDIO                = (0x1CC),    ///< SDHI_MMC1_SDIO
    ELC_EVENT_SDHI_MMC1_CARD                = (0x1CD),    ///< SDHI_MMC1_CARD
    ELC_EVENT_SDHI_MMC1_ODMSDBREQ           = (0x1CE),    ///< SDHI_MMC1_ODMSDBREQ
    ELC_EVENT_EXT_DIVIDER_INTMD             = (0x1CF),    ///< EXT_DIVIDER_INTMD
    ELC_EVENT_TSIP_PROC_BUSY_N              = (0x1E1),    ///< TSIP_PROC_BUSY_N
    ELC_EVENT_TSIP_ROMOK_N                  = (0x1E2),    ///< TSIP_ROMOK_N
    ELC_EVENT_TSIP_LONG_PLG_N               = (0x1E3),    ///< TSIP_LONG_PLG_N
    ELC_EVENT_TSIP_TEST_BUSY_N              = (0x1E4),    ///< TSIP_TEST_BUSY_N
    ELC_EVENT_TSIP_WRRDY_0_N                = (0x1E5),    ///< TSIP_WRRDY_0_N
    ELC_EVENT_TSIP_WRRDY_1_N                = (0x1E6),    ///< TSIP_WRRDY_1_N
    ELC_EVENT_TSIP_WRRDY_4_N                = (0x1E7),    ///< TSIP_WRRDY_4_N
    ELC_EVENT_TSIP_RDRDY_0_N                = (0x1E8),    ///< TSIP_RDRDY_0_N
    ELC_EVENT_TSIP_RDRDY_1_N                = (0x1E9),    ///< TSIP_RDRDY_1_N
    ELC_EVENT_TSIP_INTEGRATE_WRRDY_N        = (0x1EA),    ///< TSIP_INTEGRATE_WRRDY_N
    ELC_EVENT_TSIP_INTEGRATE_RDRDY_N        = (0x1EB),    ///< TSIP_INTEGRATE_RDRDY_N
    ELC_EVENT_LCDC_LCDC_LEVEL_0             = (0x1FA),    ///< LCDC_LCDC_LEVEL_0
    ELC_EVENT_LCDC_LCDC_LEVEL_1             = (0x1FB),    ///< LCDC_LCDC_LEVEL_1
    ELC_EVENT_LCDC_LCDC_LEVEL_2             = (0x1FC),    ///< LCDC_LCDC_LEVEL_2
    ELC_EVENT_TWOD_ENGINE_IRQ               = (0x1FD),    ///< TWOD_ENGINE_IRQ
    ELC_EVENT_JPEG_JEDI                     = (0x1FE),    ///< JPEG_JEDI
    ELC_EVENT_JPEG_JDTI                     = (0x1FF),    ///< JPEG_JDTI
} elc_event_t;

/** Individual event link */
typedef struct st_elc_link
{
    elc_peripheral_t  peripheral;     ///< Peripheral to receive the signal
    elc_event_t       event;          ///< Signal that gets sent to the Peripheral
} elc_link_t;

/** Main configuration structure for the Event Link Controller */
typedef struct st_elc_cfg
{
    bool                autostart;   ///< Start operation and enable interrupts during open().
    uint32_t            link_count;  ///< Number of event links
    elc_link_t const  * link_list;   ///< Event links
} elc_cfg_t;

/** Software event number */
typedef enum e_elc_software_event
{
    ELC_SOFTWARE_EVENT_0,       ///< Software event 0
    ELC_SOFTWARE_EVENT_1,       ///< Software event 1
} elc_software_event_t;

/** ELC driver structure. General ELC functions implemented at the HAL layer follow this API. */
typedef struct st_elc_api
{
    /** Initialize all links in the Event Link Controller.
     * @par Implemented as
     * - R_ELC_Init()
     *
     * @param[in]   p_cfg   Pointer to configuration structure.
     **/
    ssp_err_t (* init)(elc_cfg_t const * const p_cfg);

    /** Generate a software event in the Event Link Controller.
     * @par Implemented as
     * - R_ELC_SoftwareEventGenerate()
     *
     * @param[in]   eventNum           Software event number to be generated.
     **/
    ssp_err_t (* softwareEventGenerate)(elc_software_event_t event_num);

    /** Create a single event link.
     * @par Implemented as
     * - R_ELC_LinkSet()
     *
     * @param[in]   peripheral The peripheral block that will receive the event signal.
     * @param[in]   signal     The event signal.
     **/
    ssp_err_t (* linkSet)(elc_peripheral_t peripheral, elc_event_t signal);

    /** Break an event link.
     * @par Implemented as
     * - R_ELC_LinkBreak()
     *
     * @param[in]   peripheral   The peripheral that should no longer be linked.
     **/
    ssp_err_t (* linkBreak)(elc_peripheral_t peripheral);

    /** Enable the operation of the Event Link Controller.
     * @par Implemented as
     * - R_ELC_Enable()
     **/
    ssp_err_t (* enable)(void);

    /** Disable the operation of the Event Link Controller.
     * @par Implemented as
     * - R_ELC_Disable()
     **/
    ssp_err_t (* disable)(void);

    /** Get the driver version based on compile time macros.
     * @par Implemented as
     * - R_ELC_VersionGet()
     *
     * @param[out]  p_version is value returned.
     **/
    ssp_err_t (* versionGet)(ssp_version_t * const p_version);
} elc_api_t;

/** This structure encompasses everything that is needed to use an instance of this interface. */
typedef struct st_elc_instance
{
    elc_cfg_t const * p_cfg;     ///< Pointer to the configuration structure for this instance
    elc_api_t const * p_api;     ///< Pointer to the API structure for this instance
} elc_instance_t;

#endif /* DRV_ELC_API_H */

/*******************************************************************************************************************//**
 * @} (end addtogroup ELC_API)
 **********************************************************************************************************************/
