/***********************************************************************************************************************
 * Copyright [2015] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
 * display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
 * purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
 * SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
 * NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
 * OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
 * be subject to different terms.
 **********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : bsp_irq_cfg_ref.h
* Description  : This configuration header file determines which ELC events are mapped to trigger interrupts in the
*                NVIC.
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 24.04.2015 0.10     First Release
***********************************************************************************************************************/
/*******************************************************************************************************************//**
 * @file
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @ingroup BSP_CONFIG_DK2M
 * @defgroup BSP_CONFIG_DK2M_INTERRUPTS Build Time Configurations - Interrupts
 *
 * Each ELC event that can be configured to trigger an interrupt is listed below. If the user wishes for a particular
 * event to trigger an interrupt then they will need to change the macro's definition from BSP IRQ DISABLED to
 * the interrupt priority level they wish to use for the interrupt. The valid priority range for this MCU is
 * 0 to 15 with lower numbers having a higher priority (0 = max priority, 15 = min priority).
 * The BSP will take care of putting the proper function in the vector table, will set the interrupt priority level,
 * and will configure the ELC event to generate an interrupt after reset and before the user's application is called.
 *
 * @{
***********************************************************************************************************************/

#ifndef BSP_IRQ_CFG_REF_H_
#define BSP_IRQ_CFG_REF_H_

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define BSP_IRQ_CFG_PORT0_IRQ                          (BSP_IRQ_DISABLED) ///< PORT0 IRQ
#define BSP_IRQ_CFG_PORT1_IRQ                          (BSP_IRQ_DISABLED) ///< PORT1 IRQ
#define BSP_IRQ_CFG_PORT2_IRQ                          (BSP_IRQ_DISABLED) ///< PORT2 IRQ
#define BSP_IRQ_CFG_PORT3_IRQ                          (BSP_IRQ_DISABLED) ///< PORT3 IRQ
#define BSP_IRQ_CFG_PORT4_IRQ                          (BSP_IRQ_DISABLED) ///< PORT4 IRQ
#define BSP_IRQ_CFG_PORT5_IRQ                          (BSP_IRQ_DISABLED) ///< PORT5 IRQ
#define BSP_IRQ_CFG_PORT6_IRQ                          (BSP_IRQ_DISABLED) ///< PORT6 IRQ
#define BSP_IRQ_CFG_PORT7_IRQ                          (BSP_IRQ_DISABLED) ///< PORT7 IRQ
#define BSP_IRQ_CFG_PORT8_IRQ                          (BSP_IRQ_DISABLED) ///< PORT8 IRQ
#define BSP_IRQ_CFG_PORT9_IRQ                          (BSP_IRQ_DISABLED) ///< PORT9 IRQ
#define BSP_IRQ_CFG_PORT10_IRQ                         (BSP_IRQ_DISABLED) ///< PORT10 IRQ
#define BSP_IRQ_CFG_PORT11_IRQ                         (BSP_IRQ_DISABLED) ///< PORT11 IRQ
#define BSP_IRQ_CFG_PORT12_IRQ                         (BSP_IRQ_DISABLED) ///< PORT12 IRQ
#define BSP_IRQ_CFG_PORT13_IRQ                         (BSP_IRQ_DISABLED) ///< PORT13 IRQ
#define BSP_IRQ_CFG_PORT14_IRQ                         (BSP_IRQ_DISABLED) ///< PORT14 IRQ
#define BSP_IRQ_CFG_PORT15_IRQ                         (BSP_IRQ_DISABLED) ///< PORT15 IRQ
#define BSP_IRQ_CFG_DMAC0_DMAC                         (BSP_IRQ_DISABLED) ///< DMAC0 DMAC
#define BSP_IRQ_CFG_DMAC1_DMAC                         (BSP_IRQ_DISABLED) ///< DMAC1 DMAC
#define BSP_IRQ_CFG_DMAC2_DMAC                         (BSP_IRQ_DISABLED) ///< DMAC2 DMAC
#define BSP_IRQ_CFG_DMAC3_DMAC                         (BSP_IRQ_DISABLED) ///< DMAC3 DMAC
#define BSP_IRQ_CFG_DMAC4_DMAC                         (BSP_IRQ_DISABLED) ///< DMAC4 DMAC
#define BSP_IRQ_CFG_DMAC5_DMAC                         (BSP_IRQ_DISABLED) ///< DMAC5 DMAC
#define BSP_IRQ_CFG_DMAC6_DMAC                         (BSP_IRQ_DISABLED) ///< DMAC6 DMAC
#define BSP_IRQ_CFG_DMAC7_DMAC                         (BSP_IRQ_DISABLED) ///< DMAC7 DMAC
#define BSP_IRQ_CFG_DTC_TRANSFER                       (BSP_IRQ_DISABLED) ///< DTC TRANSFER
#define BSP_IRQ_CFG_DTC_COMPLETE                       (BSP_IRQ_DISABLED) ///< DTC COMPLETE
#define BSP_IRQ_CFG_DTC_DTC_END                        (BSP_IRQ_DISABLED) ///< DTC DTC END
#define BSP_IRQ_CFG_EXDMAC0_EXDMAC                     (BSP_IRQ_DISABLED) ///< EXDMAC0 EXDMAC
#define BSP_IRQ_CFG_EXDMAC1_EXDMAC                     (BSP_IRQ_DISABLED) ///< EXDMAC1 EXDMAC
#define BSP_IRQ_CFG_ICU_CANCELING_SNOOZE_MODE          (BSP_IRQ_DISABLED) ///< ICU CANCELING SNOOZE MODE
#define BSP_IRQ_CFG_FCU_FIFERR                         (BSP_IRQ_DISABLED) ///< FCU FIFERR
#define BSP_IRQ_CFG_FCU_FRDYI                          (BSP_IRQ_DISABLED) ///< FCU FRDYI
#define BSP_IRQ_CFG_FCU_ECCERR                         (BSP_IRQ_DISABLED) ///< FCU ECCERR
#define BSP_IRQ_CFG_LVD1_LVD1                          (BSP_IRQ_DISABLED) ///< LVD1 LVD1
#define BSP_IRQ_CFG_LVD2_LVD2                          (BSP_IRQ_DISABLED) ///< LVD2 LVD2
#define BSP_IRQ_CFG_VBATT_VBAT                         (BSP_IRQ_DISABLED) ///< VBATT VBAT
#define BSP_IRQ_CFG_MOSC_OSC_STOP                      (BSP_IRQ_DISABLED) ///< MOSC OSC STOP
#define BSP_IRQ_CFG_CPUSYS_SNOOZE_MODE_ENTRY_FLAG      (BSP_IRQ_DISABLED) ///< CPUSYS SNOOZE MODE ENTRY FLAG
#define BSP_IRQ_CFG_AGT0_AGTI                          (BSP_IRQ_DISABLED) ///< AGT0 AGTI
#define BSP_IRQ_CFG_AGT0_AGTCMAI                       (BSP_IRQ_DISABLED) ///< AGT0 AGTCMAI
#define BSP_IRQ_CFG_AGT0_AGTCMBI                       (BSP_IRQ_DISABLED) ///< AGT0 AGTCMBI
#define BSP_IRQ_CFG_AGT1_AGTI                          (BSP_IRQ_DISABLED) ///< AGT1 AGTI
#define BSP_IRQ_CFG_AGT1_AGTCMAI                       (BSP_IRQ_DISABLED) ///< AGT1 AGTCMAI
#define BSP_IRQ_CFG_AGT1_AGTCMBI                       (BSP_IRQ_DISABLED) ///< AGT1 AGTCMBI
#define BSP_IRQ_CFG_IWDT_NMIUNDF_N                     (BSP_IRQ_DISABLED) ///< IWDT NMIUNDF N
#define BSP_IRQ_CFG_CWDT_NMIUNDF_N                     (BSP_IRQ_DISABLED) ///< CWDT NMIUNDF N
#define BSP_IRQ_CFG_RTC_ALM                            (BSP_IRQ_DISABLED) ///< RTC ALM
#define BSP_IRQ_CFG_RTC_PRD                            (BSP_IRQ_DISABLED) ///< RTC PRD
#define BSP_IRQ_CFG_RTC_CUP                            (BSP_IRQ_DISABLED) ///< RTC CUP
#define BSP_IRQ_CFG_S12AD0_ADI                         (BSP_IRQ_DISABLED) ///< S12AD0 ADI
#define BSP_IRQ_CFG_S12AD0_GBADI                       (BSP_IRQ_DISABLED) ///< S12AD0 GBADI
#define BSP_IRQ_CFG_S12AD0_CMPAI                       (BSP_IRQ_DISABLED) ///< S12AD0 CMPAI
#define BSP_IRQ_CFG_S12AD0_CMPBI                       (BSP_IRQ_DISABLED) ///< S12AD0 CMPBI
#define BSP_IRQ_CFG_S12AD0_COMPARE_MATCH               (BSP_IRQ_DISABLED) ///< S12AD0 COMPARE MATCH
#define BSP_IRQ_CFG_S12AD0_COMPARE_MISMATCH            (BSP_IRQ_DISABLED) ///< S12AD0 COMPARE MISMATCH
#define BSP_IRQ_CFG_S12AD1_ADI                         (BSP_IRQ_DISABLED) ///< S12AD1 ADI
#define BSP_IRQ_CFG_S12AD1_GBADI                       (BSP_IRQ_DISABLED) ///< S12AD1 GBADI
#define BSP_IRQ_CFG_S12AD1_CMPAI                       (BSP_IRQ_DISABLED) ///< S12AD1 CMPAI
#define BSP_IRQ_CFG_S12AD1_CMPBI                       (BSP_IRQ_DISABLED) ///< S12AD1 CMPBI
#define BSP_IRQ_CFG_S12AD1_COMPARE_MATCH               (BSP_IRQ_DISABLED) ///< S12AD1 COMPARE MATCH
#define BSP_IRQ_CFG_S12AD1_COMPARE_MISMATCH            (BSP_IRQ_DISABLED) ///< S12AD1 COMPARE MISMATCH
#define BSP_IRQ_CFG_COMP_OC0_COMP_IRQ                  (BSP_IRQ_DISABLED) ///< COMP OC0 COMP IRQ
#define BSP_IRQ_CFG_COMP_RD1_COMP_IRQ                  (BSP_IRQ_DISABLED) ///< COMP RD1 COMP IRQ
#define BSP_IRQ_CFG_COMP_RD2_COMP_IRQ                  (BSP_IRQ_DISABLED) ///< COMP RD2 COMP IRQ
#define BSP_IRQ_CFG_COMP_RD3_COMP_IRQ                  (BSP_IRQ_DISABLED) ///< COMP RD3 COMP IRQ
#define BSP_IRQ_CFG_COMP_RD4_COMP_IRQ                  (BSP_IRQ_DISABLED) ///< COMP RD4 COMP IRQ
#define BSP_IRQ_CFG_COMP_RD5_COMP_IRQ                  (BSP_IRQ_DISABLED) ///< COMP RD5 COMP IRQ
#define BSP_IRQ_CFG_COMP_LP_COMP_C0IRQ                 (BSP_IRQ_DISABLED) ///< COMP LP COMP C0IRQ
#define BSP_IRQ_CFG_COMP_LP_COMP_C1IRQ                 (BSP_IRQ_DISABLED) ///< COMP LP COMP C1IRQ
#define BSP_IRQ_CFG_USBFS_D0FIFO                       (BSP_IRQ_DISABLED) ///< USBFS D0FIFO
#define BSP_IRQ_CFG_USBFS_D1FIFO                       (BSP_IRQ_DISABLED) ///< USBFS D1FIFO
#define BSP_IRQ_CFG_USBFS_USBI                         (BSP_IRQ_DISABLED) ///< USBFS USBI
#define BSP_IRQ_CFG_USBFS_USBR                         (BSP_IRQ_DISABLED) ///< USBFS USBR
#define BSP_IRQ_CFG_RIIC0_RXI                          (BSP_IRQ_DISABLED) ///< RIIC0 RXI
#define BSP_IRQ_CFG_RIIC0_TXI                          (BSP_IRQ_DISABLED) ///< RIIC0 TXI
#define BSP_IRQ_CFG_RIIC0_TEI                          (BSP_IRQ_DISABLED) ///< RIIC0 TEI
#define BSP_IRQ_CFG_RIIC0_EEI                          (BSP_IRQ_DISABLED) ///< RIIC0 EEI0
#define BSP_IRQ_CFG_RIIC0_WUI                          (BSP_IRQ_DISABLED) ///< RIIC0 WUI
#define BSP_IRQ_CFG_RIIC1_RXI                          (BSP_IRQ_DISABLED) ///< RIIC1 RXI
#define BSP_IRQ_CFG_RIIC1_TXI                          (BSP_IRQ_DISABLED) ///< RIIC1 TXI
#define BSP_IRQ_CFG_RIIC1_TEI                          (BSP_IRQ_DISABLED) ///< RIIC1 TEI
#define BSP_IRQ_CFG_RIIC1_EEI                          (BSP_IRQ_DISABLED) ///< RIIC1 EEI0
#define BSP_IRQ_CFG_RIIC2_RXI                          (BSP_IRQ_DISABLED) ///< RIIC2 RXI
#define BSP_IRQ_CFG_RIIC2_TXI                          (BSP_IRQ_DISABLED) ///< RIIC2 TXI
#define BSP_IRQ_CFG_RIIC2_TEI                          (BSP_IRQ_DISABLED) ///< RIIC2 TEI
#define BSP_IRQ_CFG_RIIC2_EEI                          (BSP_IRQ_DISABLED) ///< RIIC2 EEI0
#define BSP_IRQ_CFG_SSI0_SSITXI                        (BSP_IRQ_DISABLED) ///< SSI0 SSITXI
#define BSP_IRQ_CFG_SSI0_SSIRXI                        (BSP_IRQ_DISABLED) ///< SSI0 SSIRXI
#define BSP_IRQ_CFG_SSI0_SSIRT                         (BSP_IRQ_DISABLED) ///< SSI0 SSIRT
#define BSP_IRQ_CFG_SSI0_SSIF                          (BSP_IRQ_DISABLED) ///< SSI0 SSIF
#define BSP_IRQ_CFG_SSI1_SSITXI                        (BSP_IRQ_DISABLED) ///< SSI1 SSITXI
#define BSP_IRQ_CFG_SSI1_SSIRXI                        (BSP_IRQ_DISABLED) ///< SSI1 SSIRXI
#define BSP_IRQ_CFG_SSI1_SSIRT                         (BSP_IRQ_DISABLED) ///< SSI1 SSIRT
#define BSP_IRQ_CFG_SSI1_SSIF                          (BSP_IRQ_DISABLED) ///< SSI1 SSIF
#define BSP_IRQ_CFG_SRC_IDEI                           (BSP_IRQ_DISABLED) ///< SRC IDEI
#define BSP_IRQ_CFG_SRC_ODFI                           (BSP_IRQ_DISABLED) ///< SRC ODFI
#define BSP_IRQ_CFG_SRC_OVF                            (BSP_IRQ_DISABLED) ///< SRC OVF
#define BSP_IRQ_CFG_SRC_UDF                            (BSP_IRQ_DISABLED) ///< SRC UDF
#define BSP_IRQ_CFG_SRC_CEF                            (BSP_IRQ_DISABLED) ///< SRC CEF
#define BSP_IRQ_CFG_PDC_PCDFI                          (BSP_IRQ_DISABLED) ///< PDC PCDFI
#define BSP_IRQ_CFG_PDC_PCFEI                          (BSP_IRQ_DISABLED) ///< PDC PCFEI
#define BSP_IRQ_CFG_PDC_PCERI                          (BSP_IRQ_DISABLED) ///< PDC PCERI
#define BSP_IRQ_CFG_CTSU_CTSUWR                        (BSP_IRQ_DISABLED) ///< CTSU CTSUWR
#define BSP_IRQ_CFG_CTSU_CTSURD                        (BSP_IRQ_DISABLED) ///< CTSU CTSURD
#define BSP_IRQ_CFG_CTSU_CTSUFN                        (BSP_IRQ_DISABLED) ///< CTSU CTSUFN
#define BSP_IRQ_CFG_KEY_INTKR                          (BSP_IRQ_DISABLED) ///< KEY INTKR
#define BSP_IRQ_CFG_DOC_DOPCF                          (BSP_IRQ_DISABLED) ///< DOC DOPCF
#define BSP_IRQ_CFG_CAC_FERRF                          (BSP_IRQ_DISABLED) ///< CAC FERRF
#define BSP_IRQ_CFG_CAC_MENDF                          (BSP_IRQ_DISABLED) ///< CAC MENDF
#define BSP_IRQ_CFG_CAC_OVFF                           (BSP_IRQ_DISABLED) ///< CAC OVFF
#define BSP_IRQ_CFG_RCAN20_ERS                         (BSP_IRQ_DISABLED) ///< RCAN20 ERS
#define BSP_IRQ_CFG_RCAN20_RXF                         (BSP_IRQ_DISABLED) ///< RCAN20 RXF
#define BSP_IRQ_CFG_RCAN20_TXF                         (BSP_IRQ_DISABLED) ///< RCAN20 TXF
#define BSP_IRQ_CFG_RCAN20_RXM                         (BSP_IRQ_DISABLED) ///< RCAN20 RXM
#define BSP_IRQ_CFG_RCAN20_TXM                         (BSP_IRQ_DISABLED) ///< RCAN20 TXM
#define BSP_IRQ_CFG_RCAN21_ERS                         (BSP_IRQ_DISABLED) ///< RCAN21 ERS
#define BSP_IRQ_CFG_RCAN21_RXF                         (BSP_IRQ_DISABLED) ///< RCAN21 RXF
#define BSP_IRQ_CFG_RCAN21_TXF                         (BSP_IRQ_DISABLED) ///< RCAN21 TXF
#define BSP_IRQ_CFG_RCAN21_RXM                         (BSP_IRQ_DISABLED) ///< RCAN21 RXM
#define BSP_IRQ_CFG_RCAN21_TXM                         (BSP_IRQ_DISABLED) ///< RCAN21 TXM
#define BSP_IRQ_CFG_GPIO_PORT_GROUP_A                  (BSP_IRQ_DISABLED) ///< GPIO PORT GROUP A
#define BSP_IRQ_CFG_GPIO_PORT_GROUP_B                  (BSP_IRQ_DISABLED) ///< GPIO PORT GROUP B
#define BSP_IRQ_CFG_GPIO_PORT_GROUP_C                  (BSP_IRQ_DISABLED) ///< GPIO PORT GROUP C
#define BSP_IRQ_CFG_GPIO_PORT_GROUP_D                  (BSP_IRQ_DISABLED) ///< GPIO PORT GROUP D
#define BSP_IRQ_CFG_ELC0_SOFTWARE_EVENT                (BSP_IRQ_DISABLED) ///< ELC0 SOFTWARE EVENT
#define BSP_IRQ_CFG_ELC1_SOFTWARE_EVENT                (BSP_IRQ_DISABLED) ///< ELC1 SOFTWARE EVENT
#define BSP_IRQ_CFG_POEG_GROUP_EVENT0                  (BSP_IRQ_DISABLED) ///< POEG GROUP EVENT0
#define BSP_IRQ_CFG_POEG_GROUP_EVENT1                  (BSP_IRQ_DISABLED) ///< POEG GROUP EVENT1
#define BSP_IRQ_CFG_POEG_GROUP_EVENT2                  (BSP_IRQ_DISABLED) ///< POEG GROUP EVENT2
#define BSP_IRQ_CFG_POEG_GROUP_EVENT3                  (BSP_IRQ_DISABLED) ///< POEG GROUP EVENT3
#define BSP_IRQ_CFG_GPT0_CAPTURE_COMPARE_INT_A         (BSP_IRQ_DISABLED) ///< GPT0 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT0_CAPTURE_COMPARE_INT_B         (BSP_IRQ_DISABLED) ///< GPT0 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT0_COMPARE_INT_C                 (BSP_IRQ_DISABLED) ///< GPT0 COMPARE INT C
#define BSP_IRQ_CFG_GPT0_COMPARE_INT_D                 (BSP_IRQ_DISABLED) ///< GPT0 COMPARE INT D
#define BSP_IRQ_CFG_GPT0_COMPARE_INT_E                 (BSP_IRQ_DISABLED) ///< GPT0 COMPARE INT E
#define BSP_IRQ_CFG_GPT0_COMPARE_INT_F                 (BSP_IRQ_DISABLED) ///< GPT0 COMPARE INT F
#define BSP_IRQ_CFG_GPT0_COUNTER_OVERFLOW              (BSP_IRQ_DISABLED) ///< GPT0 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT0_COUNTER_UNDERFLOW             (BSP_IRQ_DISABLED) ///< GPT0 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT0_AD_TRIG_A                     (BSP_IRQ_DISABLED) ///< GPT0 AD TRIG A
#define BSP_IRQ_CFG_GPT0_AD_TRIG_B                     (BSP_IRQ_DISABLED) ///< GPT0 AD TRIG B
#define BSP_IRQ_CFG_GPT1_CAPTURE_COMPARE_INT_A         (BSP_IRQ_DISABLED) ///< GPT1 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT1_CAPTURE_COMPARE_INT_B         (BSP_IRQ_DISABLED) ///< GPT1 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT1_COMPARE_INT_C                 (BSP_IRQ_DISABLED) ///< GPT1 COMPARE INT C
#define BSP_IRQ_CFG_GPT1_COMPARE_INT_D                 (BSP_IRQ_DISABLED) ///< GPT1 COMPARE INT D
#define BSP_IRQ_CFG_GPT1_COMPARE_INT_E                 (BSP_IRQ_DISABLED) ///< GPT1 COMPARE INT E
#define BSP_IRQ_CFG_GPT1_COMPARE_INT_F                 (BSP_IRQ_DISABLED) ///< GPT1 COMPARE INT F
#define BSP_IRQ_CFG_GPT1_COUNTER_OVERFLOW              (BSP_IRQ_DISABLED) ///< GPT1 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT1_COUNTER_UNDERFLOW             (BSP_IRQ_DISABLED) ///< GPT1 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT1_AD_TRIG_A                     (BSP_IRQ_DISABLED) ///< GPT1 AD TRIG A
#define BSP_IRQ_CFG_GPT1_AD_TRIG_B                     (BSP_IRQ_DISABLED) ///< GPT1 AD TRIG B
#define BSP_IRQ_CFG_GPT2_CAPTURE_COMPARE_INT_A         (BSP_IRQ_DISABLED) ///< GPT2 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT2_CAPTURE_COMPARE_INT_B         (BSP_IRQ_DISABLED) ///< GPT2 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT2_COMPARE_INT_C                 (BSP_IRQ_DISABLED) ///< GPT2 COMPARE INT C
#define BSP_IRQ_CFG_GPT2_COMPARE_INT_D                 (BSP_IRQ_DISABLED) ///< GPT2 COMPARE INT D
#define BSP_IRQ_CFG_GPT2_COMPARE_INT_E                 (BSP_IRQ_DISABLED) ///< GPT2 COMPARE INT E
#define BSP_IRQ_CFG_GPT2_COMPARE_INT_F                 (BSP_IRQ_DISABLED) ///< GPT2 COMPARE INT F
#define BSP_IRQ_CFG_GPT2_COUNTER_OVERFLOW              (BSP_IRQ_DISABLED) ///< GPT2 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT2_COUNTER_UNDERFLOW             (BSP_IRQ_DISABLED) ///< GPT2 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT2_AD_TRIG_A                     (BSP_IRQ_DISABLED) ///< GPT2 AD TRIG A
#define BSP_IRQ_CFG_GPT2_AD_TRIG_B                     (BSP_IRQ_DISABLED) ///< GPT2 AD TRIG B
#define BSP_IRQ_CFG_GPT3_CAPTURE_COMPARE_INT_A         (BSP_IRQ_DISABLED) ///< GPT3 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT3_CAPTURE_COMPARE_INT_B         (BSP_IRQ_DISABLED) ///< GPT3 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT3_COMPARE_INT_C                 (BSP_IRQ_DISABLED) ///< GPT3 COMPARE INT C
#define BSP_IRQ_CFG_GPT3_COMPARE_INT_D                 (BSP_IRQ_DISABLED) ///< GPT3 COMPARE INT D
#define BSP_IRQ_CFG_GPT3_COMPARE_INT_E                 (BSP_IRQ_DISABLED) ///< GPT3 COMPARE INT E
#define BSP_IRQ_CFG_GPT3_COMPARE_INT_F                 (BSP_IRQ_DISABLED) ///< GPT3 COMPARE INT F
#define BSP_IRQ_CFG_GPT3_COUNTER_OVERFLOW              (BSP_IRQ_DISABLED) ///< GPT3 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT3_COUNTER_UNDERFLOW             (BSP_IRQ_DISABLED) ///< GPT3 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT3_AD_TRIG_A                     (BSP_IRQ_DISABLED) ///< GPT3 AD TRIG A
#define BSP_IRQ_CFG_GPT3_AD_TRIG_B                     (BSP_IRQ_DISABLED) ///< GPT3 AD TRIG B
#define BSP_IRQ_CFG_GPT4_CAPTURE_COMPARE_INT_A         (BSP_IRQ_DISABLED) ///< GPT4 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT4_CAPTURE_COMPARE_INT_B         (BSP_IRQ_DISABLED) ///< GPT4 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT4_COMPARE_INT_C                 (BSP_IRQ_DISABLED) ///< GPT4 COMPARE INT C
#define BSP_IRQ_CFG_GPT4_COMPARE_INT_D                 (BSP_IRQ_DISABLED) ///< GPT4 COMPARE INT D
#define BSP_IRQ_CFG_GPT4_COMPARE_INT_E                 (BSP_IRQ_DISABLED) ///< GPT4 COMPARE INT E
#define BSP_IRQ_CFG_GPT4_COMPARE_INT_F                 (BSP_IRQ_DISABLED) ///< GPT4 COMPARE INT F
#define BSP_IRQ_CFG_GPT4_COUNTER_OVERFLOW              (BSP_IRQ_DISABLED) ///< GPT4 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT4_COUNTER_UNDERFLOW             (BSP_IRQ_DISABLED) ///< GPT4 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT4_AD_TRIG_A                     (BSP_IRQ_DISABLED) ///< GPT4 AD TRIG A
#define BSP_IRQ_CFG_GPT4_AD_TRIG_B                     (BSP_IRQ_DISABLED) ///< GPT4 AD TRIG B
#define BSP_IRQ_CFG_GPT5_CAPTURE_COMPARE_INT_A         (BSP_IRQ_DISABLED) ///< GPT5 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT5_CAPTURE_COMPARE_INT_B         (BSP_IRQ_DISABLED) ///< GPT5 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT5_COMPARE_INT_C                 (BSP_IRQ_DISABLED) ///< GPT5 COMPARE INT C
#define BSP_IRQ_CFG_GPT5_COMPARE_INT_D                 (BSP_IRQ_DISABLED) ///< GPT5 COMPARE INT D
#define BSP_IRQ_CFG_GPT5_COMPARE_INT_E                 (BSP_IRQ_DISABLED) ///< GPT5 COMPARE INT E
#define BSP_IRQ_CFG_GPT5_COMPARE_INT_F                 (BSP_IRQ_DISABLED) ///< GPT5 COMPARE INT F
#define BSP_IRQ_CFG_GPT5_COUNTER_OVERFLOW              (BSP_IRQ_DISABLED) ///< GPT5 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT5_COUNTER_UNDERFLOW             (BSP_IRQ_DISABLED) ///< GPT5 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT5_AD_TRIG_A                     (BSP_IRQ_DISABLED) ///< GPT5 AD TRIG A
#define BSP_IRQ_CFG_GPT5_AD_TRIG_B                     (BSP_IRQ_DISABLED) ///< GPT5 AD TRIG B
#define BSP_IRQ_CFG_GPT6_CAPTURE_COMPARE_INT_A         (BSP_IRQ_DISABLED) ///< GPT6 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT6_CAPTURE_COMPARE_INT_B         (BSP_IRQ_DISABLED) ///< GPT6 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT6_COMPARE_INT_C                 (BSP_IRQ_DISABLED) ///< GPT6 COMPARE INT C
#define BSP_IRQ_CFG_GPT6_COMPARE_INT_D                 (BSP_IRQ_DISABLED) ///< GPT6 COMPARE INT D
#define BSP_IRQ_CFG_GPT6_COMPARE_INT_E                 (BSP_IRQ_DISABLED) ///< GPT6 COMPARE INT E
#define BSP_IRQ_CFG_GPT6_COMPARE_INT_F                 (BSP_IRQ_DISABLED) ///< GPT6 COMPARE INT F
#define BSP_IRQ_CFG_GPT6_COUNTER_OVERFLOW              (BSP_IRQ_DISABLED) ///< GPT6 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT6_COUNTER_UNDERFLOW             (BSP_IRQ_DISABLED) ///< GPT6 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT6_AD_TRIG_A                     (BSP_IRQ_DISABLED) ///< GPT6 AD TRIG A
#define BSP_IRQ_CFG_GPT6_AD_TRIG_B                     (BSP_IRQ_DISABLED) ///< GPT6 AD TRIG B
#define BSP_IRQ_CFG_GPT7_CAPTURE_COMPARE_INT_A         (BSP_IRQ_DISABLED) ///< GPT7 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT7_CAPTURE_COMPARE_INT_B         (BSP_IRQ_DISABLED) ///< GPT7 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT7_COMPARE_INT_C                 (BSP_IRQ_DISABLED) ///< GPT7 COMPARE INT C
#define BSP_IRQ_CFG_GPT7_COMPARE_INT_D                 (BSP_IRQ_DISABLED) ///< GPT7 COMPARE INT D
#define BSP_IRQ_CFG_GPT7_COMPARE_INT_E                 (BSP_IRQ_DISABLED) ///< GPT7 COMPARE INT E
#define BSP_IRQ_CFG_GPT7_COMPARE_INT_F                 (BSP_IRQ_DISABLED) ///< GPT7 COMPARE INT F
#define BSP_IRQ_CFG_GPT7_COUNTER_OVERFLOW              (BSP_IRQ_DISABLED) ///< GPT7 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT7_COUNTER_UNDERFLOW             (BSP_IRQ_DISABLED) ///< GPT7 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT7_AD_TRIG_A                     (BSP_IRQ_DISABLED) ///< GPT7 AD TRIG A
#define BSP_IRQ_CFG_GPT7_AD_TRIG_B                     (BSP_IRQ_DISABLED) ///< GPT7 AD TRIG B
#define BSP_IRQ_CFG_GPT8_CAPTURE_COMPARE_INT_A         (BSP_IRQ_DISABLED) ///< GPT8 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT8_CAPTURE_COMPARE_INT_B         (BSP_IRQ_DISABLED) ///< GPT8 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT8_COMPARE_INT_C                 (BSP_IRQ_DISABLED) ///< GPT8 COMPARE INT C
#define BSP_IRQ_CFG_GPT8_COMPARE_INT_D                 (BSP_IRQ_DISABLED) ///< GPT8 COMPARE INT D
#define BSP_IRQ_CFG_GPT8_COMPARE_INT_E                 (BSP_IRQ_DISABLED) ///< GPT8 COMPARE INT E
#define BSP_IRQ_CFG_GPT8_COMPARE_INT_F                 (BSP_IRQ_DISABLED) ///< GPT8 COMPARE INT F
#define BSP_IRQ_CFG_GPT8_COUNTER_OVERFLOW              (BSP_IRQ_DISABLED) ///< GPT8 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT8_COUNTER_UNDERFLOW             (BSP_IRQ_DISABLED) ///< GPT8 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT8_AD_TRIG_A                     (BSP_IRQ_DISABLED) ///< GPT8 AD TRIG A
#define BSP_IRQ_CFG_GPT8_AD_TRIG_B                     (BSP_IRQ_DISABLED) ///< GPT8 AD TRIG B
#define BSP_IRQ_CFG_GPT9_CAPTURE_COMPARE_INT_A         (BSP_IRQ_DISABLED) ///< GPT9 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT9_CAPTURE_COMPARE_INT_B         (BSP_IRQ_DISABLED) ///< GPT9 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT9_COMPARE_INT_C                 (BSP_IRQ_DISABLED) ///< GPT9 COMPARE INT C
#define BSP_IRQ_CFG_GPT9_COMPARE_INT_D                 (BSP_IRQ_DISABLED) ///< GPT9 COMPARE INT D
#define BSP_IRQ_CFG_GPT9_COMPARE_INT_E                 (BSP_IRQ_DISABLED) ///< GPT9 COMPARE INT E
#define BSP_IRQ_CFG_GPT9_COMPARE_INT_F                 (BSP_IRQ_DISABLED) ///< GPT9 COMPARE INT F
#define BSP_IRQ_CFG_GPT9_COUNTER_OVERFLOW              (BSP_IRQ_DISABLED) ///< GPT9 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT9_COUNTER_UNDERFLOW             (BSP_IRQ_DISABLED) ///< GPT9 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT9_AD_TRIG_A                     (BSP_IRQ_DISABLED) ///< GPT9 AD TRIG A
#define BSP_IRQ_CFG_GPT9_AD_TRIG_B                     (BSP_IRQ_DISABLED) ///< GPT9 AD TRIG B
#define BSP_IRQ_CFG_GPT10_CAPTURE_COMPARE_INT_A        (BSP_IRQ_DISABLED) ///< GPT10 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT10_CAPTURE_COMPARE_INT_B        (BSP_IRQ_DISABLED) ///< GPT10 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT10_COMPARE_INT_C                (BSP_IRQ_DISABLED) ///< GPT10 COMPARE INT C
#define BSP_IRQ_CFG_GPT10_COMPARE_INT_D                (BSP_IRQ_DISABLED) ///< GPT10 COMPARE INT D
#define BSP_IRQ_CFG_GPT10_COMPARE_INT_E                (BSP_IRQ_DISABLED) ///< GPT10 COMPARE INT E
#define BSP_IRQ_CFG_GPT10_COMPARE_INT_F                (BSP_IRQ_DISABLED) ///< GPT10 COMPARE INT F
#define BSP_IRQ_CFG_GPT10_COUNTER_OVERFLOW             (BSP_IRQ_DISABLED) ///< GPT10 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT10_COUNTER_UNDERFLOW            (BSP_IRQ_DISABLED) ///< GPT10 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT10_AD_TRIG_A                    (BSP_IRQ_DISABLED) ///< GPT10 AD TRIG A
#define BSP_IRQ_CFG_GPT10_AD_TRIG_B                    (BSP_IRQ_DISABLED) ///< GPT10 AD TRIG B
#define BSP_IRQ_CFG_GPT11_CAPTURE_COMPARE_INT_A        (BSP_IRQ_DISABLED) ///< GPT11 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT11_CAPTURE_COMPARE_INT_B        (BSP_IRQ_DISABLED) ///< GPT11 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT11_COMPARE_INT_C                (BSP_IRQ_DISABLED) ///< GPT11 COMPARE INT C
#define BSP_IRQ_CFG_GPT11_COMPARE_INT_D                (BSP_IRQ_DISABLED) ///< GPT11 COMPARE INT D
#define BSP_IRQ_CFG_GPT11_COMPARE_INT_E                (BSP_IRQ_DISABLED) ///< GPT11 COMPARE INT E
#define BSP_IRQ_CFG_GPT11_COMPARE_INT_F                (BSP_IRQ_DISABLED) ///< GPT11 COMPARE INT F
#define BSP_IRQ_CFG_GPT11_COUNTER_OVERFLOW             (BSP_IRQ_DISABLED) ///< GPT11 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT11_COUNTER_UNDERFLOW            (BSP_IRQ_DISABLED) ///< GPT11 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT11_AD_TRIG_A                    (BSP_IRQ_DISABLED) ///< GPT11 AD TRIG A
#define BSP_IRQ_CFG_GPT11_AD_TRIG_B                    (BSP_IRQ_DISABLED) ///< GPT11 AD TRIG B
#define BSP_IRQ_CFG_GPT12_CAPTURE_COMPARE_INT_A        (BSP_IRQ_DISABLED) ///< GPT12 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT12_CAPTURE_COMPARE_INT_B        (BSP_IRQ_DISABLED) ///< GPT12 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT12_COMPARE_INT_C                (BSP_IRQ_DISABLED) ///< GPT12 COMPARE INT C
#define BSP_IRQ_CFG_GPT12_COMPARE_INT_D                (BSP_IRQ_DISABLED) ///< GPT12 COMPARE INT D
#define BSP_IRQ_CFG_GPT12_COMPARE_INT_E                (BSP_IRQ_DISABLED) ///< GPT12 COMPARE INT E
#define BSP_IRQ_CFG_GPT12_COMPARE_INT_F                (BSP_IRQ_DISABLED) ///< GPT12 COMPARE INT F
#define BSP_IRQ_CFG_GPT12_COUNTER_OVERFLOW             (BSP_IRQ_DISABLED) ///< GPT12 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT12_COUNTER_UNDERFLOW            (BSP_IRQ_DISABLED) ///< GPT12 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT12_AD_TRIG_A                    (BSP_IRQ_DISABLED) ///< GPT12 AD TRIG A
#define BSP_IRQ_CFG_GPT12_AD_TRIG_B                    (BSP_IRQ_DISABLED) ///< GPT12 AD TRIG B
#define BSP_IRQ_CFG_GPT13_CAPTURE_COMPARE_INT_A        (BSP_IRQ_DISABLED) ///< GPT13 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT13_CAPTURE_COMPARE_INT_B        (BSP_IRQ_DISABLED) ///< GPT13 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT13_COMPARE_INT_C                (BSP_IRQ_DISABLED) ///< GPT13 COMPARE INT C
#define BSP_IRQ_CFG_GPT13_COMPARE_INT_D                (BSP_IRQ_DISABLED) ///< GPT13 COMPARE INT D
#define BSP_IRQ_CFG_GPT13_COMPARE_INT_E                (BSP_IRQ_DISABLED) ///< GPT13 COMPARE INT E
#define BSP_IRQ_CFG_GPT13_COMPARE_INT_F                (BSP_IRQ_DISABLED) ///< GPT13 COMPARE INT F
#define BSP_IRQ_CFG_GPT13_COUNTER_OVERFLOW             (BSP_IRQ_DISABLED) ///< GPT13 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT13_COUNTER_UNDERFLOW            (BSP_IRQ_DISABLED) ///< GPT13 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT13_AD_TRIG_A                    (BSP_IRQ_DISABLED) ///< GPT13 AD TRIG A
#define BSP_IRQ_CFG_GPT13_AD_TRIG_B                    (BSP_IRQ_DISABLED) ///< GPT13 AD TRIG B
#define BSP_IRQ_CFG_GPT14_CAPTURE_COMPARE_INT_A        (BSP_IRQ_DISABLED) ///< GPT14 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT14_CAPTURE_COMPARE_INT_B        (BSP_IRQ_DISABLED) ///< GPT14 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT14_COMPARE_INT_C                (BSP_IRQ_DISABLED) ///< GPT14 COMPARE INT C
#define BSP_IRQ_CFG_GPT14_COMPARE_INT_D                (BSP_IRQ_DISABLED) ///< GPT14 COMPARE INT D
#define BSP_IRQ_CFG_GPT14_COMPARE_INT_E                (BSP_IRQ_DISABLED) ///< GPT14 COMPARE INT E
#define BSP_IRQ_CFG_GPT14_COMPARE_INT_F                (BSP_IRQ_DISABLED) ///< GPT14 COMPARE INT F
#define BSP_IRQ_CFG_GPT14_COUNTER_OVERFLOW             (BSP_IRQ_DISABLED) ///< GPT14 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT14_COUNTER_UNDERFLOW            (BSP_IRQ_DISABLED) ///< GPT14 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT14_AD_TRIG_A                    (BSP_IRQ_DISABLED) ///< GPT14 AD TRIG A
#define BSP_IRQ_CFG_GPT14_AD_TRIG_B                    (BSP_IRQ_DISABLED) ///< GPT14 AD TRIG B
#define BSP_IRQ_CFG_GPT15_CAPTURE_COMPARE_INT_A        (BSP_IRQ_DISABLED) ///< GPT15 CAPTURE COMPARE INT A
#define BSP_IRQ_CFG_GPT15_CAPTURE_COMPARE_INT_B        (BSP_IRQ_DISABLED) ///< GPT15 CAPTURE COMPARE INT B
#define BSP_IRQ_CFG_GPT15_COMPARE_INT_C                (BSP_IRQ_DISABLED) ///< GPT15 COMPARE INT C
#define BSP_IRQ_CFG_GPT15_COMPARE_INT_D                (BSP_IRQ_DISABLED) ///< GPT15 COMPARE INT D
#define BSP_IRQ_CFG_GPT15_COMPARE_INT_E                (BSP_IRQ_DISABLED) ///< GPT15 COMPARE INT E
#define BSP_IRQ_CFG_GPT15_COMPARE_INT_F                (BSP_IRQ_DISABLED) ///< GPT15 COMPARE INT F
#define BSP_IRQ_CFG_GPT15_COUNTER_OVERFLOW             (BSP_IRQ_DISABLED) ///< GPT15 COUNTER OVERFLOW
#define BSP_IRQ_CFG_GPT15_COUNTER_UNDERFLOW            (BSP_IRQ_DISABLED) ///< GPT15 COUNTER UNDERFLOW
#define BSP_IRQ_CFG_GPT15_AD_TRIG_A                    (BSP_IRQ_DISABLED) ///< GPT15 AD TRIG A
#define BSP_IRQ_CFG_GPT15_AD_TRIG_B                    (BSP_IRQ_DISABLED) ///< GPT15 AD TRIG B
#define BSP_IRQ_CFG_GPT_UVW_EDGE                       (BSP_IRQ_DISABLED) ///< GPT UVW EDGE
#define BSP_IRQ_CFG_ETHER_IPLS                         (BSP_IRQ_DISABLED) ///< ETHER IPLS
#define BSP_IRQ_CFG_ETHER_MINT                         (BSP_IRQ_DISABLED) ///< ETHER MINT
#define BSP_IRQ_CFG_ETHER_PINT                         (BSP_IRQ_DISABLED) ///< ETHER PINT
#define BSP_IRQ_CFG_ETHER_EINT0                        (BSP_IRQ_DISABLED) ///< ETHER EINT0
#define BSP_IRQ_CFG_ETHER_EINT1                        (BSP_IRQ_DISABLED) ///< ETHER EINT1
#define BSP_IRQ_CFG_ETHER_ETHER0_RISE                  (BSP_IRQ_DISABLED) ///< ETHER ETHER0 RISE
#define BSP_IRQ_CFG_ETHER_ETHER1_RISE                  (BSP_IRQ_DISABLED) ///< ETHER ETHER1 RISE
#define BSP_IRQ_CFG_ETHER_ETHER2_RISE                  (BSP_IRQ_DISABLED) ///< ETHER ETHER2 RISE
#define BSP_IRQ_CFG_ETHER_ETHER3_RISE                  (BSP_IRQ_DISABLED) ///< ETHER ETHER3 RISE
#define BSP_IRQ_CFG_ETHER_ETHER4_RISE                  (BSP_IRQ_DISABLED) ///< ETHER ETHER4 RISE
#define BSP_IRQ_CFG_ETHER_ETHER5_RISE                  (BSP_IRQ_DISABLED) ///< ETHER ETHER5 RISE
#define BSP_IRQ_CFG_ETHER_ETHER0_FALL                  (BSP_IRQ_DISABLED) ///< ETHER ETHER0 FALL
#define BSP_IRQ_CFG_ETHER_ETHER1_FALL                  (BSP_IRQ_DISABLED) ///< ETHER ETHER1 FALL
#define BSP_IRQ_CFG_ETHER_ETHER2_FALL                  (BSP_IRQ_DISABLED) ///< ETHER ETHER2 FALL
#define BSP_IRQ_CFG_ETHER_ETHER3_FALL                  (BSP_IRQ_DISABLED) ///< ETHER ETHER3 FALL
#define BSP_IRQ_CFG_ETHER_ETHER4_FALL                  (BSP_IRQ_DISABLED) ///< ETHER ETHER4 FALL
#define BSP_IRQ_CFG_ETHER_ETHER5_FALL                  (BSP_IRQ_DISABLED) ///< ETHER ETHER5 FALL
#define BSP_IRQ_CFG_USBHS_D0FIFO                       (BSP_IRQ_DISABLED) ///< USBHS D0FIFO
#define BSP_IRQ_CFG_USBHS_D1FIFO                       (BSP_IRQ_DISABLED) ///< USBHS D1FIFO
#define BSP_IRQ_CFG_USBHS_USBIR                        (BSP_IRQ_DISABLED) ///< USBHS USBIR
#define BSP_IRQ_CFG_SCI0_RXI                           (BSP_IRQ_DISABLED) ///< SCI0 RXI
#define BSP_IRQ_CFG_SCI0_TXI                           (BSP_IRQ_DISABLED) ///< SCI0 TXI
#define BSP_IRQ_CFG_SCI0_TEI                           (BSP_IRQ_DISABLED) ///< SCI0 TEI
#define BSP_IRQ_CFG_SCI0_ERI                           (BSP_IRQ_DISABLED) ///< SCI0 ERI
#define BSP_IRQ_CFG_SCI0_AM                            (BSP_IRQ_DISABLED) ///< SCI0 AM
#define BSP_IRQ_CFG_SCI0_RXI_OR_ERI                    (BSP_IRQ_DISABLED) ///< SCI0 RXI OR ERI
#define BSP_IRQ_CFG_SCI1_RXI                           (BSP_IRQ_DISABLED) ///< SCI1 RXI
#define BSP_IRQ_CFG_SCI1_TXI                           (BSP_IRQ_DISABLED) ///< SCI1 TXI
#define BSP_IRQ_CFG_SCI1_TEI                           (BSP_IRQ_DISABLED) ///< SCI1 TEI
#define BSP_IRQ_CFG_SCI1_ERI                           (BSP_IRQ_DISABLED) ///< SCI1 ERI
#define BSP_IRQ_CFG_SCI1_AM                            (BSP_IRQ_DISABLED) ///< SCI1 AM
#define BSP_IRQ_CFG_SCI2_RXI                           (BSP_IRQ_DISABLED) ///< SCI2 RXI
#define BSP_IRQ_CFG_SCI2_TXI                           (BSP_IRQ_DISABLED) ///< SCI2 TXI
#define BSP_IRQ_CFG_SCI2_TEI                           (BSP_IRQ_DISABLED) ///< SCI2 TEI
#define BSP_IRQ_CFG_SCI2_ERI                           (BSP_IRQ_DISABLED) ///< SCI2 ERI
#define BSP_IRQ_CFG_SCI2_AM                            (BSP_IRQ_DISABLED) ///< SCI2 AM
#define BSP_IRQ_CFG_SCI3_RXI                           (BSP_IRQ_DISABLED) ///< SCI3 RXI
#define BSP_IRQ_CFG_SCI3_TXI                           (BSP_IRQ_DISABLED) ///< SCI3 TXI
#define BSP_IRQ_CFG_SCI3_TEI                           (BSP_IRQ_DISABLED) ///< SCI3 TEI
#define BSP_IRQ_CFG_SCI3_ERI                           (BSP_IRQ_DISABLED) ///< SCI3 ERI
#define BSP_IRQ_CFG_SCI3_AM                            (BSP_IRQ_DISABLED) ///< SCI3 AM
#define BSP_IRQ_CFG_SCI4_RXI                           (BSP_IRQ_DISABLED) ///< SCI4 RXI
#define BSP_IRQ_CFG_SCI4_TXI                           (BSP_IRQ_DISABLED) ///< SCI4 TXI
#define BSP_IRQ_CFG_SCI4_TEI                           (BSP_IRQ_DISABLED) ///< SCI4 TEI
#define BSP_IRQ_CFG_SCI4_ERI                           (BSP_IRQ_DISABLED) ///< SCI4 ERI
#define BSP_IRQ_CFG_SCI4_AM                            (BSP_IRQ_DISABLED) ///< SCI4 AM
#define BSP_IRQ_CFG_SCI5_RXI                           (BSP_IRQ_DISABLED) ///< SCI5 RXI
#define BSP_IRQ_CFG_SCI5_TXI                           (BSP_IRQ_DISABLED) ///< SCI5 TXI
#define BSP_IRQ_CFG_SCI5_TEI                           (BSP_IRQ_DISABLED) ///< SCI5 TEI
#define BSP_IRQ_CFG_SCI5_ERI                           (BSP_IRQ_DISABLED) ///< SCI5 ERI
#define BSP_IRQ_CFG_SCI5_AM                            (BSP_IRQ_DISABLED) ///< SCI5 AM
#define BSP_IRQ_CFG_SCI6_RXI                           (BSP_IRQ_DISABLED) ///< SCI6 RXI
#define BSP_IRQ_CFG_SCI6_TXI                           (BSP_IRQ_DISABLED) ///< SCI6 TXI
#define BSP_IRQ_CFG_SCI6_TEI                           (BSP_IRQ_DISABLED) ///< SCI6 TEI
#define BSP_IRQ_CFG_SCI6_ERI                           (BSP_IRQ_DISABLED) ///< SCI6 ERI
#define BSP_IRQ_CFG_SCI6_AM                            (BSP_IRQ_DISABLED) ///< SCI6 AM
#define BSP_IRQ_CFG_SCI7_RXI                           (BSP_IRQ_DISABLED) ///< SCI7 RXI
#define BSP_IRQ_CFG_SCI7_TXI                           (BSP_IRQ_DISABLED) ///< SCI7 TXI
#define BSP_IRQ_CFG_SCI7_TEI                           (BSP_IRQ_DISABLED) ///< SCI7 TEI
#define BSP_IRQ_CFG_SCI7_ERI                           (BSP_IRQ_DISABLED) ///< SCI7 ERI
#define BSP_IRQ_CFG_SCI7_AM                            (BSP_IRQ_DISABLED) ///< SCI7 AM
#define BSP_IRQ_CFG_SCI8_RXI                           (BSP_IRQ_DISABLED) ///< SCI8 RXI
#define BSP_IRQ_CFG_SCI8_TXI                           (BSP_IRQ_DISABLED) ///< SCI8 TXI
#define BSP_IRQ_CFG_SCI8_TEI                           (BSP_IRQ_DISABLED) ///< SCI8 TEI
#define BSP_IRQ_CFG_SCI8_ERI                           (BSP_IRQ_DISABLED) ///< SCI8 ERI
#define BSP_IRQ_CFG_SCI8_AM                            (BSP_IRQ_DISABLED) ///< SCI8 AM
#define BSP_IRQ_CFG_SCI9_RXI                           (BSP_IRQ_DISABLED) ///< SCI9 RXI
#define BSP_IRQ_CFG_SCI9_TXI                           (BSP_IRQ_DISABLED) ///< SCI9 TXI
#define BSP_IRQ_CFG_SCI9_TEI                           (BSP_IRQ_DISABLED) ///< SCI9 TEI
#define BSP_IRQ_CFG_SCI9_ERI                           (BSP_IRQ_DISABLED) ///< SCI9 ERI
#define BSP_IRQ_CFG_SCI9_AM                            (BSP_IRQ_DISABLED) ///< SCI9 AM
#define BSP_IRQ_CFG_RSPI0_SPRI                         (BSP_IRQ_DISABLED) ///< RSPI0 SPRI
#define BSP_IRQ_CFG_RSPI0_SPTI                         (BSP_IRQ_DISABLED) ///< RSPI0 SPTI
#define BSP_IRQ_CFG_RSPI0_SPII                         (BSP_IRQ_DISABLED) ///< RSPI0 SPII
#define BSP_IRQ_CFG_RSPI0_SPEI                         (BSP_IRQ_DISABLED) ///< RSPI0 SPEI
#define BSP_IRQ_CFG_RSPI0_SP_ELCTEND                   (BSP_IRQ_DISABLED) ///< RSPI0 SP ELCTEND
#define BSP_IRQ_CFG_RSPI1_SPRI                         (BSP_IRQ_DISABLED) ///< RSPI1 SPRI
#define BSP_IRQ_CFG_RSPI1_SPTI                         (BSP_IRQ_DISABLED) ///< RSPI1 SPTI
#define BSP_IRQ_CFG_RSPI1_SPII                         (BSP_IRQ_DISABLED) ///< RSPI1 SPII
#define BSP_IRQ_CFG_RSPI1_SPEI                         (BSP_IRQ_DISABLED) ///< RSPI1 SPEI
#define BSP_IRQ_CFG_RSPI1_SP_ELCTEND                   (BSP_IRQ_DISABLED) ///< RSPI1 SP ELCTEND
#define BSP_IRQ_CFG_QSPI_INTR                          (BSP_IRQ_DISABLED) ///< QSPI INTR
#define BSP_IRQ_CFG_SDHI_MMC0_ACCS                     (BSP_IRQ_DISABLED) ///< SDHI MMC0 ACCS
#define BSP_IRQ_CFG_SDHI_MMC0_SDIO                     (BSP_IRQ_DISABLED) ///< SDHI MMC0 SDIO
#define BSP_IRQ_CFG_SDHI_MMC0_CARD                     (BSP_IRQ_DISABLED) ///< SDHI MMC0 CARD
#define BSP_IRQ_CFG_SDHI_MMC0_ODMSDBREQ                (BSP_IRQ_DISABLED) ///< SDHI MMC0 ODMSDBREQ
#define BSP_IRQ_CFG_SDHI_MMC1_ACCS                     (BSP_IRQ_DISABLED) ///< SDHI MMC1 ACCS
#define BSP_IRQ_CFG_SDHI_MMC1_SDIO                     (BSP_IRQ_DISABLED) ///< SDHI MMC1 SDIO
#define BSP_IRQ_CFG_SDHI_MMC1_CARD                     (BSP_IRQ_DISABLED) ///< SDHI MMC1 CARD
#define BSP_IRQ_CFG_SDHI_MMC1_ODMSDBREQ                (BSP_IRQ_DISABLED) ///< SDHI MMC1 ODMSDBREQ
#define BSP_IRQ_CFG_EXT_DIVIDER_INTMD                  (BSP_IRQ_DISABLED) ///< EXT DIVIDER INTMD
#define BSP_IRQ_CFG_TSIP_PROC_BUSY_N                   (BSP_IRQ_DISABLED) ///< TSIP PROC BUSY N
#define BSP_IRQ_CFG_TSIP_ROMOK_N                       (BSP_IRQ_DISABLED) ///< TSIP ROMOK N
#define BSP_IRQ_CFG_TSIP_LONG_PLG_N                    (BSP_IRQ_DISABLED) ///< TSIP LONG PLG N
#define BSP_IRQ_CFG_TSIP_TEST_BUSY_N                   (BSP_IRQ_DISABLED) ///< TSIP TEST BUSY N
#define BSP_IRQ_CFG_TSIP_WRRDY_0_N                     (BSP_IRQ_DISABLED) ///< TSIP WRRDY 0 N
#define BSP_IRQ_CFG_TSIP_WRRDY_1_N                     (BSP_IRQ_DISABLED) ///< TSIP WRRDY 1 N
#define BSP_IRQ_CFG_TSIP_WRRDY_4_N                     (BSP_IRQ_DISABLED) ///< TSIP WRRDY 4 N
#define BSP_IRQ_CFG_TSIP_RDRDY_0_N                     (BSP_IRQ_DISABLED) ///< TSIP RDRDY 0 N
#define BSP_IRQ_CFG_TSIP_RDRDY_1_N                     (BSP_IRQ_DISABLED) ///< TSIP RDRDY 1 N
#define BSP_IRQ_CFG_TSIP_INTEGRATE_WRRDY_N             (BSP_IRQ_DISABLED) ///< TSIP INTEGRATE WRRDY N
#define BSP_IRQ_CFG_TSIP_INTEGRATE_RDRDY_N             (BSP_IRQ_DISABLED) ///< TSIP INTEGRATE RDRDY N
#define BSP_IRQ_CFG_LCDC_LCDC_LEVEL_0                  (BSP_IRQ_DISABLED) ///< LCDC LCDC LEVEL 0
#define BSP_IRQ_CFG_LCDC_LCDC_LEVEL_1                  (BSP_IRQ_DISABLED) ///< LCDC LCDC LEVEL 1
#define BSP_IRQ_CFG_LCDC_LCDC_LEVEL_2                  (BSP_IRQ_DISABLED) ///< LCDC LCDC LEVEL 2
#define BSP_IRQ_CFG_TWOD_ENGINE_IRQ                    (BSP_IRQ_DISABLED) ///< TWOD ENGINE IRQ
#define BSP_IRQ_CFG_JPEG_JEDI                          (BSP_IRQ_DISABLED) ///< JPEG JEDI
#define BSP_IRQ_CFG_JPEG_JDTI                          (BSP_IRQ_DISABLED) ///< JPEG JDTI

/** @} (end defgroup BSP_CONFIG_USER_INTERRUPTS) */

#endif /* BSP_IRQ_CFG_REF_H  */
