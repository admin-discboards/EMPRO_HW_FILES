/*****************************************************************************
 *  Copyright (C) 2015 by Embedded Product Design, LLC                       *
 *                                                                           *
 *  FILENAME: 4x4 RGB click.h      PART OF PROJECT: DBSK_4x4rgbClick_demo    *
 *                                                                           *
 *  FILE DESCRIPTION:                                                        *
 *  Created to assist in overriding the code in "4x4 RGB Click.c/.h with     *
 *  SSP-equivalents.                                                         *
 *                                                                           *
 *  HISTORY:                                                                 *
 *  Date          By               Description                               *
 *  2015-10-09    EPD/Ed Strehle   v1.00 release for Renesas DevCon 2015     *
 *  2015-10-19    EPD/Ed Strehle   v1.1.0 update for SSP v1.0.0              *
 *                                                                           *
 *  NOTES:                                                                   *
 *                                                                           *
 *  KNOWN TODOs:                                                             *
 *  <none>                                                                   *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
#ifndef fourbyfour_RGB_CLICK_H_
#define fourbyfour_RGB_CLICK_H_

extern int i;
extern int n;

void main_rgb4x4click(void);

#endif /* fourbyfour_RGB_CLICK_H_ */
