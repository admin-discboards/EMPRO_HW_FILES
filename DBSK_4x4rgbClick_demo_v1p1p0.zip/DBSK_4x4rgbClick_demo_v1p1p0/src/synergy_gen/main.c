/* generated main source file - do not edit */
extern void hal_entry(void);
void main(void)
{
    hal_entry ();
}
