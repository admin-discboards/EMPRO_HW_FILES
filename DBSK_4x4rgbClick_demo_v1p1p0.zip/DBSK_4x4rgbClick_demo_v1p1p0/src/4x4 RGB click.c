/*
* * Project name:
*     4x4 RGB click
* * Copyright:
*     (c) Mikroelektronika, 2015.
* * Revision History:
*    20120404:
*      - mikroC PRO for FT90X (VM);
* * Description:
*      A simple example of the RGB 4X4 Click. 4x4 RGB click carries a matrix of 16 RGB LEDs and a MCP1826 low dropout regulator.
*      These LEDs actually consist of three single colored LEDs (Red, Green and Blue) in a single package.
*      Various colors can be reproduced by mixing the intensity of each LED.
*      The LED matrix is connected to the target board microcontroller through the mikroBUS� RST pin.
*      The board uses either a 3.3V or 5V power supply.
*
* * Test configuration:
*     MCU:             FT900
*                      http://www.ftdichip.com/Support/Documents/DataSheets/ICs/DS_FT900_1_2_3.pdf
*     Dev.Board:       EasyFT90x v7
*                      http://www.mikroe.com/easyft90x
*     Oscillator:      CPU at full system clock, 100.000MHz
*     Ext. modules:    4x4 RGB click
*     SW:              mikroC PRO for FT90x
*                      http://www.mikroe.com/mikroc/ft90x/
* * NOTES:
*     - Place 4x4 RGB click in mikroBUS socket 1
*     - ATTENTION! Setting the diodes on maximum frequency is not recommended!!
*     - Recommended maximum settings for white color is 0x00A0A0A0.
*
*****************************************************************************************************************************************************/

/*****************************************************************************
 * Copyright (C) 2015 by Embedded Product Design, LLC                        *
 *                                                                           *
 * FILENAME: 4x4 RGB click.c      PART OF PROJECT: DBSK_4x4rgbClick_demo     *
 *                                                                           *
 * FILE DESCRIPTION:                                                         *
 * Commented-out original code as provided my MikroElektronica               *
 * SSP-equivalents are included in support.c/.h                              *
 *                                                                           *
 * HISTORY:                                                                  *
 * Date          By               Description                                *
 * 2015-10-09    EPD/Ed Strehle   v1.00 release for Renesas DevCon 2015      *
 * 2015-10-19    EPD/Ed Strehle   v1.1.0 update for SSP v1.0.0               *
 *                                                                           *
 * NOTES:                                                                    *
 *                                                                           *
 * KNOWN TODOs:                                                              *
 * <none>                                                                    *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/

#include "support.h"

#define MAX_SIZE  16

//int i;
int n;

unsigned long DiodeArray[MAX_SIZE];
unsigned long TempColor;

/* to be replaced with SSP equivalents ... see support.c
sbit RGBLed_Data at GPIO_PIN1_bit;         // Set data port


void RGBLed_ZeroBit() {
  RGBLed_Data = 1;
  Delay_Cyc(3);
  RGBLed_Data = 0;
  Delay_Cyc(7);
}

void RGBLed_OneBit() {
  RGBLed_Data = 1;
  Delay_Cyc(7);
  RGBLed_Data = 0;
  Delay_Cyc(6);
}

void RGBLed_ResetDelay() {
  Delay_50us();
  Delay_10us();
}
*/

void RGBLed_InitDiode(unsigned long ARGBColor, unsigned long * AdiodeArray) {
  *AdiodeArray = (ARGBColor & 0x000000FF) | ((ARGBColor >> 16) << 8) | ((ARGBColor >> 8) << 16);
}

void RGBLed_SetColor(unsigned long * AdiodeArray) {
  signed char i;

  for (i = 23; i >= 0; i--) {
    if (( (*AdiodeArray) & (1ul << i)) == 0) {
      RGBLed_ZeroBit();
    }
    else {
      RGBLed_OneBit();
    }
  }
}

void RGBLed_SetDiode(char ANum, unsigned long AColor, unsigned long * AdiodeArray) {
  char i;

   for (i = 0; i < MAX_SIZE; i++) {
    if (i == (ANum - 1)) {
      RGBLed_InitDiode(AColor, &AdiodeArray[i]);
      RGBLed_SetColor(&AdiodeArray[i]);
    }
    else {
      RGBLed_SetColor(&AdiodeArray[i]);
    }
  }
  RGBLed_ResetDelay();
}

/* to be replaced with SSP equivalents ... see support.c
void RGBLed_InitHW() {
  GPIO_Digital_Output(&GPIO_PORT_00_07, _GPIO_PINMASK_1);        // Initialize data output pin
}
// Because delay_ms uses only constant variables, we will use this function to change the time delay.
// Change the delay by changing the n variable.
void Delay_time() {
  unsigned int n1;
  for (n1=1; n1<=n; n1++)
  delay_ms(5);
}
*/

// Start snake
void Snake() {
  RGBLed_SetDiode(4, TempColor, DiodeArray);  // Turn on diode 4 with the desired color
  Delay_time();
  RGBLed_SetDiode(3, TempColor, DiodeArray);  // Turn on diode 3 with the desired color
  Delay_time();
  RGBLed_SetDiode(2, TempColor, DiodeArray);  // Turn on diode 2 with the desired color
  Delay_time();
  RGBLed_SetDiode(1, TempColor, DiodeArray);  // Turn on diode 1 with the desired color
  Delay_time();
  RGBLed_SetDiode(5, TempColor, DiodeArray);  // Turn on diode 5 with the desired color
  Delay_time();
  RGBLed_SetDiode(9, TempColor, DiodeArray);  // Turn on diode 9 with the desired color
  Delay_time();
  RGBLed_SetDiode(13, TempColor, DiodeArray); // Turn on diode 13 with the desired color
  Delay_time();
  RGBLed_SetDiode(14, TempColor, DiodeArray); // Turn on diode 14 with the desired color
  Delay_time();
  RGBLed_SetDiode(15, TempColor, DiodeArray); // Turn on diode 15 with the desired color
  Delay_time();
  RGBLed_SetDiode(16, TempColor, DiodeArray); // Turn on diode 16 with the desired color
  Delay_time();
  RGBLed_SetDiode(12, TempColor, DiodeArray); // Turn on diode 12 with the desired color
  Delay_time();
  RGBLed_SetDiode(8, TempColor, DiodeArray);  // Turn on diode 8 with the desired color
  Delay_time();
  RGBLed_SetDiode(7, TempColor, DiodeArray);  // Turn on diode 7 with the desired color
  Delay_time();
  RGBLed_SetDiode(6, TempColor, DiodeArray);  // Turn on diode 6 with the desired color
  Delay_time();
  RGBLed_SetDiode(10, TempColor, DiodeArray); // Turn on diode 10 with the desired color
  Delay_time();
  RGBLed_SetDiode(11, TempColor, DiodeArray); // Turn on diode 11 with the desired color
}
// Return Snake
 void Snake_return ()  {
  RGBLed_SetDiode(11, TempColor, DiodeArray); // Turn on diode 11 with the desired color
  Delay_time();
  RGBLed_SetDiode(10, TempColor, DiodeArray); // Turn on diode 10 with the desired color
  Delay_time();
  RGBLed_SetDiode(6, TempColor, DiodeArray);  // Turn on diode 6 with the desired color
  Delay_time();
  RGBLed_SetDiode(7, TempColor, DiodeArray);  // Turn on diode 7 with the desired color
  Delay_time();
  RGBLed_SetDiode(8, TempColor, DiodeArray);  // Turn on diode 8 with the desired color
  Delay_time();
  RGBLed_SetDiode(12, TempColor, DiodeArray); // Turn on diode 12 with the desired color
  Delay_time();
  RGBLed_SetDiode(16, TempColor, DiodeArray); // Turn on diode 16 with the desired color
  Delay_time();
  RGBLed_SetDiode(15, TempColor, DiodeArray); // Turn on diode 15 with the desired color
  Delay_time();
  RGBLed_SetDiode(14, TempColor, DiodeArray); // Turn on diode 14 with the desired color
  Delay_time();
  RGBLed_SetDiode(13, TempColor, DiodeArray); // Turn on diode 13 with the desired color
  Delay_time();
  RGBLed_SetDiode(9, TempColor, DiodeArray);  // Turn on diode 9 with the desired color
  Delay_time();
  RGBLed_SetDiode(5, TempColor, DiodeArray);  // Turn on diode 5 with the desired color
  Delay_time();
  RGBLed_SetDiode(1, TempColor, DiodeArray);  // Turn on diode 1 with the desired color
  Delay_time();
  RGBLed_SetDiode(2, TempColor, DiodeArray);  // Turn on diode 2 with the desired color
  Delay_time();
  RGBLed_SetDiode(3, TempColor, DiodeArray);  // Turn on diode 3 with the desired color
  Delay_time();
  RGBLed_SetDiode(4, TempColor, DiodeArray);  // Turn on diode 4 with the desired color
  Delay_time();
}

// Fill all the diodes with one color
void FillScreen() {
  unsigned int n2;
  for (n2=1; n2<=16; n2++) {
    RGBLed_SetDiode(n2, TempColor, DiodeArray);
    delay_ms(100);
  }
}

// Main function
// 4x4Click demo code used intensity of 0x2F and it was blinding.  Using 0x0F.
// void main() {
void main_rgb4x4click() {

  RGBLed_InitHW();            // Initialize RGB HW
  TempColor = 0x00080808;     // White
  FillScreen();               // Fill screen with color

   while(1){
   // Start Snake
   n=20;                       // 20*5ms = 100ms delay
   TempColor = 0x00000008;     // Blue color
   Snake();
   TempColor = 0x00000808;     // Bright blue color
   Snake_return ();

   // Increase Snake Speed 1x
   n=15;                       // 15*5ms = 75ms delay
   TempColor = 0x00000800;     // Green colcor
   Snake();
   TempColor = 0x00080800;     // Yellow color back
   Snake_return();

   // Increase Snake Speed 2x
   TempColor = 0x00080000;     // Red color
   n=10;                       // 10*5ms = 50ms delay
   Snake();
   TempColor = 0x00080008;     // Purple color back
   Snake_return ();

   // Increase Snake Speed 3x
   n=5;                        // 5*5ms = 25ms delay
   TempColor = 0x00080808;     // White
   Snake_return ();
  }
}
