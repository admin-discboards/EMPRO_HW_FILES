/*****************************************************************************
 *  Copyright (C) 2015 by Embedded Product Design, LLC                       *
 *                                                                           *
 *  FILENAME: 4x4 RGB click.c      PART OF PROJECT: DBSK_4x4rgbClick_demo    *
 *                                                                           *
 *  FILE DESCRIPTION:                                                        *
 *  Contents used to override the code in "4x4 RGB Click.c//.h with          *
 *  SSP-equivalents.                                                         *
 *                                                                           *
 *  HISTORY:                                                                 *
 *  Date          By               Description                               *
 *  2015-10-09    EPD/Ed Strehle   v1.00 release for Renesas DevCon 2015     *
 *  2015-10-19    EPD/Ed Strehle   v1.1.0 update for SSP v1.0.0              *
 *                                                                           *
 *  NOTES:                                                                   *
 *                                                                           *
 *  KNOWN TODOs:                                                             *
 *  <none>                                                                   *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
#include "hal_data.h"

#ifndef SUPPORT_H_
#define SUPPORT_H_

/** DiscBoard user button */
#define DBSK_BUTTON01		((ioport_port_pin_t) IOPORT_PORT_01_PIN_11)

/** DiscBoard LEDs */
#define DB_LED_CPU          ((ioport_port_pin_t) IOPORT_PORT_01_PIN_09)
#define	DBSK_LED_D3         ((ioport_port_pin_t) IOPORT_PORT_02_PIN_00)
#define DBSK_LED_D4         ((ioport_port_pin_t) IOPORT_PORT_04_PIN_02)

/** other */
#define RGBLED_DATA_PIN		((ioport_port_pin_t) IOPORT_PORT_00_PIN_10)


/** SSP built-in function software_delay_loop() claims 4 cycles per loop plus 2 cycles overhead
 * overhead to set an IO bit is about 200ns
 * calculate by tpulse= tdelay_us-tovhd = (2+4N)/fc_MHz ==> N=(((tdelay_us-tovhd)*fc_MHz)-2)/4
 * 		for 400ns, N=(((0.4-0.2)*144)-2)/4)=7 cycles
 * 		for 850ns, N=(((0.85-0.2)*144)-2)/4)=23 cycles
 */
#define COUNTS_400NS_144MHZCLK	9
#define COUNTS_850NS_144MHZCLK	26

// function prototypes
void RGBLed_ZeroBit(void);
void RGBLed_OneBit(void);
void RGBLed_ResetDelay(void);
void RGBLed_InitHW(void);
void Delay_time(void);
void delay_ms(uint16_t n_ms);

#endif /* SUPPORT_H_ */
