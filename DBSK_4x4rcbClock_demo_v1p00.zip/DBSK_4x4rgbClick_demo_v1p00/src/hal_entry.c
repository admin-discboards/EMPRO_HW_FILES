/* HAL-only entry function */
/*****************************************************************************
 *  Copyright (C) 2015 by Embedded Product Design, LLC                       *
 *  Ed Strehle <edstrehle@emprodesign.com>                                   *
 *                                                                           *
 *  PROJECT NAME:         DBSK_4x4rgbClick_demo                              *
 *  PROJECT DESCRIPTION:                                                     *
 *  Generate an LED-array "snake" display using a purchased module           *
 *  - This project demonstrates the ability to integrate example code to     *
 *      drive a purchased "Click" board.                                     *
 *  - Files "4x4 RGB Click.c/.h" were imported from MikroElektronika.        *
 *  - IO functions were commented-out in the supplied code and replaced with *
 *      SSP equivalents.                                                     *
 *  WS2812S LEDs required specific timing near 400ns and 850ns.  GPIO        *
 *  control through r_ioport methods took 2.7us.  Direct hardware access     *
 *  allowed faster IO control                                                *
 *                                                                           *
 *  TARGET CONFIGURATION:                                                    *
 *      DiscBoards Processor module (S7G2) Rev A                             *
 *      DiscBoards Application module Rev A                                  *
 *      MikroElektronika 4x4RGB Click module (w/WorldSemi WS2812S RGB LED)   *
 *                                                                           *
 *  BUILD ENVIRONMENT:                                                       *
 *      Compiler:        Renesas Synergy SSP v0.91.01                        *
 *      SSP Blocks used: HAL, GPIO, external IRQ,                            *
 *                           low-level bypassing of r_ioport                 *
 *      Customizations:  SWO pin not used in Pin Configurator (ignore error) *
 *                                                                           *
 *  FILENAME: hal_entry.c                                                    *
 *  FILE DESCRIPTION:  Calls the main() function from the imported code      *
 *                                                                           *
 *  HISTORY:                                                                 *
 *  Date          By           Description                                   *
 *  2015-10-09    Ed Strehle   v1.00 Initial release for Renesas DevCon 2015 *
 *                                                                           *
 *  NOTES:                                                                   *
 *  1) Links:                                                                *
 *       http://www.discboards.org                                           *
 *       http://www.mikroe.com/click/4x4-rgb/                                *
 *       http://www.adafruit.com/datasheets/WS2812.pdf                       *
 *                                                                           *
 *  KNOWN TODOs:                                                             *
 *  <none>                                                                   *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
#include "hal_data.h"
#include "4x4 RGB click.h"

void hal_entry(void) {
	main_rgb4x4click();
}
