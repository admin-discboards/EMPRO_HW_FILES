/*
 * 4x4 RGB click.h
 *
 *  Created on: Sep 21, 2015
 *      Author: edstrehlepro
 */

#ifndef fourbyfour_RGB_CLICK_H_
#define fourbyfour_RGB_CLICK_H_

extern int i;
extern int n;

void main_rgb4x4click(void);

#endif /* fourbyfour_RGB_CLICK_H_ */
