/* generated HAL header file - do not edit */
#ifndef HAL_DATA_H_
#define HAL_DATA_H_
#include <stdint.h>
#include "bsp_api.h"
#include "r_icu.h"
#include "r_external_irq_api.h"
#include "r_ioport.h"
#include "r_ioport_api.h"
#include "r_elc.h"
#include "r_elc_api.h"
#include "r_cgc.h"
#include "r_cgc_api.h"
/* External IRQ on ICU Instance. */
extern const external_irq_instance_t g_external_irq;
#ifdef callback_Button01
#define EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_external_irq (0)
#else
#define EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_external_irq (1)
#endif
#if EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_external_irq
void callback_Button01(external_irq_callback_args_t * p_args);
#endif
/** IOPORT on IOPORT Instance */
extern const ioport_instance_t g_ioport;
/** Pointer to ELC API */
extern const elc_instance_t g_elc;
#endif /* HAL_DATA_H_ */
