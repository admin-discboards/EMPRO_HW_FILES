/***********************************************************************************************************************
 * Copyright [2015] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
 * display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
 * purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
 * SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
 * NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
 * OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
 * be subject to different terms.
 **********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : hw_icu_private.h
 * Description  : ICU register access functions.
 ***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *           19.12.2014 0.60    Initial Release.
 **********************************************************************************************************************/

#ifndef HW_ICU_COMMON_H
#define HW_ICU_COMMON_H

/**********************************************************************************************************************
 * Includes
 **********************************************************************************************************************/
/* Register definitions */
#include "bsp_api.h"

/**********************************************************************************************************************
 * Typedef definitions
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Macro Definitions
 **********************************************************************************************************************/
static IRQn_Type irq_lookup[ICU_BUTTON_MAX_NUM_CHANNELS] =
{
#if BSP_IRQ_CFG_PORT0_IRQ != BSP_IRQ_DISABLED
    PORT0_IRQ_IRQn,
#else
    BSP_MAX_NUM_IRQn,
#endif
#if BSP_IRQ_CFG_PORT1_IRQ != BSP_IRQ_DISABLED
    PORT1_IRQ_IRQn,
#else
    BSP_MAX_NUM_IRQn,
#endif
#if BSP_IRQ_CFG_PORT2_IRQ != BSP_IRQ_DISABLED
    PORT2_IRQ_IRQn,
#else
    BSP_MAX_NUM_IRQn,
#endif
#if BSP_IRQ_CFG_PORT3_IRQ != BSP_IRQ_DISABLED
    PORT3_IRQ_IRQn,
#else
    BSP_MAX_NUM_IRQn,
#endif
#if BSP_IRQ_CFG_PORT4_IRQ != BSP_IRQ_DISABLED
    PORT4_IRQ_IRQn,
#else
    BSP_MAX_NUM_IRQn,
#endif
#if BSP_IRQ_CFG_PORT5_IRQ != BSP_IRQ_DISABLED
    PORT5_IRQ_IRQn,
#else
    BSP_MAX_NUM_IRQn,
#endif
#if BSP_IRQ_CFG_PORT6_IRQ != BSP_IRQ_DISABLED
    PORT6_IRQ_IRQn,
#else
    BSP_MAX_NUM_IRQn,
#endif
#if BSP_IRQ_CFG_PORT7_IRQ != BSP_IRQ_DISABLED
    PORT7_IRQ_IRQn,
#else
    BSP_MAX_NUM_IRQn,
#endif
#if BSP_IRQ_CFG_PORT8_IRQ != BSP_IRQ_DISABLED
    PORT8_IRQ_IRQn,
#else
    BSP_MAX_NUM_IRQn,
#endif
#if BSP_IRQ_CFG_PORT9_IRQ != BSP_IRQ_DISABLED
    PORT9_IRQ_IRQn,
#else
    BSP_MAX_NUM_IRQn,
#endif
#if BSP_IRQ_CFG_PORT10_IRQ != BSP_IRQ_DISABLED
    PORT10_IRQ_IRQn,
#else
    BSP_MAX_NUM_IRQn,
#endif
#if BSP_IRQ_CFG_PORT11_IRQ != BSP_IRQ_DISABLED
    PORT11_IRQ_IRQn,
#else
    BSP_MAX_NUM_IRQn,
#endif
#if BSP_IRQ_CFG_PORT12_IRQ != BSP_IRQ_DISABLED
    PORT12_IRQ_IRQn,
#else
    BSP_MAX_NUM_IRQn,
#endif
#if BSP_IRQ_CFG_PORT13_IRQ != BSP_IRQ_DISABLED
    PORT13_IRQ_IRQn,
#else
    BSP_MAX_NUM_IRQn,
#endif
#if BSP_IRQ_CFG_PORT14_IRQ != BSP_IRQ_DISABLED
    PORT14_IRQ_IRQn,
#else
    BSP_MAX_NUM_IRQn,
#endif
#if BSP_IRQ_CFG_PORT15_IRQ != BSP_IRQ_DISABLED
    PORT15_IRQ_IRQn
#else
    BSP_MAX_NUM_IRQn,
#endif
};

/**********************************************************************************************************************
 * Function Prototypes
 **********************************************************************************************************************/
static inline void HW_ICU_DivisorSet (uint8_t ch, icu_divisor_t pclk_divisor)
{
    R_ICU->IRQCRn_b[ch].FCLKSEL = pclk_divisor;
}

static inline uint8_t HW_ICU_DivisorGet (uint8_t ch)
{
    return R_ICU->IRQCRn_b[ch].FCLKSEL;
}

static inline void HW_ICU_FilterDisable (uint8_t ch)
{
    R_ICU->IRQCRn_b[ch].FLTEN = 0;
}

static inline void HW_ICU_FilterEnable (uint8_t ch)
{
    R_ICU->IRQCRn_b[ch].FLTEN = 1;
}

static inline uint8_t HW_ICU_FilterGet (uint8_t ch)
{
    return R_ICU->IRQCRn_b[ch].FLTEN;
}

static inline IRQn_Type HW_ICU_IRQGet (uint8_t ch)
{
    return irq_lookup[ch];
}

static inline uint8_t HW_ICU_TriggerGet (uint8_t ch)
{
    return R_ICU->IRQCRn_b[ch].IRQMD;
}

static inline void HW_ICU_TriggerSet (uint8_t ch, external_irq_trigger_t trigger)
{
    R_ICU->IRQCRn_b[ch].IRQMD = trigger;
}
#endif /* HW_GPT_COMMON_H */
