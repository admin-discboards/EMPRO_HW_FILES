/***********************************************************************************************************************
 * Copyright [2015] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
 * display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
 * purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
 * SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
 * NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
 * OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
 * be subject to different terms.
 **********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : hw_elc_private.h
 * Description  : ELC LLD private API
 ***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *           ELC  1.00    Initial Release.
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @addtogroup ELC
 * @{
 **********************************************************************************************************************/

#ifndef HW_ELC_PRIVATE_H
#define HW_ELC_PRIVATE_H

#if defined(__GNUC__) && defined(__ARM_EABI__)
#define INLINE_ATTRIBUTE __attribute__((always_inline))
#else
#define INLINE_ATTRIBUTE
#endif

/**********************************************************************************************************************
 * Includes
 **********************************************************************************************************************/
#include "bsp_api.h"

/**********************************************************************************************************************
 * Macro definitions
 **********************************************************************************************************************/

/**********************************************************************************************************************
 * Typedef definitions
 **********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Prototypes
 **********************************************************************************************************************/
__STATIC_INLINE void HW_ELC_PowerOn (void) INLINE_ATTRIBUTE;

__STATIC_INLINE void HW_ELC_PowerOff (void) INLINE_ATTRIBUTE;

__STATIC_INLINE void HW_ELC_SoftwareEvent0Generate (void) INLINE_ATTRIBUTE;

__STATIC_INLINE void HW_ELC_SoftwareEvent1Generate (void) INLINE_ATTRIBUTE;

__STATIC_INLINE void HW_ELC_Enable (void) INLINE_ATTRIBUTE;

__STATIC_INLINE void HW_ELC_Disable (void) INLINE_ATTRIBUTE;

__STATIC_INLINE void HW_ELC_LinkSet (uint32_t peripheral, uint16_t signal) INLINE_ATTRIBUTE;

__STATIC_INLINE void HW_ELC_LinkBreak (uint32_t peripheral) INLINE_ATTRIBUTE;

/**********************************************************************************************************************
 * Includes
 **********************************************************************************************************************/
#include "common/hw_elc_common.h"
#endif /* HW_ELC_PRIVATE_H */

/*******************************************************************************************************************//**
 * @} (end addtogroup ELC)
 **********************************************************************************************************************/
