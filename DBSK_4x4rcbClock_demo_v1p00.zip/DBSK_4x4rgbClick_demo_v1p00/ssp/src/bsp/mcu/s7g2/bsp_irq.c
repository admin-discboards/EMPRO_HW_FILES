/***********************************************************************************************************************
 * Copyright [2015] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
 * display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
 * purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
 * SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
 * NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
 * OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
 * be subject to different terms.
 **********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : bsp_irq.c
* Description  : This module configures certain ELC events so that they can trigger NVIC interrupts.
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 22.07.2014 0.10     First Release
*         : 28.08.2014 0.20     Added R_BSP_IrqStatusClear() function.
*         : 24.09.2014 0.30     No longer uses BSP_IRQ_ENABLED. Sets NVIC priority level now.
*         : 03.08.2015 0.40     Removed COMP_LP and Vbatt entries as they are specific to S3A7.

***********************************************************************************************************************/
/*******************************************************************************************************************//**
 * @file
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "bsp_api.h"

#if defined(BSP_MCU_GROUP_S7G2)

/** ELC event definitions. */
#include "r_elc_api.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
/* Used for accessing bitfields in IELSR registers. */
typedef struct
{
    __IO uint32_t  IELS       :  9;               /* [0..8] Event selection to NVIC */
         uint32_t  res0       :  7;
    __IO uint32_t  IR         :  1;               /* [16..16] Interrupt Status Flag */
         uint32_t  res1       :  7;
    __IO uint32_t  DTCE       :  1;               /* [24..24] DTC Activation Enable */
         uint32_t  res2       :  7;
} bsp_prv_ielsr_t;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @addtogroup BSP_MCU_IRQ
 *
 * @{
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Clear the interrupt status flag (IR) for a given interrupt. When an interrupt is triggered the IR bit
 *        is set. If it is not cleared in the ISR then the interrupt will trigger again immediately.
 *
 * @param[in] irq Interrupt for which to clear the IR bit.
 *
 * @note This does not work for system exceptions where the IRQn_Type value is < 0.
 **********************************************************************************************************************/
void R_BSP_IrqStatusClear (IRQn_Type irq)
{
    /* This does not work for system exceptions where the IRQn_Type value is < 0 */
    if (((int32_t)irq) >= 0)
    {
        /** Clear the IR bit in the selected IELSR register. */
        ((bsp_prv_ielsr_t *)&R_ICU->IELSRn)[(uint32_t)irq].IR = 0;
    }
}

/** @} (end addtogroup BSP_MCU_IRQ) */

/*******************************************************************************************************************//**
 * @brief This function will initialize the ICU so that certain ELC events will trigger interrupts in the NVIC.
 *        It will also set the NVIC priority levels for all enabled interrupts. Which ELC events are enabled and
 *        what priority levels are used depends on the macro settings in bsp_irq_cfg.h.
 *
 * @note This does not work for system exceptions where the IRQn_Type value is < 0.
 **********************************************************************************************************************/
void bsp_irq_cfg (void)
{
    uint32_t * base_addr;

    base_addr = (uint32_t *)&R_ICU->IELSRn;

    /* This next line does not emit any code. It is used to suppress compiler warnings about base_addr not being
     * used when no interrupts are enabled. */
    ((void)(base_addr));

#if (BSP_IRQ_CFG_PORT0_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT0_IRQ_IRQn) = ELC_EVENT_PORT0_IRQ;
    NVIC_SetPriority(PORT0_IRQ_IRQn, BSP_IRQ_CFG_PORT0_IRQ);
#endif
#if (BSP_IRQ_CFG_PORT1_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT1_IRQ_IRQn) = ELC_EVENT_PORT1_IRQ;
    NVIC_SetPriority(PORT1_IRQ_IRQn, BSP_IRQ_CFG_PORT1_IRQ);
#endif
#if (BSP_IRQ_CFG_PORT2_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT2_IRQ_IRQn) = ELC_EVENT_PORT2_IRQ;
    NVIC_SetPriority(PORT2_IRQ_IRQn, BSP_IRQ_CFG_PORT2_IRQ);
#endif
#if (BSP_IRQ_CFG_PORT3_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT3_IRQ_IRQn) = ELC_EVENT_PORT3_IRQ;
    NVIC_SetPriority(PORT3_IRQ_IRQn, BSP_IRQ_CFG_PORT3_IRQ);
#endif
#if (BSP_IRQ_CFG_PORT4_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT4_IRQ_IRQn) = ELC_EVENT_PORT4_IRQ;
    NVIC_SetPriority(PORT4_IRQ_IRQn, BSP_IRQ_CFG_PORT4_IRQ);
#endif
#if (BSP_IRQ_CFG_PORT5_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT5_IRQ_IRQn) = ELC_EVENT_PORT5_IRQ;
    NVIC_SetPriority(PORT5_IRQ_IRQn, BSP_IRQ_CFG_PORT5_IRQ);
#endif
#if (BSP_IRQ_CFG_PORT6_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT6_IRQ_IRQn) = ELC_EVENT_PORT6_IRQ;
    NVIC_SetPriority(PORT6_IRQ_IRQn, BSP_IRQ_CFG_PORT6_IRQ);
#endif
#if (BSP_IRQ_CFG_PORT7_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT7_IRQ_IRQn) = ELC_EVENT_PORT7_IRQ;
    NVIC_SetPriority(PORT7_IRQ_IRQn, BSP_IRQ_CFG_PORT7_IRQ);
#endif
#if (BSP_IRQ_CFG_PORT8_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT8_IRQ_IRQn) = ELC_EVENT_PORT8_IRQ;
    NVIC_SetPriority(PORT8_IRQ_IRQn, BSP_IRQ_CFG_PORT8_IRQ);
#endif
#if (BSP_IRQ_CFG_PORT9_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT9_IRQ_IRQn) = ELC_EVENT_PORT9_IRQ;
    NVIC_SetPriority(PORT9_IRQ_IRQn, BSP_IRQ_CFG_PORT9_IRQ);
#endif
#if (BSP_IRQ_CFG_PORT10_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT10_IRQ_IRQn) = ELC_EVENT_PORT10_IRQ;
    NVIC_SetPriority(PORT10_IRQ_IRQn, BSP_IRQ_CFG_PORT10_IRQ);
#endif
#if (BSP_IRQ_CFG_PORT11_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT11_IRQ_IRQn) = ELC_EVENT_PORT11_IRQ;
    NVIC_SetPriority(PORT11_IRQ_IRQn, BSP_IRQ_CFG_PORT11_IRQ);
#endif
#if (BSP_IRQ_CFG_PORT12_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT12_IRQ_IRQn) = ELC_EVENT_PORT12_IRQ;
    NVIC_SetPriority(PORT12_IRQ_IRQn, BSP_IRQ_CFG_PORT12_IRQ);
#endif
#if (BSP_IRQ_CFG_PORT13_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT13_IRQ_IRQn) = ELC_EVENT_PORT13_IRQ;
    NVIC_SetPriority(PORT13_IRQ_IRQn, BSP_IRQ_CFG_PORT13_IRQ);
#endif
#if (BSP_IRQ_CFG_PORT14_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT14_IRQ_IRQn) = ELC_EVENT_PORT14_IRQ;
    NVIC_SetPriority(PORT14_IRQ_IRQn, BSP_IRQ_CFG_PORT14_IRQ);
#endif
#if (BSP_IRQ_CFG_PORT15_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PORT15_IRQ_IRQn) = ELC_EVENT_PORT15_IRQ;
    NVIC_SetPriority(PORT15_IRQ_IRQn, BSP_IRQ_CFG_PORT15_IRQ);
#endif
#if (BSP_IRQ_CFG_DMAC0_DMAC != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)DMAC0_DMAC_IRQn) = ELC_EVENT_DMAC0_DMAC;
    NVIC_SetPriority(DMAC0_DMAC_IRQn, BSP_IRQ_CFG_DMAC0_DMAC);
#endif
#if (BSP_IRQ_CFG_DMAC1_DMAC != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)DMAC1_DMAC_IRQn) = ELC_EVENT_DMAC1_DMAC;
    NVIC_SetPriority(DMAC1_DMAC_IRQn, BSP_IRQ_CFG_DMAC1_DMAC);
#endif
#if (BSP_IRQ_CFG_DMAC2_DMAC != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)DMAC2_DMAC_IRQn) = ELC_EVENT_DMAC2_DMAC;
    NVIC_SetPriority(DMAC2_DMAC_IRQn, BSP_IRQ_CFG_DMAC2_DMAC);
#endif
#if (BSP_IRQ_CFG_DMAC3_DMAC != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)DMAC3_DMAC_IRQn) = ELC_EVENT_DMAC3_DMAC;
    NVIC_SetPriority(DMAC3_DMAC_IRQn, BSP_IRQ_CFG_DMAC3_DMAC);
#endif
#if (BSP_IRQ_CFG_DMAC4_DMAC != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)DMAC4_DMAC_IRQn) = ELC_EVENT_DMAC4_DMAC;
    NVIC_SetPriority(DMAC4_DMAC_IRQn, BSP_IRQ_CFG_DMAC4_DMAC);
#endif
#if (BSP_IRQ_CFG_DMAC5_DMAC != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)DMAC5_DMAC_IRQn) = ELC_EVENT_DMAC5_DMAC;
    NVIC_SetPriority(DMAC5_DMAC_IRQn, BSP_IRQ_CFG_DMAC5_DMAC);
#endif
#if (BSP_IRQ_CFG_DMAC6_DMAC != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)DMAC6_DMAC_IRQn) = ELC_EVENT_DMAC6_DMAC;
    NVIC_SetPriority(DMAC6_DMAC_IRQn, BSP_IRQ_CFG_DMAC6_DMAC);
#endif
#if (BSP_IRQ_CFG_DMAC7_DMAC != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)DMAC7_DMAC_IRQn) = ELC_EVENT_DMAC7_DMAC;
    NVIC_SetPriority(DMAC7_DMAC_IRQn, BSP_IRQ_CFG_DMAC7_DMAC);
#endif
#if (BSP_IRQ_CFG_DTC_TRANSFER != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)DTC_TRANSFER_IRQn) = ELC_EVENT_DTC_TRANSFER;
    NVIC_SetPriority(DTC_TRANSFER_IRQn, BSP_IRQ_CFG_DTC_TRANSFER);
#endif
#if (BSP_IRQ_CFG_DTC_COMPLETE != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)DTC_COMPLETE_IRQn) = ELC_EVENT_DTC_COMPLETE;
    NVIC_SetPriority(DTC_COMPLETE_IRQn, BSP_IRQ_CFG_DTC_COMPLETE);
#endif
#if (BSP_IRQ_CFG_DTC_DTC_END != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)DTC_DTC_END_IRQn) = ELC_EVENT_DTC_DTC_END;
    NVIC_SetPriority(DTC_DTC_END_IRQn, BSP_IRQ_CFG_DTC_DTC_END);
#endif
#if (BSP_IRQ_CFG_EXDMAC0_EXDMAC != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)EXDMAC0_EXDMAC_IRQn) = ELC_EVENT_EXDMAC0_EXDMAC;
    NVIC_SetPriority(EXDMAC0_EXDMAC_IRQn, BSP_IRQ_CFG_EXDMAC0_EXDMAC);
#endif
#if (BSP_IRQ_CFG_EXDMAC1_EXDMAC != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)EXDMAC1_EXDMAC_IRQn) = ELC_EVENT_EXDMAC1_EXDMAC;
    NVIC_SetPriority(EXDMAC1_EXDMAC_IRQn, BSP_IRQ_CFG_EXDMAC1_EXDMAC);
#endif
#if (BSP_IRQ_CFG_ICU_CANCELING_SNOOZE_MODE != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ICU_CANCELING_SNOOZE_MODE_IRQn) = ELC_EVENT_ICU_CANCELING_SNOOZE_MODE;
    NVIC_SetPriority(ICU_CANCELING_SNOOZE_MODE_IRQn, BSP_IRQ_CFG_ICU_CANCELING_SNOOZE_MODE);
#endif
#if (BSP_IRQ_CFG_FCU_FIFERR != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)FCU_FIFERR_IRQn) = ELC_EVENT_FCU_FIFERR;
    NVIC_SetPriority(FCU_FIFERR_IRQn, BSP_IRQ_CFG_FCU_FIFERR);
#endif
#if (BSP_IRQ_CFG_FCU_FRDYI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)FCU_FRDYI_IRQn) = ELC_EVENT_FCU_FRDYI;
    NVIC_SetPriority(FCU_FRDYI_IRQn, BSP_IRQ_CFG_FCU_FRDYI);
#endif
#if (BSP_IRQ_CFG_FCU_ECCERR != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)FCU_ECCERR_IRQn) = ELC_EVENT_FCU_ECCERR;
    NVIC_SetPriority(FCU_ECCERR_IRQn, BSP_IRQ_CFG_FCU_ECCERR);
#endif
#if (BSP_IRQ_CFG_LVD1_LVD1 != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)LVD1_LVD1_IRQn) = ELC_EVENT_LVD1_LVD1;
    NVIC_SetPriority(LVD1_LVD1_IRQn, BSP_IRQ_CFG_LVD1_LVD1);
#endif
#if (BSP_IRQ_CFG_LVD2_LVD2 != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)LVD2_LVD2_IRQn) = ELC_EVENT_LVD2_LVD2;
    NVIC_SetPriority(LVD2_LVD2_IRQn, BSP_IRQ_CFG_LVD2_LVD2);
#endif
#if (BSP_IRQ_CFG_MOSC_OSC_STOP != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)MOSC_OSC_STOP_IRQn) = ELC_EVENT_MOSC_OSC_STOP;
    NVIC_SetPriority(MOSC_OSC_STOP_IRQn, BSP_IRQ_CFG_MOSC_OSC_STOP);
#endif
#if (BSP_IRQ_CFG_CPUSYS_SNOOZE_MODE_ENTRY_FLAG != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)CPUSYS_SNOOZE_MODE_ENTRY_FLAG_IRQn) = ELC_EVENT_CPUSYS_SNOOZE_MODE_ENTRY_FLAG;
    NVIC_SetPriority(CPUSYS_SNOOZE_MODE_ENTRY_FLAG_IRQn, BSP_IRQ_CFG_CPUSYS_SNOOZE_MODE_ENTRY_FLAG);
#endif
#if (BSP_IRQ_CFG_AGT0_AGTI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)AGT0_AGTI_IRQn) = ELC_EVENT_AGT0_AGTI;
    NVIC_SetPriority(AGT0_AGTI_IRQn, BSP_IRQ_CFG_AGT0_AGTI);
#endif
#if (BSP_IRQ_CFG_AGT0_AGTCMAI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)AGT0_AGTCMAI_IRQn) = ELC_EVENT_AGT0_AGTCMAI;
    NVIC_SetPriority(AGT0_AGTCMAI_IRQn, BSP_IRQ_CFG_AGT0_AGTCMAI);
#endif
#if (BSP_IRQ_CFG_AGT0_AGTCMBI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)AGT0_AGTCMBI_IRQn) = ELC_EVENT_AGT0_AGTCMBI;
    NVIC_SetPriority(AGT0_AGTCMBI_IRQn, BSP_IRQ_CFG_AGT0_AGTCMBI);
#endif
#if (BSP_IRQ_CFG_AGT1_AGTI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)AGT1_AGTI_IRQn) = ELC_EVENT_AGT1_AGTI;
    NVIC_SetPriority(AGT1_AGTI_IRQn, BSP_IRQ_CFG_AGT1_AGTI);
#endif
#if (BSP_IRQ_CFG_AGT1_AGTCMAI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)AGT1_AGTCMAI_IRQn) = ELC_EVENT_AGT1_AGTCMAI;
    NVIC_SetPriority(AGT1_AGTCMAI_IRQn, BSP_IRQ_CFG_AGT1_AGTCMAI);
#endif
#if (BSP_IRQ_CFG_AGT1_AGTCMBI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)AGT1_AGTCMBI_IRQn) = ELC_EVENT_AGT1_AGTCMBI;
    NVIC_SetPriority(AGT1_AGTCMBI_IRQn, BSP_IRQ_CFG_AGT1_AGTCMBI);
#endif
#if (BSP_IRQ_CFG_IWDT_NMIUNDF_N != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)IWDT_NMIUNDF_N_IRQn) = ELC_EVENT_IWDT_NMIUNDF_N;
    NVIC_SetPriority(IWDT_NMIUNDF_N_IRQn, BSP_IRQ_CFG_IWDT_NMIUNDF_N);
#endif
#if (BSP_IRQ_CFG_CWDT_NMIUNDF_N != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)CWDT_NMIUNDF_N_IRQn) = ELC_EVENT_CWDT_NMIUNDF_N;
    NVIC_SetPriority(CWDT_NMIUNDF_N_IRQn, BSP_IRQ_CFG_CWDT_NMIUNDF_N);
#endif
#if (BSP_IRQ_CFG_RTC_ALM != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RTC_ALM_IRQn) = ELC_EVENT_RTC_ALM;
    NVIC_SetPriority(RTC_ALM_IRQn, BSP_IRQ_CFG_RTC_ALM);
#endif
#if (BSP_IRQ_CFG_RTC_PRD != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RTC_PRD_IRQn) = ELC_EVENT_RTC_PRD;
    NVIC_SetPriority(RTC_PRD_IRQn, BSP_IRQ_CFG_RTC_PRD);
#endif
#if (BSP_IRQ_CFG_RTC_CUP != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RTC_CUP_IRQn) = ELC_EVENT_RTC_CUP;
    NVIC_SetPriority(RTC_CUP_IRQn, BSP_IRQ_CFG_RTC_CUP);
#endif
#if (BSP_IRQ_CFG_S12AD0_ADI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)S12AD0_ADI_IRQn) = ELC_EVENT_S12AD0_ADI;
    NVIC_SetPriority(S12AD0_ADI_IRQn, BSP_IRQ_CFG_S12AD0_ADI);
#endif
#if (BSP_IRQ_CFG_S12AD0_GBADI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)S12AD0_GBADI_IRQn) = ELC_EVENT_S12AD0_GBADI;
    NVIC_SetPriority(S12AD0_GBADI_IRQn, BSP_IRQ_CFG_S12AD0_GBADI);
#endif
#if (BSP_IRQ_CFG_S12AD0_CMPAI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)S12AD0_CMPAI_IRQn) = ELC_EVENT_S12AD0_CMPAI;
    NVIC_SetPriority(S12AD0_CMPAI_IRQn, BSP_IRQ_CFG_S12AD0_CMPAI);
#endif
#if (BSP_IRQ_CFG_S12AD0_CMPBI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)S12AD0_CMPBI_IRQn) = ELC_EVENT_S12AD0_CMPBI;
    NVIC_SetPriority(S12AD0_CMPBI_IRQn, BSP_IRQ_CFG_S12AD0_CMPBI);
#endif
#if (BSP_IRQ_CFG_S12AD0_COMPARE_MATCH != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)S12AD0_COMPARE_MATCH_IRQn) = ELC_EVENT_S12AD0_COMPARE_MATCH;
    NVIC_SetPriority(S12AD0_COMPARE_MATCH_IRQn, BSP_IRQ_CFG_S12AD0_COMPARE_MATCH);
#endif
#if (BSP_IRQ_CFG_S12AD0_COMPARE_MISMATCH != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)S12AD0_COMPARE_MISMATCH_IRQn) = ELC_EVENT_S12AD0_COMPARE_MISMATCH;
    NVIC_SetPriority(S12AD0_COMPARE_MISMATCH_IRQn, BSP_IRQ_CFG_S12AD0_COMPARE_MISMATCH);
#endif
#if (BSP_IRQ_CFG_S12AD1_ADI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)S12AD1_ADI_IRQn) = ELC_EVENT_S12AD1_ADI;
    NVIC_SetPriority(S12AD1_ADI_IRQn, BSP_IRQ_CFG_S12AD1_ADI);
#endif
#if (BSP_IRQ_CFG_S12AD1_GBADI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)S12AD1_GBADI_IRQn) = ELC_EVENT_S12AD1_GBADI;
    NVIC_SetPriority(S12AD1_GBADI_IRQn, BSP_IRQ_CFG_S12AD1_GBADI);
#endif
#if (BSP_IRQ_CFG_S12AD1_CMPAI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)S12AD1_CMPAI_IRQn) = ELC_EVENT_S12AD1_CMPAI;
    NVIC_SetPriority(S12AD1_CMPAI_IRQn, BSP_IRQ_CFG_S12AD1_CMPAI);
#endif
#if (BSP_IRQ_CFG_S12AD1_CMPBI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)S12AD1_CMPBI_IRQn) = ELC_EVENT_S12AD1_CMPBI;
    NVIC_SetPriority(S12AD1_CMPBI_IRQn, BSP_IRQ_CFG_S12AD1_CMPBI);
#endif
#if (BSP_IRQ_CFG_S12AD1_COMPARE_MATCH != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)S12AD1_COMPARE_MATCH_IRQn) = ELC_EVENT_S12AD1_COMPARE_MATCH;
    NVIC_SetPriority(S12AD1_COMPARE_MATCH_IRQn, BSP_IRQ_CFG_S12AD1_COMPARE_MATCH);
#endif
#if (BSP_IRQ_CFG_S12AD1_COMPARE_MISMATCH != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)S12AD1_COMPARE_MISMATCH_IRQn) = ELC_EVENT_S12AD1_COMPARE_MISMATCH;
    NVIC_SetPriority(S12AD1_COMPARE_MISMATCH_IRQn, BSP_IRQ_CFG_S12AD1_COMPARE_MISMATCH);
#endif
#if (BSP_IRQ_CFG_COMP_OC0_COMP_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)COMP_OC0_COMP_IRQ_IRQn) = ELC_EVENT_COMP_OC0_COMP_IRQ;
    NVIC_SetPriority(COMP_OC0_COMP_IRQ_IRQn, BSP_IRQ_CFG_COMP_OC0_COMP_IRQ);
#endif
#if (BSP_IRQ_CFG_COMP_RD1_COMP_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)COMP_RD1_COMP_IRQ_IRQn) = ELC_EVENT_COMP_RD1_COMP_IRQ;
    NVIC_SetPriority(COMP_RD1_COMP_IRQ_IRQn, BSP_IRQ_CFG_COMP_RD1_COMP_IRQ);
#endif
#if (BSP_IRQ_CFG_COMP_RD2_COMP_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)COMP_RD2_COMP_IRQ_IRQn) = ELC_EVENT_COMP_RD2_COMP_IRQ;
    NVIC_SetPriority(COMP_RD2_COMP_IRQ_IRQn, BSP_IRQ_CFG_COMP_RD2_COMP_IRQ);
#endif
#if (BSP_IRQ_CFG_COMP_RD3_COMP_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)COMP_RD3_COMP_IRQ_IRQn) = ELC_EVENT_COMP_RD3_COMP_IRQ;
    NVIC_SetPriority(COMP_RD3_COMP_IRQ_IRQn, BSP_IRQ_CFG_COMP_RD3_COMP_IRQ);
#endif
#if (BSP_IRQ_CFG_COMP_RD4_COMP_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)COMP_RD4_COMP_IRQ_IRQn) = ELC_EVENT_COMP_RD4_COMP_IRQ;
    NVIC_SetPriority(COMP_RD4_COMP_IRQ_IRQn, BSP_IRQ_CFG_COMP_RD4_COMP_IRQ);
#endif
#if (BSP_IRQ_CFG_COMP_RD5_COMP_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)COMP_RD5_COMP_IRQ_IRQn) = ELC_EVENT_COMP_RD5_COMP_IRQ;
    NVIC_SetPriority(COMP_RD5_COMP_IRQ_IRQn, BSP_IRQ_CFG_COMP_RD5_COMP_IRQ);
#endif
#if (BSP_IRQ_CFG_USBFS_D0FIFO != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)USBFS_D0FIFO_IRQn) = ELC_EVENT_USBFS_D0FIFO;
    NVIC_SetPriority(USBFS_D0FIFO_IRQn, BSP_IRQ_CFG_USBFS_D0FIFO);
#endif
#if (BSP_IRQ_CFG_USBFS_D1FIFO != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)USBFS_D1FIFO_IRQn) = ELC_EVENT_USBFS_D1FIFO;
    NVIC_SetPriority(USBFS_D1FIFO_IRQn, BSP_IRQ_CFG_USBFS_D1FIFO);
#endif
#if (BSP_IRQ_CFG_USBFS_USBI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)USBFS_USBI_IRQn) = ELC_EVENT_USBFS_USBI;
    NVIC_SetPriority(USBFS_USBI_IRQn, BSP_IRQ_CFG_USBFS_USBI);
#endif
#if (BSP_IRQ_CFG_USBFS_USBR != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)USBFS_USBR_IRQn) = ELC_EVENT_USBFS_USBR;
    NVIC_SetPriority(USBFS_USBR_IRQn, BSP_IRQ_CFG_USBFS_USBR);
#endif
#if (BSP_IRQ_CFG_RIIC0_RXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RIIC0_RXI_IRQn) = ELC_EVENT_RIIC0_RXI;
    NVIC_SetPriority(RIIC0_RXI_IRQn, BSP_IRQ_CFG_RIIC0_RXI);
#endif
#if (BSP_IRQ_CFG_RIIC0_TXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RIIC0_TXI_IRQn) = ELC_EVENT_RIIC0_TXI;
    NVIC_SetPriority(RIIC0_TXI_IRQn, BSP_IRQ_CFG_RIIC0_TXI);
#endif
#if (BSP_IRQ_CFG_RIIC0_TEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RIIC0_TEI_IRQn) = ELC_EVENT_RIIC0_TEI;
    NVIC_SetPriority(RIIC0_TEI_IRQn, BSP_IRQ_CFG_RIIC0_TEI);
#endif
#if (BSP_IRQ_CFG_RIIC0_EEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RIIC0_EEI_IRQn) = ELC_EVENT_RIIC0_EEI;
    NVIC_SetPriority(RIIC0_EEI_IRQn, BSP_IRQ_CFG_RIIC0_EEI0);
#endif
#if (BSP_IRQ_CFG_RIIC0_WUI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RIIC0_WUI_IRQn) = ELC_EVENT_RIIC0_WUI;
    NVIC_SetPriority(RIIC0_WUI_IRQn, BSP_IRQ_CFG_RIIC0_WUI);
#endif
#if (BSP_IRQ_CFG_RIIC1_RXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RIIC1_RXI_IRQn) = ELC_EVENT_RIIC1_RXI;
    NVIC_SetPriority(RIIC1_RXI_IRQn, BSP_IRQ_CFG_RIIC1_RXI);
#endif
#if (BSP_IRQ_CFG_RIIC1_TXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RIIC1_TXI_IRQn) = ELC_EVENT_RIIC1_TXI;
    NVIC_SetPriority(RIIC1_TXI_IRQn, BSP_IRQ_CFG_RIIC1_TXI);
#endif
#if (BSP_IRQ_CFG_RIIC1_TEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RIIC1_TEI_IRQn) = ELC_EVENT_RIIC1_TEI;
    NVIC_SetPriority(RIIC1_TEI_IRQn, BSP_IRQ_CFG_RIIC1_TEI);
#endif
#if (BSP_IRQ_CFG_RIIC1_EEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RIIC1_EEI_IRQn) = ELC_EVENT_RIIC1_EEI;
    NVIC_SetPriority(RIIC1_EEI_IRQn, BSP_IRQ_CFG_RIIC1_EEI0);
#endif
#if (BSP_IRQ_CFG_RIIC2_RXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RIIC2_RXI_IRQn) = ELC_EVENT_RIIC2_RXI;
    NVIC_SetPriority(RIIC2_RXI_IRQn, BSP_IRQ_CFG_RIIC2_RXI);
#endif
#if (BSP_IRQ_CFG_RIIC2_TXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RIIC2_TXI_IRQn) = ELC_EVENT_RIIC2_TXI;
    NVIC_SetPriority(RIIC2_TXI_IRQn, BSP_IRQ_CFG_RIIC2_TXI);
#endif
#if (BSP_IRQ_CFG_RIIC2_TEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RIIC2_TEI_IRQn) = ELC_EVENT_RIIC2_TEI;
    NVIC_SetPriority(RIIC2_TEI_IRQn, BSP_IRQ_CFG_RIIC2_TEI);
#endif
#if (BSP_IRQ_CFG_RIIC2_EEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RIIC2_EEI_IRQn) = ELC_EVENT_RIIC2_EEI;
    NVIC_SetPriority(RIIC2_EEI_IRQn, BSP_IRQ_CFG_RIIC2_EEI0);
#endif
#if (BSP_IRQ_CFG_SSI0_SSITXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SSI0_SSITXI_IRQn) = ELC_EVENT_SSI0_SSITXI;
    NVIC_SetPriority(SSI0_SSITXI_IRQn, BSP_IRQ_CFG_SSI0_SSITXI);
#endif
#if (BSP_IRQ_CFG_SSI0_SSIRXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SSI0_SSIRXI_IRQn) = ELC_EVENT_SSI0_SSIRXI;
    NVIC_SetPriority(SSI0_SSIRXI_IRQn, BSP_IRQ_CFG_SSI0_SSIRXI);
#endif
#if (BSP_IRQ_CFG_SSI0_SSIRT != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SSI0_SSIRT_IRQn) = ELC_EVENT_SSI0_SSIRT;
    NVIC_SetPriority(SSI0_SSIRT_IRQn, BSP_IRQ_CFG_SSI0_SSIRT);
#endif
#if (BSP_IRQ_CFG_SSI0_SSIF != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SSI0_SSIF_IRQn) = ELC_EVENT_SSI0_SSIF;
    NVIC_SetPriority(SSI0_SSIF_IRQn, BSP_IRQ_CFG_SSI0_SSIF);
#endif
#if (BSP_IRQ_CFG_SSI1_SSITXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SSI1_SSITXI_IRQn) = ELC_EVENT_SSI1_SSITXI;
    NVIC_SetPriority(SSI1_SSITXI_IRQn, BSP_IRQ_CFG_SSI1_SSITXI);
#endif
#if (BSP_IRQ_CFG_SSI1_SSIRXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SSI1_SSIRXI_IRQn) = ELC_EVENT_SSI1_SSIRXI;
    NVIC_SetPriority(SSI1_SSIRXI_IRQn, BSP_IRQ_CFG_SSI1_SSIRXI);
#endif
#if (BSP_IRQ_CFG_SSI1_SSIRT != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SSI1_SSIRT_IRQn) = ELC_EVENT_SSI1_SSIRT;
    NVIC_SetPriority(SSI1_SSIRT_IRQn, BSP_IRQ_CFG_SSI1_SSIRT);
#endif
#if (BSP_IRQ_CFG_SSI1_SSIF != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SSI1_SSIF_IRQn) = ELC_EVENT_SSI1_SSIF;
    NVIC_SetPriority(SSI1_SSIF_IRQn, BSP_IRQ_CFG_SSI1_SSIF);
#endif
#if (BSP_IRQ_CFG_SRC_IDEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SRC_IDEI_IRQn) = ELC_EVENT_SRC_IDEI;
    NVIC_SetPriority(SRC_IDEI_IRQn, BSP_IRQ_CFG_SRC_IDEI);
#endif
#if (BSP_IRQ_CFG_SRC_ODFI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SRC_ODFI_IRQn) = ELC_EVENT_SRC_ODFI;
    NVIC_SetPriority(SRC_ODFI_IRQn, BSP_IRQ_CFG_SRC_ODFI);
#endif
#if (BSP_IRQ_CFG_SRC_OVF != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SRC_OVF_IRQn) = ELC_EVENT_SRC_OVF;
    NVIC_SetPriority(SRC_OVF_IRQn, BSP_IRQ_CFG_SRC_OVF);
#endif
#if (BSP_IRQ_CFG_SRC_UDF != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SRC_UDF_IRQn) = ELC_EVENT_SRC_UDF;
    NVIC_SetPriority(SRC_UDF_IRQn, BSP_IRQ_CFG_SRC_UDF);
#endif
#if (BSP_IRQ_CFG_SRC_CEF != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SRC_CEF_IRQn) = ELC_EVENT_SRC_CEF;
    NVIC_SetPriority(SRC_CEF_IRQn, BSP_IRQ_CFG_SRC_CEF);
#endif
#if (BSP_IRQ_CFG_PDC_PCDFI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PDC_PCDFI_IRQn) = ELC_EVENT_PDC_PCDFI;
    NVIC_SetPriority(PDC_PCDFI_IRQn, BSP_IRQ_CFG_PDC_PCDFI);
#endif
#if (BSP_IRQ_CFG_PDC_PCFEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PDC_PCFEI_IRQn) = ELC_EVENT_PDC_PCFEI;
    NVIC_SetPriority(PDC_PCFEI_IRQn, BSP_IRQ_CFG_PDC_PCFEI);
#endif
#if (BSP_IRQ_CFG_PDC_PCERI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)PDC_PCERI_IRQn) = ELC_EVENT_PDC_PCERI;
    NVIC_SetPriority(PDC_PCERI_IRQn, BSP_IRQ_CFG_PDC_PCERI);
#endif
#if (BSP_IRQ_CFG_CTSU_CTSUWR != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)CTSU_CTSUWR_IRQn) = ELC_EVENT_CTSU_CTSUWR;
    NVIC_SetPriority(CTSU_CTSUWR_IRQn, BSP_IRQ_CFG_CTSU_CTSUWR);
#endif
#if (BSP_IRQ_CFG_CTSU_CTSURD != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)CTSU_CTSURD_IRQn) = ELC_EVENT_CTSU_CTSURD;
    NVIC_SetPriority(CTSU_CTSURD_IRQn, BSP_IRQ_CFG_CTSU_CTSURD);
#endif
#if (BSP_IRQ_CFG_CTSU_CTSUFN != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)CTSU_CTSUFN_IRQn) = ELC_EVENT_CTSU_CTSUFN;
    NVIC_SetPriority(CTSU_CTSUFN_IRQn, BSP_IRQ_CFG_CTSU_CTSUFN);
#endif
#if (BSP_IRQ_CFG_KEY_INTKR != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)KEY_INTKR_IRQn) = ELC_EVENT_KEY_INTKR;
    NVIC_SetPriority(KEY_INTKR_IRQn, BSP_IRQ_CFG_KEY_INTKR);
#endif
#if (BSP_IRQ_CFG_DOC_DOPCF != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)DOC_DOPCF_IRQn) = ELC_EVENT_DOC_DOPCF;
    NVIC_SetPriority(DOC_DOPCF_IRQn, BSP_IRQ_CFG_DOC_DOPCF);
#endif
#if (BSP_IRQ_CFG_CAC_FERRF != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)CAC_FERRF_IRQn) = ELC_EVENT_CAC_FERRF;
    NVIC_SetPriority(CAC_FERRF_IRQn, BSP_IRQ_CFG_CAC_FERRF);
#endif
#if (BSP_IRQ_CFG_CAC_MENDF != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)CAC_MENDF_IRQn) = ELC_EVENT_CAC_MENDF;
    NVIC_SetPriority(CAC_MENDF_IRQn, BSP_IRQ_CFG_CAC_MENDF);
#endif
#if (BSP_IRQ_CFG_CAC_OVFF != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)CAC_OVFF_IRQn) = ELC_EVENT_CAC_OVFF;
    NVIC_SetPriority(CAC_OVFF_IRQn, BSP_IRQ_CFG_CAC_OVFF);
#endif
#if (BSP_IRQ_CFG_RCAN20_ERS != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RCAN20_ERS_IRQn) = ELC_EVENT_RCAN20_ERS;
    NVIC_SetPriority(RCAN20_ERS_IRQn, BSP_IRQ_CFG_RCAN20_ERS);
#endif
#if (BSP_IRQ_CFG_RCAN20_RXF != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RCAN20_RXF_IRQn) = ELC_EVENT_RCAN20_RXF;
    NVIC_SetPriority(RCAN20_RXF_IRQn, BSP_IRQ_CFG_RCAN20_RXF);
#endif
#if (BSP_IRQ_CFG_RCAN20_TXF != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RCAN20_TXF_IRQn) = ELC_EVENT_RCAN20_TXF;
    NVIC_SetPriority(RCAN20_TXF_IRQn, BSP_IRQ_CFG_RCAN20_TXF);
#endif
#if (BSP_IRQ_CFG_RCAN20_RXM != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RCAN20_RXM_IRQn) = ELC_EVENT_RCAN20_RXM;
    NVIC_SetPriority(RCAN20_RXM_IRQn, BSP_IRQ_CFG_RCAN20_RXM);
#endif
#if (BSP_IRQ_CFG_RCAN20_TXM != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RCAN20_TXM_IRQn) = ELC_EVENT_RCAN20_TXM;
    NVIC_SetPriority(RCAN20_TXM_IRQn, BSP_IRQ_CFG_RCAN20_TXM);
#endif
#if (BSP_IRQ_CFG_RCAN21_ERS != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RCAN21_ERS_IRQn) = ELC_EVENT_RCAN21_ERS;
    NVIC_SetPriority(RCAN21_ERS_IRQn, BSP_IRQ_CFG_RCAN21_ERS);
#endif
#if (BSP_IRQ_CFG_RCAN21_RXF != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RCAN21_RXF_IRQn) = ELC_EVENT_RCAN21_RXF;
    NVIC_SetPriority(RCAN21_RXF_IRQn, BSP_IRQ_CFG_RCAN21_RXF);
#endif
#if (BSP_IRQ_CFG_RCAN21_TXF != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RCAN21_TXF_IRQn) = ELC_EVENT_RCAN21_TXF;
    NVIC_SetPriority(RCAN21_TXF_IRQn, BSP_IRQ_CFG_RCAN21_TXF);
#endif
#if (BSP_IRQ_CFG_RCAN21_RXM != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RCAN21_RXM_IRQn) = ELC_EVENT_RCAN21_RXM;
    NVIC_SetPriority(RCAN21_RXM_IRQn, BSP_IRQ_CFG_RCAN21_RXM);
#endif
#if (BSP_IRQ_CFG_RCAN21_TXM != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RCAN21_TXM_IRQn) = ELC_EVENT_RCAN21_TXM;
    NVIC_SetPriority(RCAN21_TXM_IRQn, BSP_IRQ_CFG_RCAN21_TXM);
#endif
#if (BSP_IRQ_CFG_GPIO_PORT_GROUP_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPIO_PORT_GROUP_A_IRQn) = ELC_EVENT_GPIO_PORT_GROUP_A;
    NVIC_SetPriority(GPIO_PORT_GROUP_A_IRQn, BSP_IRQ_CFG_GPIO_PORT_GROUP_A);
#endif
#if (BSP_IRQ_CFG_GPIO_PORT_GROUP_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPIO_PORT_GROUP_B_IRQn) = ELC_EVENT_GPIO_PORT_GROUP_B;
    NVIC_SetPriority(GPIO_PORT_GROUP_B_IRQn, BSP_IRQ_CFG_GPIO_PORT_GROUP_B);
#endif
#if (BSP_IRQ_CFG_GPIO_PORT_GROUP_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPIO_PORT_GROUP_C_IRQn) = ELC_EVENT_GPIO_PORT_GROUP_C;
    NVIC_SetPriority(GPIO_PORT_GROUP_C_IRQn, BSP_IRQ_CFG_GPIO_PORT_GROUP_C);
#endif
#if (BSP_IRQ_CFG_GPIO_PORT_GROUP_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPIO_PORT_GROUP_D_IRQn) = ELC_EVENT_GPIO_PORT_GROUP_D;
    NVIC_SetPriority(GPIO_PORT_GROUP_D_IRQn, BSP_IRQ_CFG_GPIO_PORT_GROUP_D);
#endif
#if (BSP_IRQ_CFG_ELC0_SOFTWARE_EVENT != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ELC0_SOFTWARE_EVENT_IRQn) = ELC_EVENT_ELC0_SOFTWARE_EVENT;
    NVIC_SetPriority(ELC0_SOFTWARE_EVENT_IRQn, BSP_IRQ_CFG_ELC0_SOFTWARE_EVENT);
#endif
#if (BSP_IRQ_CFG_ELC1_SOFTWARE_EVENT != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ELC1_SOFTWARE_EVENT_IRQn) = ELC_EVENT_ELC1_SOFTWARE_EVENT;
    NVIC_SetPriority(ELC1_SOFTWARE_EVENT_IRQn, BSP_IRQ_CFG_ELC1_SOFTWARE_EVENT);
#endif
#if (BSP_IRQ_CFG_POEG_GROUP_EVENT0 != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)POEG_GROUP_EVENT0_IRQn) = ELC_EVENT_POEG_GROUP_EVENT0;
    NVIC_SetPriority(POEG_GROUP_EVENT0_IRQn, BSP_IRQ_CFG_POEG_GROUP_EVENT0);
#endif
#if (BSP_IRQ_CFG_POEG_GROUP_EVENT1 != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)POEG_GROUP_EVENT1_IRQn) = ELC_EVENT_POEG_GROUP_EVENT1;
    NVIC_SetPriority(POEG_GROUP_EVENT1_IRQn, BSP_IRQ_CFG_POEG_GROUP_EVENT1);
#endif
#if (BSP_IRQ_CFG_POEG_GROUP_EVENT2 != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)POEG_GROUP_EVENT2_IRQn) = ELC_EVENT_POEG_GROUP_EVENT2;
    NVIC_SetPriority(POEG_GROUP_EVENT2_IRQn, BSP_IRQ_CFG_POEG_GROUP_EVENT2);
#endif
#if (BSP_IRQ_CFG_POEG_GROUP_EVENT3 != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)POEG_GROUP_EVENT3_IRQn) = ELC_EVENT_POEG_GROUP_EVENT3;
    NVIC_SetPriority(POEG_GROUP_EVENT3_IRQn, BSP_IRQ_CFG_POEG_GROUP_EVENT3);
#endif
#if (BSP_IRQ_CFG_GPT0_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT0_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT0_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT0_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT0_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT0_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT0_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT0_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT0_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT0_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT0_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT0_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT0_COMPARE_INT_C;
    NVIC_SetPriority(GPT0_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT0_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT0_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT0_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT0_COMPARE_INT_D;
    NVIC_SetPriority(GPT0_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT0_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT0_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT0_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT0_COMPARE_INT_E;
    NVIC_SetPriority(GPT0_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT0_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT0_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT0_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT0_COMPARE_INT_F;
    NVIC_SetPriority(GPT0_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT0_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT0_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT0_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT0_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT0_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT0_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT0_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT0_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT0_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT0_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT0_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT0_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT0_AD_TRIG_A_IRQn) = ELC_EVENT_GPT0_AD_TRIG_A;
    NVIC_SetPriority(GPT0_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT0_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT0_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT0_AD_TRIG_B_IRQn) = ELC_EVENT_GPT0_AD_TRIG_B;
    NVIC_SetPriority(GPT0_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT0_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT1_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT1_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT1_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT1_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT1_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT1_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT1_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT1_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT1_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT1_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT1_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT1_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT1_COMPARE_INT_C;
    NVIC_SetPriority(GPT1_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT1_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT1_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT1_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT1_COMPARE_INT_D;
    NVIC_SetPriority(GPT1_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT1_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT1_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT1_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT1_COMPARE_INT_E;
    NVIC_SetPriority(GPT1_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT1_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT1_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT1_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT1_COMPARE_INT_F;
    NVIC_SetPriority(GPT1_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT1_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT1_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT1_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT1_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT1_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT1_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT1_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT1_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT1_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT1_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT1_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT1_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT1_AD_TRIG_A_IRQn) = ELC_EVENT_GPT1_AD_TRIG_A;
    NVIC_SetPriority(GPT1_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT1_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT1_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT1_AD_TRIG_B_IRQn) = ELC_EVENT_GPT1_AD_TRIG_B;
    NVIC_SetPriority(GPT1_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT1_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT2_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT2_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT2_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT2_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT2_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT2_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT2_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT2_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT2_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT2_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT2_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT2_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT2_COMPARE_INT_C;
    NVIC_SetPriority(GPT2_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT2_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT2_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT2_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT2_COMPARE_INT_D;
    NVIC_SetPriority(GPT2_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT2_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT2_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT2_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT2_COMPARE_INT_E;
    NVIC_SetPriority(GPT2_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT2_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT2_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT2_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT2_COMPARE_INT_F;
    NVIC_SetPriority(GPT2_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT2_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT2_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT2_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT2_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT2_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT2_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT2_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT2_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT2_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT2_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT2_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT2_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT2_AD_TRIG_A_IRQn) = ELC_EVENT_GPT2_AD_TRIG_A;
    NVIC_SetPriority(GPT2_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT2_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT2_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT2_AD_TRIG_B_IRQn) = ELC_EVENT_GPT2_AD_TRIG_B;
    NVIC_SetPriority(GPT2_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT2_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT3_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT3_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT3_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT3_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT3_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT3_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT3_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT3_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT3_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT3_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT3_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT3_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT3_COMPARE_INT_C;
    NVIC_SetPriority(GPT3_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT3_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT3_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT3_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT3_COMPARE_INT_D;
    NVIC_SetPriority(GPT3_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT3_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT3_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT3_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT3_COMPARE_INT_E;
    NVIC_SetPriority(GPT3_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT3_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT3_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT3_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT3_COMPARE_INT_F;
    NVIC_SetPriority(GPT3_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT3_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT3_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT3_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT3_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT3_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT3_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT3_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT3_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT3_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT3_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT3_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT3_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT3_AD_TRIG_A_IRQn) = ELC_EVENT_GPT3_AD_TRIG_A;
    NVIC_SetPriority(GPT3_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT3_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT3_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT3_AD_TRIG_B_IRQn) = ELC_EVENT_GPT3_AD_TRIG_B;
    NVIC_SetPriority(GPT3_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT3_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT4_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT4_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT4_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT4_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT4_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT4_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT4_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT4_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT4_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT4_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT4_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT4_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT4_COMPARE_INT_C;
    NVIC_SetPriority(GPT4_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT4_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT4_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT4_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT4_COMPARE_INT_D;
    NVIC_SetPriority(GPT4_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT4_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT4_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT4_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT4_COMPARE_INT_E;
    NVIC_SetPriority(GPT4_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT4_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT4_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT4_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT4_COMPARE_INT_F;
    NVIC_SetPriority(GPT4_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT4_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT4_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT4_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT4_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT4_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT4_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT4_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT4_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT4_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT4_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT4_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT4_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT4_AD_TRIG_A_IRQn) = ELC_EVENT_GPT4_AD_TRIG_A;
    NVIC_SetPriority(GPT4_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT4_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT4_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT4_AD_TRIG_B_IRQn) = ELC_EVENT_GPT4_AD_TRIG_B;
    NVIC_SetPriority(GPT4_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT4_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT5_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT5_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT5_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT5_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT5_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT5_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT5_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT5_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT5_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT5_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT5_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT5_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT5_COMPARE_INT_C;
    NVIC_SetPriority(GPT5_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT5_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT5_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT5_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT5_COMPARE_INT_D;
    NVIC_SetPriority(GPT5_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT5_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT5_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT5_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT5_COMPARE_INT_E;
    NVIC_SetPriority(GPT5_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT5_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT5_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT5_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT5_COMPARE_INT_F;
    NVIC_SetPriority(GPT5_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT5_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT5_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT5_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT5_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT5_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT5_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT5_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT5_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT5_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT5_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT5_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT5_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT5_AD_TRIG_A_IRQn) = ELC_EVENT_GPT5_AD_TRIG_A;
    NVIC_SetPriority(GPT5_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT5_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT5_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT5_AD_TRIG_B_IRQn) = ELC_EVENT_GPT5_AD_TRIG_B;
    NVIC_SetPriority(GPT5_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT5_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT6_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT6_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT6_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT6_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT6_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT6_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT6_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT6_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT6_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT6_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT6_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT6_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT6_COMPARE_INT_C;
    NVIC_SetPriority(GPT6_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT6_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT6_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT6_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT6_COMPARE_INT_D;
    NVIC_SetPriority(GPT6_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT6_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT6_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT6_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT6_COMPARE_INT_E;
    NVIC_SetPriority(GPT6_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT6_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT6_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT6_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT6_COMPARE_INT_F;
    NVIC_SetPriority(GPT6_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT6_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT6_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT6_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT6_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT6_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT6_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT6_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT6_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT6_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT6_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT6_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT6_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT6_AD_TRIG_A_IRQn) = ELC_EVENT_GPT6_AD_TRIG_A;
    NVIC_SetPriority(GPT6_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT6_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT6_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT6_AD_TRIG_B_IRQn) = ELC_EVENT_GPT6_AD_TRIG_B;
    NVIC_SetPriority(GPT6_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT6_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT7_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT7_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT7_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT7_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT7_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT7_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT7_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT7_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT7_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT7_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT7_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT7_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT7_COMPARE_INT_C;
    NVIC_SetPriority(GPT7_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT7_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT7_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT7_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT7_COMPARE_INT_D;
    NVIC_SetPriority(GPT7_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT7_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT7_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT7_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT7_COMPARE_INT_E;
    NVIC_SetPriority(GPT7_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT7_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT7_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT7_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT7_COMPARE_INT_F;
    NVIC_SetPriority(GPT7_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT7_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT7_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT7_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT7_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT7_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT7_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT7_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT7_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT7_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT7_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT7_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT7_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT7_AD_TRIG_A_IRQn) = ELC_EVENT_GPT7_AD_TRIG_A;
    NVIC_SetPriority(GPT7_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT7_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT7_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT7_AD_TRIG_B_IRQn) = ELC_EVENT_GPT7_AD_TRIG_B;
    NVIC_SetPriority(GPT7_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT7_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT8_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT8_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT8_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT8_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT8_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT8_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT8_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT8_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT8_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT8_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT8_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT8_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT8_COMPARE_INT_C;
    NVIC_SetPriority(GPT8_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT8_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT8_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT8_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT8_COMPARE_INT_D;
    NVIC_SetPriority(GPT8_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT8_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT8_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT8_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT8_COMPARE_INT_E;
    NVIC_SetPriority(GPT8_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT8_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT8_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT8_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT8_COMPARE_INT_F;
    NVIC_SetPriority(GPT8_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT8_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT8_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT8_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT8_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT8_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT8_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT8_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT8_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT8_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT8_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT8_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT8_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT8_AD_TRIG_A_IRQn) = ELC_EVENT_GPT8_AD_TRIG_A;
    NVIC_SetPriority(GPT8_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT8_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT8_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT8_AD_TRIG_B_IRQn) = ELC_EVENT_GPT8_AD_TRIG_B;
    NVIC_SetPriority(GPT8_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT8_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT9_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT9_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT9_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT9_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT9_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT9_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT9_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT9_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT9_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT9_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT9_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT9_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT9_COMPARE_INT_C;
    NVIC_SetPriority(GPT9_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT9_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT9_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT9_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT9_COMPARE_INT_D;
    NVIC_SetPriority(GPT9_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT9_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT9_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT9_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT9_COMPARE_INT_E;
    NVIC_SetPriority(GPT9_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT9_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT9_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT9_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT9_COMPARE_INT_F;
    NVIC_SetPriority(GPT9_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT9_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT9_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT9_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT9_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT9_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT9_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT9_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT9_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT9_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT9_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT9_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT9_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT9_AD_TRIG_A_IRQn) = ELC_EVENT_GPT9_AD_TRIG_A;
    NVIC_SetPriority(GPT9_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT9_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT9_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT9_AD_TRIG_B_IRQn) = ELC_EVENT_GPT9_AD_TRIG_B;
    NVIC_SetPriority(GPT9_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT9_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT10_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT10_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT10_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT10_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT10_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT10_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT10_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT10_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT10_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT10_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT10_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT10_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT10_COMPARE_INT_C;
    NVIC_SetPriority(GPT10_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT10_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT10_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT10_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT10_COMPARE_INT_D;
    NVIC_SetPriority(GPT10_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT10_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT10_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT10_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT10_COMPARE_INT_E;
    NVIC_SetPriority(GPT10_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT10_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT10_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT10_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT10_COMPARE_INT_F;
    NVIC_SetPriority(GPT10_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT10_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT10_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT10_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT10_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT10_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT10_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT10_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT10_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT10_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT10_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT10_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT10_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT10_AD_TRIG_A_IRQn) = ELC_EVENT_GPT10_AD_TRIG_A;
    NVIC_SetPriority(GPT10_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT10_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT10_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT10_AD_TRIG_B_IRQn) = ELC_EVENT_GPT10_AD_TRIG_B;
    NVIC_SetPriority(GPT10_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT10_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT11_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT11_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT11_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT11_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT11_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT11_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT11_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT11_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT11_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT11_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT11_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT11_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT11_COMPARE_INT_C;
    NVIC_SetPriority(GPT11_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT11_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT11_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT11_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT11_COMPARE_INT_D;
    NVIC_SetPriority(GPT11_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT11_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT11_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT11_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT11_COMPARE_INT_E;
    NVIC_SetPriority(GPT11_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT11_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT11_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT11_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT11_COMPARE_INT_F;
    NVIC_SetPriority(GPT11_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT11_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT11_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT11_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT11_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT11_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT11_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT11_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT11_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT11_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT11_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT11_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT11_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT11_AD_TRIG_A_IRQn) = ELC_EVENT_GPT11_AD_TRIG_A;
    NVIC_SetPriority(GPT11_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT11_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT11_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT11_AD_TRIG_B_IRQn) = ELC_EVENT_GPT11_AD_TRIG_B;
    NVIC_SetPriority(GPT11_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT11_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT12_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT12_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT12_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT12_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT12_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT12_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT12_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT12_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT12_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT12_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT12_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT12_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT12_COMPARE_INT_C;
    NVIC_SetPriority(GPT12_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT12_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT12_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT12_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT12_COMPARE_INT_D;
    NVIC_SetPriority(GPT12_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT12_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT12_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT12_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT12_COMPARE_INT_E;
    NVIC_SetPriority(GPT12_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT12_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT12_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT12_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT12_COMPARE_INT_F;
    NVIC_SetPriority(GPT12_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT12_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT12_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT12_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT12_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT12_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT12_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT12_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT12_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT12_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT12_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT12_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT12_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT12_AD_TRIG_A_IRQn) = ELC_EVENT_GPT12_AD_TRIG_A;
    NVIC_SetPriority(GPT12_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT12_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT12_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT12_AD_TRIG_B_IRQn) = ELC_EVENT_GPT12_AD_TRIG_B;
    NVIC_SetPriority(GPT12_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT12_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT13_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT13_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT13_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT13_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT13_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT13_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT13_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT13_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT13_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT13_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT13_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT13_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT13_COMPARE_INT_C;
    NVIC_SetPriority(GPT13_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT13_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT13_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT13_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT13_COMPARE_INT_D;
    NVIC_SetPriority(GPT13_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT13_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT13_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT13_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT13_COMPARE_INT_E;
    NVIC_SetPriority(GPT13_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT13_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT13_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT13_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT13_COMPARE_INT_F;
    NVIC_SetPriority(GPT13_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT13_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT13_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT13_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT13_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT13_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT13_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT13_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT13_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT13_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT13_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT13_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT13_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT13_AD_TRIG_A_IRQn) = ELC_EVENT_GPT13_AD_TRIG_A;
    NVIC_SetPriority(GPT13_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT13_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT13_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT13_AD_TRIG_B_IRQn) = ELC_EVENT_GPT13_AD_TRIG_B;
    NVIC_SetPriority(GPT13_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT13_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT14_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT14_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT14_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT14_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT14_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT14_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT14_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT14_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT14_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT14_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT14_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT14_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT14_COMPARE_INT_C;
    NVIC_SetPriority(GPT14_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT14_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT14_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT14_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT14_COMPARE_INT_D;
    NVIC_SetPriority(GPT14_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT14_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT14_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT14_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT14_COMPARE_INT_E;
    NVIC_SetPriority(GPT14_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT14_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT14_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT14_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT14_COMPARE_INT_F;
    NVIC_SetPriority(GPT14_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT14_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT14_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT14_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT14_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT14_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT14_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT14_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT14_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT14_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT14_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT14_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT14_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT14_AD_TRIG_A_IRQn) = ELC_EVENT_GPT14_AD_TRIG_A;
    NVIC_SetPriority(GPT14_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT14_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT14_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT14_AD_TRIG_B_IRQn) = ELC_EVENT_GPT14_AD_TRIG_B;
    NVIC_SetPriority(GPT14_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT14_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT15_CAPTURE_COMPARE_INT_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT15_CAPTURE_COMPARE_INT_A_IRQn) = ELC_EVENT_GPT15_CAPTURE_COMPARE_INT_A;
    NVIC_SetPriority(GPT15_CAPTURE_COMPARE_INT_A_IRQn, BSP_IRQ_CFG_GPT15_CAPTURE_COMPARE_INT_A);
#endif
#if (BSP_IRQ_CFG_GPT15_CAPTURE_COMPARE_INT_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT15_CAPTURE_COMPARE_INT_B_IRQn) = ELC_EVENT_GPT15_CAPTURE_COMPARE_INT_B;
    NVIC_SetPriority(GPT15_CAPTURE_COMPARE_INT_B_IRQn, BSP_IRQ_CFG_GPT15_CAPTURE_COMPARE_INT_B);
#endif
#if (BSP_IRQ_CFG_GPT15_COMPARE_INT_C != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT15_COMPARE_INT_C_IRQn) = ELC_EVENT_GPT15_COMPARE_INT_C;
    NVIC_SetPriority(GPT15_COMPARE_INT_C_IRQn, BSP_IRQ_CFG_GPT15_COMPARE_INT_C);
#endif
#if (BSP_IRQ_CFG_GPT15_COMPARE_INT_D != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT15_COMPARE_INT_D_IRQn) = ELC_EVENT_GPT15_COMPARE_INT_D;
    NVIC_SetPriority(GPT15_COMPARE_INT_D_IRQn, BSP_IRQ_CFG_GPT15_COMPARE_INT_D);
#endif
#if (BSP_IRQ_CFG_GPT15_COMPARE_INT_E != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT15_COMPARE_INT_E_IRQn) = ELC_EVENT_GPT15_COMPARE_INT_E;
    NVIC_SetPriority(GPT15_COMPARE_INT_E_IRQn, BSP_IRQ_CFG_GPT15_COMPARE_INT_E);
#endif
#if (BSP_IRQ_CFG_GPT15_COMPARE_INT_F != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT15_COMPARE_INT_F_IRQn) = ELC_EVENT_GPT15_COMPARE_INT_F;
    NVIC_SetPriority(GPT15_COMPARE_INT_F_IRQn, BSP_IRQ_CFG_GPT15_COMPARE_INT_F);
#endif
#if (BSP_IRQ_CFG_GPT15_COUNTER_OVERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT15_COUNTER_OVERFLOW_IRQn) = ELC_EVENT_GPT15_COUNTER_OVERFLOW;
    NVIC_SetPriority(GPT15_COUNTER_OVERFLOW_IRQn, BSP_IRQ_CFG_GPT15_COUNTER_OVERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT15_COUNTER_UNDERFLOW != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT15_COUNTER_UNDERFLOW_IRQn) = ELC_EVENT_GPT15_COUNTER_UNDERFLOW;
    NVIC_SetPriority(GPT15_COUNTER_UNDERFLOW_IRQn, BSP_IRQ_CFG_GPT15_COUNTER_UNDERFLOW);
#endif
#if (BSP_IRQ_CFG_GPT15_AD_TRIG_A != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT15_AD_TRIG_A_IRQn) = ELC_EVENT_GPT15_AD_TRIG_A;
    NVIC_SetPriority(GPT15_AD_TRIG_A_IRQn, BSP_IRQ_CFG_GPT15_AD_TRIG_A);
#endif
#if (BSP_IRQ_CFG_GPT15_AD_TRIG_B != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT15_AD_TRIG_B_IRQn) = ELC_EVENT_GPT15_AD_TRIG_B;
    NVIC_SetPriority(GPT15_AD_TRIG_B_IRQn, BSP_IRQ_CFG_GPT15_AD_TRIG_B);
#endif
#if (BSP_IRQ_CFG_GPT_UVW_EDGE != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)GPT_UVW_EDGE_IRQn) = ELC_EVENT_GPT_UVW_EDGE;
    NVIC_SetPriority(GPT_UVW_EDGE_IRQn, BSP_IRQ_CFG_GPT_UVW_EDGE);
#endif
#if (BSP_IRQ_CFG_ETHER_IPLS != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_IPLS_IRQn) = ELC_EVENT_ETHER_IPLS;
    NVIC_SetPriority(ETHER_IPLS_IRQn, BSP_IRQ_CFG_ETHER_IPLS);
#endif
#if (BSP_IRQ_CFG_ETHER_MINT != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_MINT_IRQn) = ELC_EVENT_ETHER_MINT;
    NVIC_SetPriority(ETHER_MINT_IRQn, BSP_IRQ_CFG_ETHER_MINT);
#endif
#if (BSP_IRQ_CFG_ETHER_PINT != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_PINT_IRQn) = ELC_EVENT_ETHER_PINT;
    NVIC_SetPriority(ETHER_PINT_IRQn, BSP_IRQ_CFG_ETHER_PINT);
#endif
#if (BSP_IRQ_CFG_ETHER_EINT0 != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_EINT0_IRQn) = ELC_EVENT_ETHER_EINT0;
    NVIC_SetPriority(ETHER_EINT0_IRQn, BSP_IRQ_CFG_ETHER_EINT0);
#endif
#if (BSP_IRQ_CFG_ETHER_EINT1 != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_EINT1_IRQn) = ELC_EVENT_ETHER_EINT1;
    NVIC_SetPriority(ETHER_EINT1_IRQn, BSP_IRQ_CFG_ETHER_EINT1);
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER0_RISE != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_ETHER0_RISE_IRQn) = ELC_EVENT_ETHER_ETHER0_RISE;
    NVIC_SetPriority(ETHER_ETHER0_RISE_IRQn, BSP_IRQ_CFG_ETHER_ETHER0_RISE);
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER1_RISE != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_ETHER1_RISE_IRQn) = ELC_EVENT_ETHER_ETHER1_RISE;
    NVIC_SetPriority(ETHER_ETHER1_RISE_IRQn, BSP_IRQ_CFG_ETHER_ETHER1_RISE);
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER2_RISE != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_ETHER2_RISE_IRQn) = ELC_EVENT_ETHER_ETHER2_RISE;
    NVIC_SetPriority(ETHER_ETHER2_RISE_IRQn, BSP_IRQ_CFG_ETHER_ETHER2_RISE);
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER3_RISE != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_ETHER3_RISE_IRQn) = ELC_EVENT_ETHER_ETHER3_RISE;
    NVIC_SetPriority(ETHER_ETHER3_RISE_IRQn, BSP_IRQ_CFG_ETHER_ETHER3_RISE);
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER4_RISE != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_ETHER4_RISE_IRQn) = ELC_EVENT_ETHER_ETHER4_RISE;
    NVIC_SetPriority(ETHER_ETHER4_RISE_IRQn, BSP_IRQ_CFG_ETHER_ETHER4_RISE);
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER5_RISE != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_ETHER5_RISE_IRQn) = ELC_EVENT_ETHER_ETHER5_RISE;
    NVIC_SetPriority(ETHER_ETHER5_RISE_IRQn, BSP_IRQ_CFG_ETHER_ETHER5_RISE);
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER0_FALL != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_ETHER0_FALL_IRQn) = ELC_EVENT_ETHER_ETHER0_FALL;
    NVIC_SetPriority(ETHER_ETHER0_FALL_IRQn, BSP_IRQ_CFG_ETHER_ETHER0_FALL);
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER1_FALL != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_ETHER1_FALL_IRQn) = ELC_EVENT_ETHER_ETHER1_FALL;
    NVIC_SetPriority(ETHER_ETHER1_FALL_IRQn, BSP_IRQ_CFG_ETHER_ETHER1_FALL);
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER2_FALL != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_ETHER2_FALL_IRQn) = ELC_EVENT_ETHER_ETHER2_FALL;
    NVIC_SetPriority(ETHER_ETHER2_FALL_IRQn, BSP_IRQ_CFG_ETHER_ETHER2_FALL);
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER3_FALL != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_ETHER3_FALL_IRQn) = ELC_EVENT_ETHER_ETHER3_FALL;
    NVIC_SetPriority(ETHER_ETHER3_FALL_IRQn, BSP_IRQ_CFG_ETHER_ETHER3_FALL);
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER4_FALL != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_ETHER4_FALL_IRQn) = ELC_EVENT_ETHER_ETHER4_FALL;
    NVIC_SetPriority(ETHER_ETHER4_FALL_IRQn, BSP_IRQ_CFG_ETHER_ETHER4_FALL);
#endif
#if (BSP_IRQ_CFG_ETHER_ETHER5_FALL != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)ETHER_ETHER5_FALL_IRQn) = ELC_EVENT_ETHER_ETHER5_FALL;
    NVIC_SetPriority(ETHER_ETHER5_FALL_IRQn, BSP_IRQ_CFG_ETHER_ETHER5_FALL);
#endif
#if (BSP_IRQ_CFG_USBHS_D0FIFO != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)USBHS_D0FIFO_IRQn) = ELC_EVENT_USBHS_D0FIFO;
    NVIC_SetPriority(USBHS_D0FIFO_IRQn, BSP_IRQ_CFG_USBHS_D0FIFO);
#endif
#if (BSP_IRQ_CFG_USBHS_D1FIFO != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)USBHS_D1FIFO_IRQn) = ELC_EVENT_USBHS_D1FIFO;
    NVIC_SetPriority(USBHS_D1FIFO_IRQn, BSP_IRQ_CFG_USBHS_D1FIFO);
#endif
#if (BSP_IRQ_CFG_USBHS_USBIR != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)USBHS_USBIR_IRQn) = ELC_EVENT_USBHS_USBIR;
    NVIC_SetPriority(USBHS_USBIR_IRQn, BSP_IRQ_CFG_USBHS_USBIR);
#endif
#if (BSP_IRQ_CFG_SCI0_RXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI0_RXI_IRQn) = ELC_EVENT_SCI0_RXI;
    NVIC_SetPriority(SCI0_RXI_IRQn, BSP_IRQ_CFG_SCI0_RXI);
#endif
#if (BSP_IRQ_CFG_SCI0_TXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI0_TXI_IRQn) = ELC_EVENT_SCI0_TXI;
    NVIC_SetPriority(SCI0_TXI_IRQn, BSP_IRQ_CFG_SCI0_TXI);
#endif
#if (BSP_IRQ_CFG_SCI0_TEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI0_TEI_IRQn) = ELC_EVENT_SCI0_TEI;
    NVIC_SetPriority(SCI0_TEI_IRQn, BSP_IRQ_CFG_SCI0_TEI);
#endif
#if (BSP_IRQ_CFG_SCI0_ERI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI0_ERI_IRQn) = ELC_EVENT_SCI0_ERI;
    NVIC_SetPriority(SCI0_ERI_IRQn, BSP_IRQ_CFG_SCI0_ERI);
#endif
#if (BSP_IRQ_CFG_SCI0_AM != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI0_AM_IRQn) = ELC_EVENT_SCI0_AM;
    NVIC_SetPriority(SCI0_AM_IRQn, BSP_IRQ_CFG_SCI0_AM);
#endif
#if (BSP_IRQ_CFG_SCI0_RXI_OR_ERI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI0_RXI_OR_ERI_IRQn) = ELC_EVENT_SCI0_RXI_OR_ERI;
    NVIC_SetPriority(SCI0_RXI_OR_ERI_IRQn, BSP_IRQ_CFG_SCI0_RXI_OR_ERI);
#endif
#if (BSP_IRQ_CFG_SCI1_RXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI1_RXI_IRQn) = ELC_EVENT_SCI1_RXI;
    NVIC_SetPriority(SCI1_RXI_IRQn, BSP_IRQ_CFG_SCI1_RXI);
#endif
#if (BSP_IRQ_CFG_SCI1_TXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI1_TXI_IRQn) = ELC_EVENT_SCI1_TXI;
    NVIC_SetPriority(SCI1_TXI_IRQn, BSP_IRQ_CFG_SCI1_TXI);
#endif
#if (BSP_IRQ_CFG_SCI1_TEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI1_TEI_IRQn) = ELC_EVENT_SCI1_TEI;
    NVIC_SetPriority(SCI1_TEI_IRQn, BSP_IRQ_CFG_SCI1_TEI);
#endif
#if (BSP_IRQ_CFG_SCI1_ERI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI1_ERI_IRQn) = ELC_EVENT_SCI1_ERI;
    NVIC_SetPriority(SCI1_ERI_IRQn, BSP_IRQ_CFG_SCI1_ERI);
#endif
#if (BSP_IRQ_CFG_SCI1_AM != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI1_AM_IRQn) = ELC_EVENT_SCI1_AM;
    NVIC_SetPriority(SCI1_AM_IRQn, BSP_IRQ_CFG_SCI1_AM);
#endif
#if (BSP_IRQ_CFG_SCI2_RXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI2_RXI_IRQn) = ELC_EVENT_SCI2_RXI;
    NVIC_SetPriority(SCI2_RXI_IRQn, BSP_IRQ_CFG_SCI2_RXI);
#endif
#if (BSP_IRQ_CFG_SCI2_TXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI2_TXI_IRQn) = ELC_EVENT_SCI2_TXI;
    NVIC_SetPriority(SCI2_TXI_IRQn, BSP_IRQ_CFG_SCI2_TXI);
#endif
#if (BSP_IRQ_CFG_SCI2_TEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI2_TEI_IRQn) = ELC_EVENT_SCI2_TEI;
    NVIC_SetPriority(SCI2_TEI_IRQn, BSP_IRQ_CFG_SCI2_TEI);
#endif
#if (BSP_IRQ_CFG_SCI2_ERI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI2_ERI_IRQn) = ELC_EVENT_SCI2_ERI;
    NVIC_SetPriority(SCI2_ERI_IRQn, BSP_IRQ_CFG_SCI2_ERI);
#endif
#if (BSP_IRQ_CFG_SCI2_AM != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI2_AM_IRQn) = ELC_EVENT_SCI2_AM;
    NVIC_SetPriority(SCI2_AM_IRQn, BSP_IRQ_CFG_SCI2_AM);
#endif
#if (BSP_IRQ_CFG_SCI3_RXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI3_RXI_IRQn) = ELC_EVENT_SCI3_RXI;
    NVIC_SetPriority(SCI3_RXI_IRQn, BSP_IRQ_CFG_SCI3_RXI);
#endif
#if (BSP_IRQ_CFG_SCI3_TXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI3_TXI_IRQn) = ELC_EVENT_SCI3_TXI;
    NVIC_SetPriority(SCI3_TXI_IRQn, BSP_IRQ_CFG_SCI3_TXI);
#endif
#if (BSP_IRQ_CFG_SCI3_TEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI3_TEI_IRQn) = ELC_EVENT_SCI3_TEI;
    NVIC_SetPriority(SCI3_TEI_IRQn, BSP_IRQ_CFG_SCI3_TEI);
#endif
#if (BSP_IRQ_CFG_SCI3_ERI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI3_ERI_IRQn) = ELC_EVENT_SCI3_ERI;
    NVIC_SetPriority(SCI3_ERI_IRQn, BSP_IRQ_CFG_SCI3_ERI);
#endif
#if (BSP_IRQ_CFG_SCI3_AM != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI3_AM_IRQn) = ELC_EVENT_SCI3_AM;
    NVIC_SetPriority(SCI3_AM_IRQn, BSP_IRQ_CFG_SCI3_AM);
#endif
#if (BSP_IRQ_CFG_SCI4_RXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI4_RXI_IRQn) = ELC_EVENT_SCI4_RXI;
    NVIC_SetPriority(SCI4_RXI_IRQn, BSP_IRQ_CFG_SCI4_RXI);
#endif
#if (BSP_IRQ_CFG_SCI4_TXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI4_TXI_IRQn) = ELC_EVENT_SCI4_TXI;
    NVIC_SetPriority(SCI4_TXI_IRQn, BSP_IRQ_CFG_SCI4_TXI);
#endif
#if (BSP_IRQ_CFG_SCI4_TEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI4_TEI_IRQn) = ELC_EVENT_SCI4_TEI;
    NVIC_SetPriority(SCI4_TEI_IRQn, BSP_IRQ_CFG_SCI4_TEI);
#endif
#if (BSP_IRQ_CFG_SCI4_ERI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI4_ERI_IRQn) = ELC_EVENT_SCI4_ERI;
    NVIC_SetPriority(SCI4_ERI_IRQn, BSP_IRQ_CFG_SCI4_ERI);
#endif
#if (BSP_IRQ_CFG_SCI4_AM != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI4_AM_IRQn) = ELC_EVENT_SCI4_AM;
    NVIC_SetPriority(SCI4_AM_IRQn, BSP_IRQ_CFG_SCI4_AM);
#endif
#if (BSP_IRQ_CFG_SCI5_RXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI5_RXI_IRQn) = ELC_EVENT_SCI5_RXI;
    NVIC_SetPriority(SCI5_RXI_IRQn, BSP_IRQ_CFG_SCI5_RXI);
#endif
#if (BSP_IRQ_CFG_SCI5_TXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI5_TXI_IRQn) = ELC_EVENT_SCI5_TXI;
    NVIC_SetPriority(SCI5_TXI_IRQn, BSP_IRQ_CFG_SCI5_TXI);
#endif
#if (BSP_IRQ_CFG_SCI5_TEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI5_TEI_IRQn) = ELC_EVENT_SCI5_TEI;
    NVIC_SetPriority(SCI5_TEI_IRQn, BSP_IRQ_CFG_SCI5_TEI);
#endif
#if (BSP_IRQ_CFG_SCI5_ERI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI5_ERI_IRQn) = ELC_EVENT_SCI5_ERI;
    NVIC_SetPriority(SCI5_ERI_IRQn, BSP_IRQ_CFG_SCI5_ERI);
#endif
#if (BSP_IRQ_CFG_SCI5_AM != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI5_AM_IRQn) = ELC_EVENT_SCI5_AM;
    NVIC_SetPriority(SCI5_AM_IRQn, BSP_IRQ_CFG_SCI5_AM);
#endif
#if (BSP_IRQ_CFG_SCI6_RXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI6_RXI_IRQn) = ELC_EVENT_SCI6_RXI;
    NVIC_SetPriority(SCI6_RXI_IRQn, BSP_IRQ_CFG_SCI6_RXI);
#endif
#if (BSP_IRQ_CFG_SCI6_TXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI6_TXI_IRQn) = ELC_EVENT_SCI6_TXI;
    NVIC_SetPriority(SCI6_TXI_IRQn, BSP_IRQ_CFG_SCI6_TXI);
#endif
#if (BSP_IRQ_CFG_SCI6_TEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI6_TEI_IRQn) = ELC_EVENT_SCI6_TEI;
    NVIC_SetPriority(SCI6_TEI_IRQn, BSP_IRQ_CFG_SCI6_TEI);
#endif
#if (BSP_IRQ_CFG_SCI6_ERI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI6_ERI_IRQn) = ELC_EVENT_SCI6_ERI;
    NVIC_SetPriority(SCI6_ERI_IRQn, BSP_IRQ_CFG_SCI6_ERI);
#endif
#if (BSP_IRQ_CFG_SCI6_AM != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI6_AM_IRQn) = ELC_EVENT_SCI6_AM;
    NVIC_SetPriority(SCI6_AM_IRQn, BSP_IRQ_CFG_SCI6_AM);
#endif
#if (BSP_IRQ_CFG_SCI7_RXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI7_RXI_IRQn) = ELC_EVENT_SCI7_RXI;
    NVIC_SetPriority(SCI7_RXI_IRQn, BSP_IRQ_CFG_SCI7_RXI);
#endif
#if (BSP_IRQ_CFG_SCI7_TXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI7_TXI_IRQn) = ELC_EVENT_SCI7_TXI;
    NVIC_SetPriority(SCI7_TXI_IRQn, BSP_IRQ_CFG_SCI7_TXI);
#endif
#if (BSP_IRQ_CFG_SCI7_TEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI7_TEI_IRQn) = ELC_EVENT_SCI7_TEI;
    NVIC_SetPriority(SCI7_TEI_IRQn, BSP_IRQ_CFG_SCI7_TEI);
#endif
#if (BSP_IRQ_CFG_SCI7_ERI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI7_ERI_IRQn) = ELC_EVENT_SCI7_ERI;
    NVIC_SetPriority(SCI7_ERI_IRQn, BSP_IRQ_CFG_SCI7_ERI);
#endif
#if (BSP_IRQ_CFG_SCI7_AM != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI7_AM_IRQn) = ELC_EVENT_SCI7_AM;
    NVIC_SetPriority(SCI7_AM_IRQn, BSP_IRQ_CFG_SCI7_AM);
#endif
#if (BSP_IRQ_CFG_SCI8_RXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI8_RXI_IRQn) = ELC_EVENT_SCI8_RXI;
    NVIC_SetPriority(SCI8_RXI_IRQn, BSP_IRQ_CFG_SCI8_RXI);
#endif
#if (BSP_IRQ_CFG_SCI8_TXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI8_TXI_IRQn) = ELC_EVENT_SCI8_TXI;
    NVIC_SetPriority(SCI8_TXI_IRQn, BSP_IRQ_CFG_SCI8_TXI);
#endif
#if (BSP_IRQ_CFG_SCI8_TEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI8_TEI_IRQn) = ELC_EVENT_SCI8_TEI;
    NVIC_SetPriority(SCI8_TEI_IRQn, BSP_IRQ_CFG_SCI8_TEI);
#endif
#if (BSP_IRQ_CFG_SCI8_ERI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI8_ERI_IRQn) = ELC_EVENT_SCI8_ERI;
    NVIC_SetPriority(SCI8_ERI_IRQn, BSP_IRQ_CFG_SCI8_ERI);
#endif
#if (BSP_IRQ_CFG_SCI8_AM != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI8_AM_IRQn) = ELC_EVENT_SCI8_AM;
    NVIC_SetPriority(SCI8_AM_IRQn, BSP_IRQ_CFG_SCI8_AM);
#endif
#if (BSP_IRQ_CFG_SCI9_RXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI9_RXI_IRQn) = ELC_EVENT_SCI9_RXI;
    NVIC_SetPriority(SCI9_RXI_IRQn, BSP_IRQ_CFG_SCI9_RXI);
#endif
#if (BSP_IRQ_CFG_SCI9_TXI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI9_TXI_IRQn) = ELC_EVENT_SCI9_TXI;
    NVIC_SetPriority(SCI9_TXI_IRQn, BSP_IRQ_CFG_SCI9_TXI);
#endif
#if (BSP_IRQ_CFG_SCI9_TEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI9_TEI_IRQn) = ELC_EVENT_SCI9_TEI;
    NVIC_SetPriority(SCI9_TEI_IRQn, BSP_IRQ_CFG_SCI9_TEI);
#endif
#if (BSP_IRQ_CFG_SCI9_ERI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI9_ERI_IRQn) = ELC_EVENT_SCI9_ERI;
    NVIC_SetPriority(SCI9_ERI_IRQn, BSP_IRQ_CFG_SCI9_ERI);
#endif
#if (BSP_IRQ_CFG_SCI9_AM != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SCI9_AM_IRQn) = ELC_EVENT_SCI9_AM;
    NVIC_SetPriority(SCI9_AM_IRQn, BSP_IRQ_CFG_SCI9_AM);
#endif
#if (BSP_IRQ_CFG_RSPI0_SPRI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RSPI0_SPRI_IRQn) = ELC_EVENT_RSPI0_SPRI;
    NVIC_SetPriority(RSPI0_SPRI_IRQn, BSP_IRQ_CFG_RSPI0_SPRI);
#endif
#if (BSP_IRQ_CFG_RSPI0_SPTI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RSPI0_SPTI_IRQn) = ELC_EVENT_RSPI0_SPTI;
    NVIC_SetPriority(RSPI0_SPTI_IRQn, BSP_IRQ_CFG_RSPI0_SPTI);
#endif
#if (BSP_IRQ_CFG_RSPI0_SPII != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RSPI0_SPII_IRQn) = ELC_EVENT_RSPI0_SPII;
    NVIC_SetPriority(RSPI0_SPII_IRQn, BSP_IRQ_CFG_RSPI0_SPII);
#endif
#if (BSP_IRQ_CFG_RSPI0_SPEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RSPI0_SPEI_IRQn) = ELC_EVENT_RSPI0_SPEI;
    NVIC_SetPriority(RSPI0_SPEI_IRQn, BSP_IRQ_CFG_RSPI0_SPEI);
#endif
#if (BSP_IRQ_CFG_RSPI0_SP_ELCTEND != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RSPI0_SP_ELCTEND_IRQn) = ELC_EVENT_RSPI0_SP_ELCTEND;
    NVIC_SetPriority(RSPI0_SP_ELCTEND_IRQn, BSP_IRQ_CFG_RSPI0_SP_ELCTEND);
#endif
#if (BSP_IRQ_CFG_RSPI1_SPRI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RSPI1_SPRI_IRQn) = ELC_EVENT_RSPI1_SPRI;
    NVIC_SetPriority(RSPI1_SPRI_IRQn, BSP_IRQ_CFG_RSPI1_SPRI);
#endif
#if (BSP_IRQ_CFG_RSPI1_SPTI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RSPI1_SPTI_IRQn) = ELC_EVENT_RSPI1_SPTI;
    NVIC_SetPriority(RSPI1_SPTI_IRQn, BSP_IRQ_CFG_RSPI1_SPTI);
#endif
#if (BSP_IRQ_CFG_RSPI1_SPII != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RSPI1_SPII_IRQn) = ELC_EVENT_RSPI1_SPII;
    NVIC_SetPriority(RSPI1_SPII_IRQn, BSP_IRQ_CFG_RSPI1_SPII);
#endif
#if (BSP_IRQ_CFG_RSPI1_SPEI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RSPI1_SPEI_IRQn) = ELC_EVENT_RSPI1_SPEI;
    NVIC_SetPriority(RSPI1_SPEI_IRQn, BSP_IRQ_CFG_RSPI1_SPEI);
#endif
#if (BSP_IRQ_CFG_RSPI1_SP_ELCTEND != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)RSPI1_SP_ELCTEND_IRQn) = ELC_EVENT_RSPI1_SP_ELCTEND;
    NVIC_SetPriority(RSPI1_SP_ELCTEND_IRQn, BSP_IRQ_CFG_RSPI1_SP_ELCTEND);
#endif
#if (BSP_IRQ_CFG_QSPI_INTR != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)QSPI_INTR_IRQn) = ELC_EVENT_QSPI_INTR;
    NVIC_SetPriority(QSPI_INTR_IRQn, BSP_IRQ_CFG_QSPI_INTR);
#endif
#if (BSP_IRQ_CFG_SDHI_MMC0_ACCS != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SDHI_MMC0_ACCS_IRQn) = ELC_EVENT_SDHI_MMC0_ACCS;
    NVIC_SetPriority(SDHI_MMC0_ACCS_IRQn, BSP_IRQ_CFG_SDHI_MMC0_ACCS);
#endif
#if (BSP_IRQ_CFG_SDHI_MMC0_SDIO != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SDHI_MMC0_SDIO_IRQn) = ELC_EVENT_SDHI_MMC0_SDIO;
    NVIC_SetPriority(SDHI_MMC0_SDIO_IRQn, BSP_IRQ_CFG_SDHI_MMC0_SDIO);
#endif
#if (BSP_IRQ_CFG_SDHI_MMC0_CARD != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SDHI_MMC0_CARD_IRQn) = ELC_EVENT_SDHI_MMC0_CARD;
    NVIC_SetPriority(SDHI_MMC0_CARD_IRQn, BSP_IRQ_CFG_SDHI_MMC0_CARD);
#endif
#if (BSP_IRQ_CFG_SDHI_MMC0_ODMSDBREQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SDHI_MMC0_ODMSDBREQ_IRQn) = ELC_EVENT_SDHI_MMC0_ODMSDBREQ;
    NVIC_SetPriority(SDHI_MMC0_ODMSDBREQ_IRQn, BSP_IRQ_CFG_SDHI_MMC0_ODMSDBREQ);
#endif
#if (BSP_IRQ_CFG_SDHI_MMC1_ACCS != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SDHI_MMC1_ACCS_IRQn) = ELC_EVENT_SDHI_MMC1_ACCS;
    NVIC_SetPriority(SDHI_MMC1_ACCS_IRQn, BSP_IRQ_CFG_SDHI_MMC1_ACCS);
#endif
#if (BSP_IRQ_CFG_SDHI_MMC1_SDIO != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SDHI_MMC1_SDIO_IRQn) = ELC_EVENT_SDHI_MMC1_SDIO;
    NVIC_SetPriority(SDHI_MMC1_SDIO_IRQn, BSP_IRQ_CFG_SDHI_MMC1_SDIO);
#endif
#if (BSP_IRQ_CFG_SDHI_MMC1_CARD != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SDHI_MMC1_CARD_IRQn) = ELC_EVENT_SDHI_MMC1_CARD;
    NVIC_SetPriority(SDHI_MMC1_CARD_IRQn, BSP_IRQ_CFG_SDHI_MMC1_CARD);
#endif
#if (BSP_IRQ_CFG_SDHI_MMC1_ODMSDBREQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)SDHI_MMC1_ODMSDBREQ_IRQn) = ELC_EVENT_SDHI_MMC1_ODMSDBREQ;
    NVIC_SetPriority(SDHI_MMC1_ODMSDBREQ_IRQn, BSP_IRQ_CFG_SDHI_MMC1_ODMSDBREQ);
#endif
#if (BSP_IRQ_CFG_EXT_DIVIDER_INTMD != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)EXT_DIVIDER_INTMD_IRQn) = ELC_EVENT_EXT_DIVIDER_INTMD;
    NVIC_SetPriority(EXT_DIVIDER_INTMD_IRQn, BSP_IRQ_CFG_EXT_DIVIDER_INTMD);
#endif
#if (BSP_IRQ_CFG_TSIP_PROC_BUSY_N != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)TSIP_PROC_BUSY_N_IRQn) = ELC_EVENT_TSIP_PROC_BUSY_N;
    NVIC_SetPriority(TSIP_PROC_BUSY_N_IRQn, BSP_IRQ_CFG_TSIP_PROC_BUSY_N);
#endif
#if (BSP_IRQ_CFG_TSIP_ROMOK_N != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)TSIP_ROMOK_N_IRQn) = ELC_EVENT_TSIP_ROMOK_N;
    NVIC_SetPriority(TSIP_ROMOK_N_IRQn, BSP_IRQ_CFG_TSIP_ROMOK_N);
#endif
#if (BSP_IRQ_CFG_TSIP_LONG_PLG_N != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)TSIP_LONG_PLG_N_IRQn) = ELC_EVENT_TSIP_LONG_PLG_N;
    NVIC_SetPriority(TSIP_LONG_PLG_N_IRQn, BSP_IRQ_CFG_TSIP_LONG_PLG_N);
#endif
#if (BSP_IRQ_CFG_TSIP_TEST_BUSY_N != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)TSIP_TEST_BUSY_N_IRQn) = ELC_EVENT_TSIP_TEST_BUSY_N;
    NVIC_SetPriority(TSIP_TEST_BUSY_N_IRQn, BSP_IRQ_CFG_TSIP_TEST_BUSY_N);
#endif
#if (BSP_IRQ_CFG_TSIP_WRRDY_0_N != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)TSIP_WRRDY_0_N_IRQn) = ELC_EVENT_TSIP_WRRDY_0_N;
    NVIC_SetPriority(TSIP_WRRDY_0_N_IRQn, BSP_IRQ_CFG_TSIP_WRRDY_0_N);
#endif
#if (BSP_IRQ_CFG_TSIP_WRRDY_1_N != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)TSIP_WRRDY_1_N_IRQn) = ELC_EVENT_TSIP_WRRDY_1_N;
    NVIC_SetPriority(TSIP_WRRDY_1_N_IRQn, BSP_IRQ_CFG_TSIP_WRRDY_1_N);
#endif
#if (BSP_IRQ_CFG_TSIP_WRRDY_4_N != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)TSIP_WRRDY_4_N_IRQn) = ELC_EVENT_TSIP_WRRDY_4_N;
    NVIC_SetPriority(TSIP_WRRDY_4_N_IRQn, BSP_IRQ_CFG_TSIP_WRRDY_4_N);
#endif
#if (BSP_IRQ_CFG_TSIP_RDRDY_0_N != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)TSIP_RDRDY_0_N_IRQn) = ELC_EVENT_TSIP_RDRDY_0_N;
    NVIC_SetPriority(TSIP_RDRDY_0_N_IRQn, BSP_IRQ_CFG_TSIP_RDRDY_0_N);
#endif
#if (BSP_IRQ_CFG_TSIP_RDRDY_1_N != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)TSIP_RDRDY_1_N_IRQn) = ELC_EVENT_TSIP_RDRDY_1_N;
    NVIC_SetPriority(TSIP_RDRDY_1_N_IRQn, BSP_IRQ_CFG_TSIP_RDRDY_1_N);
#endif
#if (BSP_IRQ_CFG_TSIP_INTEGRATE_WRRDY_N != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)TSIP_INTEGRATE_WRRDY_N_IRQn) = ELC_EVENT_TSIP_INTEGRATE_WRRDY_N;
    NVIC_SetPriority(TSIP_INTEGRATE_WRRDY_N_IRQn, BSP_IRQ_CFG_TSIP_INTEGRATE_WRRDY_N);
#endif
#if (BSP_IRQ_CFG_TSIP_INTEGRATE_RDRDY_N != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)TSIP_INTEGRATE_RDRDY_N_IRQn) = ELC_EVENT_TSIP_INTEGRATE_RDRDY_N;
    NVIC_SetPriority(TSIP_INTEGRATE_RDRDY_N_IRQn, BSP_IRQ_CFG_TSIP_INTEGRATE_RDRDY_N);
#endif
#if (BSP_IRQ_CFG_LCDC_LCDC_LEVEL_0 != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)LCDC_LCDC_LEVEL_0_IRQn) = ELC_EVENT_LCDC_LCDC_LEVEL_0;
    NVIC_SetPriority(LCDC_LCDC_LEVEL_0_IRQn, BSP_IRQ_CFG_LCDC_LCDC_LEVEL_0);
#endif
#if (BSP_IRQ_CFG_LCDC_LCDC_LEVEL_1 != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)LCDC_LCDC_LEVEL_1_IRQn) = ELC_EVENT_LCDC_LCDC_LEVEL_1;
    NVIC_SetPriority(LCDC_LCDC_LEVEL_1_IRQn, BSP_IRQ_CFG_LCDC_LCDC_LEVEL_1);
#endif
#if (BSP_IRQ_CFG_LCDC_LCDC_LEVEL_2 != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)LCDC_LCDC_LEVEL_2_IRQn) = ELC_EVENT_LCDC_LCDC_LEVEL_2;
    NVIC_SetPriority(LCDC_LCDC_LEVEL_2_IRQn, BSP_IRQ_CFG_LCDC_LCDC_LEVEL_2);
#endif
#if (BSP_IRQ_CFG_TWOD_ENGINE_IRQ != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)TWOD_ENGINE_IRQ_IRQn) = ELC_EVENT_TWOD_ENGINE_IRQ;
    NVIC_SetPriority(TWOD_ENGINE_IRQ_IRQn, BSP_IRQ_CFG_TWOD_ENGINE_IRQ);
#endif
#if (BSP_IRQ_CFG_JPEG_JEDI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)JPEG_JEDI_IRQn) = ELC_EVENT_JPEG_JEDI;
    NVIC_SetPriority(JPEG_JEDI_IRQn, BSP_IRQ_CFG_JPEG_JEDI);
#endif
#if (BSP_IRQ_CFG_JPEG_JDTI != BSP_IRQ_DISABLED)
    *(base_addr + (uint32_t)JPEG_JDTI_IRQn) = ELC_EVENT_JPEG_JDTI;
    NVIC_SetPriority(JPEG_JDTI_IRQn, BSP_IRQ_CFG_JPEG_JDTI);
#endif

}

#endif



