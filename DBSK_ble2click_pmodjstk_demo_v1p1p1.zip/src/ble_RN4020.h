/*****************************************************************************
 * Copyright (C) 2015 by Embedded Product Design, LLC                        *
 *                                                                           *
 * FILENAME: ble_RN4020.c    PART OF PROJECT: DBSK_ble2click_PmodJSTK_demo   *
 *                                                                           *
 * FILE DESCRIPTION:                                                         *
 * Function prototypes for ble_RN4020.c                                      *
 *                                                                           *
 * HISTORY:                                                                  *
 * Date          By               Description                                *
 * 2015-10-09    Ed Strehle       Initial release for Renesas DevCon 2015    *
 * 2015-10-22    EPD/Ed Strehle   v1.1.0 update for SSP v1.0.0               *
 *                                                                           *
 * NOTES:                                                                    *
 *                                                                           *
 * KNOWN TODOs:                                                              *
 * <none>                                                                    *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
#include "hal_data.h"

void 		send_BLE_byte_ascii(uint8_t value);
void 		send_BLE_uint16_ascii(uint16_t value);

void 		init_RN4020_BLE(void);
ssp_err_t 	set_RN4020_MLDPmode(void);
ssp_err_t 	set_RN4020_CMDmode(void);

bool 		wait_for_response(char *value);
ssp_err_t 	wait_for_BLE_connection(void);

