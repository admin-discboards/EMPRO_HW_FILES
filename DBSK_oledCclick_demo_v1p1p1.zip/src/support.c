/*****************************************************************************
 *  Copyright (C) 2015 by Embedded Product Design, LLC                       *
 *                                                                           *
 *  FILENAME: support.c      PART OF PROJECT: DBSK_oledCclick_demo           *
 *                                                                           *
 *  FILE DESCRIPTION:                                                        *
 *  Contains functions to override the example code in "Oled_C.c"            *
 *  using Renesas SSP equivalents.  Affected functions:                      *
 *  - InitMCU;                                                               *
 *  - OLED_C_command;                                                        *
 *  - OLED_C_data;                                                           *
 *  - DDRAM_access;                                                          *
 *  - reset_LCD;                                                             *
 *  - OLED_C_Color;                                                          *
 *  - main_oledc_demo;                                                       *
 *                                                                           *
 *  HISTORY:                                                                 *
 *  Date          By           Description                                   *
 *  2015-10-09    Ed Strehle   Initial release for Renesas DevCon 2015       *
 *                                                                           *
 *  NOTES:                                                                   *
 *                                                                           *
 *  KNOWN TODOs:                                                             *
 *  <none>                                                                   *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
#include "hal_data.h"
#include "support.h"
#include "Oled_C.h"

volatile bool 		g_spi0_xfer_complete = false;

// assumes PFS Write Enable is disabled before entry or CS won't work
ssp_err_t db_oledcdemo_spi_write (uint8_t value) {
	ssp_err_t err;

	g_spi0_xfer_complete = false;

	PFS_OLEDC_CS_PIN.PODR = 0;
	R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MICROSECONDS);  // spins the processor

	err = g_spi_on_sci.write(g_sci_spi0.p_ctrl, (void *) &value, sizeof(uint8_t), SPI_BIT_WIDTH_8_BITS);
	while (!g_spi0_xfer_complete);

	R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MICROSECONDS);  // spins the processor
	PFS_OLEDC_CS_PIN.PODR = 1;

	return err;
}

/*
// this is intended to be a 16bit SPI write.
void OLED_C_Color(uint8_t colorMSB, uint8_t colorLSB ) {
	ssp_err_t err;

	// lift pin write protection as in HW_IOPORT_PFSAccess()
	R_PMISC->PWPR_b.BOWI  = 0;	 ///< Clear BOWI bit - writing to PFSWE bit enabled
	R_PMISC->PWPR_b.PSFWE = 1;   ///< Set PFSWE bit - writing to PFS register enabled

	PFS_OLEDC_CS_PIN.PODR = 0;
	R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MICROSECONDS);  // spins the processor

	// send the MSB ... OLED_C_data(colorMSB);
	g_spi0_xfer_complete = false;
	err = g_spi_on_sci.write(g_sci_spi0.p_ctrl, (void *) &colorMSB, sizeof(uint8_t), SPI_BIT_WIDTH_8_BITS);
	while (!g_spi0_xfer_complete);

	// send the LSB ... OLED_C_data(colorLSB);
	g_spi0_xfer_complete = false;
	err = g_spi_on_sci.write(g_sci_spi0.p_ctrl, (void *) &colorLSB, sizeof(uint8_t), SPI_BIT_WIDTH_8_BITS);
	while (!g_spi0_xfer_complete);

	R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MICROSECONDS);  // spins the processor
	PFS_OLEDC_CS_PIN.PODR = 1;

	// restore pin write protection as in HW_IOPORT_PFSAccess()
	R_PMISC->PWPR_b.PSFWE = 0;   ///< Clear PFSWE bit - writing to PFS register disabled
	R_PMISC->PWPR_b.BOWI  = 1;	 ///< Set BOWI bit - writing to PFSWE bit disabled
}
*/

// Init MCU function
void InitMCU(){
	ssp_err_t	err;
	// GPIO configurations in Synergy SSP are handled in System_Init()

	// open and start SPI instance for OLED_C.
	err = g_spi_on_sci.open( g_sci_spi0.p_ctrl, g_sci_spi0.p_cfg);
	g_spi0_xfer_complete = false;

	// NOTE OLED_T pin is on P000/input only ... override with blue-wire from P008
	err = g_ioport_on_ioport.pinWrite(OLEDC_RW_PIN, IOPORT_LEVEL_LOW);

	// initialize the other control lines
	err = g_ioport_on_ioport.pinWrite(OLEDC_RST_PIN, IOPORT_LEVEL_HIGH);
	err = g_ioport_on_ioport.pinWrite(OLEDC_CS_PIN, IOPORT_LEVEL_HIGH);
	err = g_ioport_on_ioport.pinWrite(OLEDC_DC_PIN, IOPORT_LEVEL_LOW);	// cmd mode
}

//Send command to OLED C display
void OLED_C_command(uint8_t reg_index, uint8_t reg_value) {
	ssp_err_t	err;

	// lift pin write protection as in HW_IOPORT_PFSAccess()
	R_PMISC->PWPR_b.BOWI  = 0;	 ///< Clear BOWI bit - writing to PFSWE bit enabled
	R_PMISC->PWPR_b.PSFWE = 1;   ///< Set PFSWE bit - writing to PFS register enabled

	// Select index addr ... write as data
	PFS_OLEDC_DC_PIN.PODR = 0;
	err = db_oledcdemo_spi_write(reg_index);

	R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MICROSECONDS);  // spins the processor

	// Write data to reg ... write as a command
	PFS_OLEDC_DC_PIN.PODR = 1;
	err = db_oledcdemo_spi_write(reg_value);

	// restore pin write protection as in HW_IOPORT_PFSAccess()
	R_PMISC->PWPR_b.PSFWE = 0;   ///< Clear PFSWE bit - writing to PFS register disabled
	R_PMISC->PWPR_b.BOWI  = 1;	 ///< Set BOWI bit - writing to PFSWE bit disabled
}

//Send data to OLED C display
void OLED_C_data(uint8_t data_value) {
	ssp_err_t	err;

	// lift pin write protection as in HW_IOPORT_PFSAccess()
	R_PMISC->PWPR_b.BOWI  = 0;	 ///< Clear BOWI bit - writing to PFSWE bit enabled
	R_PMISC->PWPR_b.PSFWE = 1;   ///< Set PFSWE bit - writing to PFS register enabled

	// writing as data
	PFS_OLEDC_DC_PIN.PODR = 1;
	err = db_oledcdemo_spi_write(data_value);

	// restore pin write protection as in HW_IOPORT_PFSAccess()
	R_PMISC->PWPR_b.PSFWE = 0;   ///< Clear PFSWE bit - writing to PFS register disabled
	R_PMISC->PWPR_b.BOWI  = 1;	 ///< Set BOWI bit - writing to PFSWE bit disabled
}

//Sekvence before writing data to memory
void DDRAM_access(){
	uint8_t	ddram_cmd = 0x08;
	ssp_err_t	err;

	// lift pin write protection as in HW_IOPORT_PFSAccess()
	R_PMISC->PWPR_b.BOWI  = 0;	 ///< Clear BOWI bit - writing to PFSWE bit enabled
	R_PMISC->PWPR_b.PSFWE = 1;   ///< Set PFSWE bit - writing to PFS register enabled

	// writing as command
	PFS_OLEDC_DC_PIN.PODR = 0;
	err = db_oledcdemo_spi_write(ddram_cmd);

	// restore pin write protection as in HW_IOPORT_PFSAccess()
	R_PMISC->PWPR_b.PSFWE = 0;   ///< Clear PFSWE bit - writing to PFS register disabled
	R_PMISC->PWPR_b.BOWI  = 1;	 ///< Set BOWI bit - writing to PFSWE bit disabled
}


void reset_LCD () {
	// lift pin write protection as in HW_IOPORT_PFSAccess()
	R_PMISC->PWPR_b.BOWI  = 0;	 ///< Clear BOWI bit - writing to PFSWE bit enabled
	R_PMISC->PWPR_b.PSFWE = 1;   ///< Set PFSWE bit - writing to PFS register enabled

	PFS_OLEDC_RST_PIN.PODR = 0;		// OLED_RST=0;
	R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);  // spins the processor
	PFS_OLEDC_RST_PIN.PODR = 1;		// OLED_RST=1;
	R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);  // spins the processor

	// restore pin write protection as in HW_IOPORT_PFSAccess()
	R_PMISC->PWPR_b.PSFWE = 0;   ///< Clear PFSWE bit - writing to PFS register disabled
	R_PMISC->PWPR_b.BOWI  = 1;	 ///< Set BOWI bit - writing to PFSWE bit disabled
}


void callback_sci_spi0(spi_callback_args_t * p_args) {
	if (p_args->event == SPI_EVENT_TRANSFER_COMPLETE) {
		g_spi0_xfer_complete = true;

	}
}
