/*****************************************************************************
 *  Copyright (C) 2015 by Embedded Product Design, LLC                       *
 *                                                                           *
 *  FILENAME: support.h      PART OF PROJECT: DBSK_4x4rgbClick_demo          *
 *                                                                           *
 *  FILE DESCRIPTION:                                                        *
 *  Contents used to override the code in "Oled_C.c/h with                   *
 *  SSP-equivalents.                                                         *
 *                                                                           *
 *  HISTORY:                                                                 *
 *  Date          By           Description                                   *
 *  2015-10-09    Ed Strehle   Initial release for Renesas DevCon 2015       *
 *                                                                           *
 *  NOTES:                                                                   *
 *                                                                           *
 *  KNOWN TODOs:                                                             *
 *  <none>                                                                   *
 * ------------------------------------------------------------------------- *
 * This software was created by Embedded Product Design, LLC ("EPD")         *
 *     http://www.emprodesign.com                                            *
 * Unless otherwise agreed-upon in writing with EPD, contents are provided   *
 * "AS IS" and without warranty.                                             *
 *****************************************************************************/
#include "hal_data.h"

#ifndef SUPPORT_H_
#define SUPPORT_H_

/** DiscBoard user button */
#define DBSK_BUTTON01		((ioport_port_pin_t) IOPORT_PORT_01_PIN_11)

/** DiscBoard LEDs */
#define DB_LED_CPU          ((ioport_port_pin_t) IOPORT_PORT_01_PIN_09)
#define	DBSK_LED_D3         ((ioport_port_pin_t) IOPORT_PORT_02_PIN_00)
#define DBSK_LED_D4         ((ioport_port_pin_t) IOPORT_PORT_04_PIN_02)

/** other */
#define OLEDC_RST_PIN		((ioport_port_pin_t) IOPORT_PORT_00_PIN_10)
#define OLEDC_CS_PIN		((ioport_port_pin_t) IOPORT_PORT_01_PIN_03)
#define OLEDC_DC_PIN		((ioport_port_pin_t) IOPORT_PORT_04_PIN_08) // Data-Cmd ... MikroBus PWM pin

// MikroBus AN pin is tied to P000 on DiscBoard Starter Kit ... this pin is input-only on Synergy
// OLED-C uses the MikroBus AN pin as an analog output
// to support this P008 was tied to P000 ... no contention expected
#define OLEDC_RW_PIN		((ioport_port_pin_t) IOPORT_PORT_00_PIN_08) // OLED_T in demo code

// CS and DC pins need to be fast ... go directly to PmnPFS registers/bitfields
#define PFS_OLEDC_CS_PIN 	R_PFS->P103PFS_b
#define PFS_OLEDC_DC_PIN 	R_PFS->P408PFS_b
#define PFS_OLEDC_RST_PIN 	R_PFS->P010PFS_b

// macros to override Mikroe C commands throughout Oled_C.c
#define Delay_ms(a)		R_BSP_SoftwareDelay(a, BSP_DELAY_UNITS_MILLISECONDS);  // spins the processor
#define delay_ms(a)		R_BSP_SoftwareDelay(a, BSP_DELAY_UNITS_MILLISECONDS);  // spins the processor

// function prototypes
void InitMCU(void);
void OLED_C_command(uint8_t reg_index, uint8_t reg_value);
void OLED_C_data(uint8_t data_value);
void DDRAM_access(void);
void reset_LCD (void);
//void OLED_C_Color(uint8_t colorMSB, uint8_t colorLSB );
void main_oledc_demo(void);

#endif /* SUPPORT_H_ */
